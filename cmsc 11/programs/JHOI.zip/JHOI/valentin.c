#include <stdio.h>

main(){

int i,j;
int n=5;

for(i=0; i<5; i++)
{
	for(j=0; j<n; j++)
	{
	printf("%d", 5-j-i);
	}
printf("\n");	
n--;
}

for(i=1; i<6; i++)
{
	for(j=0 ; j<i; j++)
	{
	printf("%d", j+1);
	}	
printf("\n");
}
}
