#include <stdio.h>

main(){

int i,j;
int n=5;

for(i=0; i<n; i++)
{
	for(j=i; j<n; j++)
	{
	printf("%d", n-i);
	}
printf("\n");	
}

for(i=0; i<n; i++)
{
	for(j=0 ; j<i+1; j++)
	{
	printf("%d", i+1);
	}
printf("\n");	
}
}
