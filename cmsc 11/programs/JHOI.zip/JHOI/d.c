#include <stdio.h>

main(){

int b,c;
int n=7;

for(b=0; b<n; b++)
{
	for(c=0 ; c<n; c++)
	{
	if((b==c)|(b+c==n-1))
	printf("*");
	else  
	printf(" ");
	}
printf("\n");	
}

}
