#include <stdio.h>

main(){

int b,c;
int n=5;

for(b=0; b<n; b++)
{
	for(c=0 ; c<n; c++)
	{
	if((b==0)||(c==0)||(b==n+1)||(c==n-1))
	printf("*");
	else  
	printf(" ");
	}
printf("\n");	
}

}
