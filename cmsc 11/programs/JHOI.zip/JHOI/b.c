#include <stdio.h>

main(){

int n,a,b,c;

for(n=5; n>0; n--)
{
	for(a=0 ; a<n; a++)
	{
	printf("*");
	}
printf("\n");	
}

for(b=1; b<6; b++)
{
	for(c=0 ; c<b; c++)
	{
	printf("*");
	}
printf("\n");	
}
}
