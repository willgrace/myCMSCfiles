#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>

#define word_size 6

char guessed_word[100][word_size];//storage for already guessed words
int guess_index;//stores how many words are already guessed for usage for guessed_word
int number_of_tries=5;
char selected_word[word_size], twisted_word[word_size];
int random_value=1000; //Higher Value more random word but slower
int rand_times=3; //value for twisting (higher value doesnt mean more twisted word)
char answer[word_size];//answer inputted by user
int score=0;
FILE * arrFile; //pointer for file read

void select_random_word(){
	int i;
    int flag=0;// if 1 then a word is already selected
	char read_word[100];//word read from file
    arrFile = fopen("words.txt", "r"); 
    while(1){
    	if (arrFile != NULL){
	    	while(!feof(arrFile)){
			                      fscanf(arrFile,"%s\n",read_word);
			                      if(strlen(read_word)==word_size && (rand()%random_value)==0){//check if a word has length = word_size then randomize wether to choose that word or not
                                                                  strcpy(selected_word, read_word); //selected_word= "random word"
                                                                  strcpy(twisted_word, selected_word); //twisted_word = selected_word
                                                                  flag=1;
                                                                  break;
                                                                  }   
		                          }
		                          if(fclose(arrFile) != 0) printf("\nError in saving file!\n");
	                           }
                               else printf("\nFile cannot be opened!\n");
        if(flag) break;
   }

}

int word_exist(char compare[]){
	int i;
	char read_word[100];
    arrFile = fopen("words.txt", "r");
    
	if (arrFile != NULL){
		while(!feof(arrFile)){
			fscanf(arrFile,"%s\n",read_word);
			if(strcmp(read_word,compare)==0)//if was able to see word contained in "compare" in the file input
			    return contained_in_selected(compare);//calls function to check if the word from "compare" can be created using the selected word
		}
		if(fclose(arrFile) != 0) printf("\nError in saving file!\n");
	}
	else printf("\nFile cannot be opened!\n");
	return 0;
}

int contained_in_selected(char compare[]){
    int x=0,y=0,counter=0;
    char temp_word[word_size];
    strcpy(temp_word,selected_word);
    //if the length of the word inside compare is larger than the selected then it is impossible to make that word from the selected word
    if(strlen(compare)>strlen(selected_word) || strlen(compare)<3) return 0;
             
    //this function checks if the word from "compare" can be created using the selected word
    for(x=0; x<strlen(compare); x++){
             for(y=0; y<strlen(temp_word); y++){
                      if(compare[x]==temp_word[y]){
                          temp_word[y]=48;//ASCII '0'==48
                          counter++;
                          break;
                      }
             }
    }
    if(counter==strlen(compare))//if the number of correct comparison is equal to len of compare then the word can be created from existing word                           
        return 1;
    else
        return 0;
}

twist_word(){
  int index1,index2;
  char temp;
  int x=0;
  
  do{
     for(x=0;x<rand_times;x++){  
                              index1= rand()%(strlen(selected_word));
                              do{
                                 index2=rand()%(strlen(selected_word));
                                }while(index1==index2);//the two indexes to be swapped should be different
                                
                                //swap to twist word indexes
                                temp=twisted_word[index1];
                                twisted_word[index1]= twisted_word[index2];
                                twisted_word[index2]=temp;
     }
  }while(strcmp(twisted_word,selected_word)==0);
}

int word_guessed(char word[]){
    int x;
    for(x=0;x<guess_index;x++){
                                 if(strcmp(guessed_word[x],word)==0)//check if in the list of already guessed word
                                                return 1;
                                 }
    return 0;           
}

game(){
       //refresh variables
       int x=0;  
       guess_index=0;
       number_of_tries=5;
       printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");   
       score=0;
       
       srand(time(NULL));//random dependent to time
       
       select_random_word();//select random word
       
       //printf("Original Word: %s\n",selected_word);
       
       twist_word();//twist the chosen word
       
       do{
          printf("***************\nScore: %d\n",score);
          printf("Tries Remaining: %d\n\n",number_of_tries);
          printf("Scrammbled Word: %s\n***************\n\n",twisted_word); 
          printf("Input Answer: ");
          scanf("%s",answer);
          printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
          for(x=0;x<strlen(answer);x++)//lower case answer
                                       answer[x]=tolower(answer[x]);
          if(word_exist(answer)){
                    if(!word_guessed(answer)){
                         score=score+strlen(answer);//score depends on word length
                         printf("%s exists\n",answer);  
                    }
                    else printf("%Word Already Guessed\n");     
                      
                    strcpy(guessed_word[guess_index++],answer); //add to word guessed
          }
          else{
                number_of_tries--;
                printf("%s does not exist\n",answer); 
                if(number_of_tries==0)//lose if number of tries ==0
                      break;  
                }  
       }while(strcmp(answer,selected_word)!=0);//infinite loop until you guessed the correct word
       
       if(number_of_tries==0) printf("You Lose\n\n");
       else printf("You Guessed the word correctly!\n\n");
       printf("Original Word: %s\n",selected_word);
       printf("Score: %d\n\n\n",score);  
}

main(){
       int choice=0;
       while(1){
            printf("TextTwist V1.0\nBy: Nikki Formilleza\n\n");
            printf("MENU\n");
            printf("1.)New Game\n");
            printf("2.)Quit\n\n");
            printf("Enter your choice: ");
            scanf("%d", &choice);
           
           switch (choice){
                  case 1: {game(); break;}//case n: where n=ver
                  case 2: {exit(1); break;}//exit
                  default : printf("Invalid...");//if not in the case conditions then default command will initialize
                 }
      }
}
