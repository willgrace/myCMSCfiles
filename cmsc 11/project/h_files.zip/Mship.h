

#ifndef MSHIP_H
#define MSHIP_H

#include "settings.h"


class mother
{

public:

	mother() {} // constructor

	void Ship();

private:

 int exm1, exm2, eym1, eym2;

int mbx, mby;

int mother_shoot;

};




 void mother::Ship()
       
 {

	 if (!exm1) {
	 exm1=10;
	 exm2=40; 
	 eym1=8;
	 eym2=14; }
        

    Line_H (exm1, exm2, eym1, 8);
    Line_V (eym1, eym2, exm1+15, 15);
    plot_pixel (exm1-1, eym1, 12);
    plot_pixel (exm2+1, eym1, 12);

  if (exm1 >= 6 && exm2 <= 300) {
  exm1++;
  exm2++; }


  if (exm2 >= 300) {

    Line_H (exm1, exm2, eym1, 0);
    Line_V (eym1, eym2, exm1+15, 0);
    plot_pixel (exm1-1, eym1, 0);
    plot_pixel (exm2+1, eym1, 0);

     quiet();

  exm1=10, exm2=40, eym1=8, eym2=14;  }


    switch (1+rand() %10)
    {

    case 5:

     if (!mbx) {     
    mbx=exm1+15;
     mby=eym2; }
     
     if (!mother_shoot) {

shoot();      
    
     mother_shoot=1; }   break;


	} // End of switch structure.



 if (mother_shoot) {  
 plot_pixel (mbx, mby+=2, 12);
   
  if (mby >= 185) {
 mother_shoot=0; 
 mby=0;
 mbx=0;}

} // End of mother shoot if. 

     beep();
  
     } // End of function.



#endif