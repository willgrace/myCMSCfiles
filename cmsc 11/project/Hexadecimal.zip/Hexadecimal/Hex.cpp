
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <conio.h>

// Structures ////////////////////////////////////////////////////////

struct give { short OK; };

give sendback = { 0 };

//////////////////////////////////////////////////////////////////////

// Globals ///////////////////////////////////////////////////////////

long number, orig, hold[30], count = 0;


// Prototypes ////////////////////////////////////////////////////////

void space (void);

////////////////////////////////////////////////////////////////////// 


int main()
{

	bool Done = false;
	char again;


	puts ("\n\n\n                           HEXADECIMAL CONVERTER\n");
    puts ("                                   By\n");
	puts ("                              Steven Ramponi\n\n\n\n");	

	puts ("Hit any key to continue..");
	getch();

// Main event loop //////////////////////////////////////////////////

	while (!Done) {


	space();

enter:
    printf ("Enter an integer: ");
	scanf ("%i", &number);

	if (number <= 0) {
		printf ("\n\nNo number less than zero is allowed, try again. \a");
		goto enter;
	} // End if.

	orig = number; // Store the original number from user.

	space();

	hold[count++] = number % 16;

	/* Divide the number by sixteen to store the remainder in 
	the hold array */
    while ((number/=16) > 0) hold[count++] = number % 16;

	printf ("Input number: %i", orig); // Original number input.

	printf ("\n\nHex: "); // Banner.
		
	while (count-- > 0) { // Unload the array stack to reverse output.

	if (hold[count] >= 10) {
		
		if (hold[count] == 10) printf ("A");

		if (hold[count] == 11) printf ("B");

		if (hold[count] == 12) printf ("C");

		if (hold[count] == 13) printf ("D");

		if (hold[count] == 14) printf ("E");

		if (hold[count] == 15) printf ("F");

		} // End if.

	    else printf ("%i", hold[count]);

	} // End of while.

    puts ("\n\n");

	printf ("Would you like to try another number? (y-n): ");

	do {                     // Reset everything.
		again = getchar(); count = 0; number = 0; orig = 0; 
	}while (again != 'y' && again != 'n');

	if (again == 'n') Done = true;

	} // End of main event loop. /////////////////////////////////////

	
    puts ("\n\nHit a key to exit..");

	getch();

	return (sendback.OK);

} // End of program.


// Function definitions /////////////////////////////////////////////

void space (void)
{

	puts ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

} // End of function.

