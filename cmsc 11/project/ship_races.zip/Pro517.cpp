// -------------------------Excercise------------------------------
// ----------------------------5.17--------------------------------
// ---------------------By Steven Ramponi--------------------------
// -----------------------With speed control-----------------------


#include <ctype.h>
#include <iostream.h>
#include <iomanip.h>
#include <time.h>
#include <conio.h>
#include "Sound1.h"
#include "vga.h"
#include "settings.h"


// S T R U C T U R E S /////////////////////////////


typedef struct ship_type

{

int xs1, xs2, ys1, ys2; // Ships dimentions.
int px1, px2;  /////////////////////////////

  } ships;


  // Structure access.

  ships blue1, red2;


// F U N C T I O N S //////////////////////////////////////////////////

 void Blue()
{

     if (!blue1.xs1) {
      blue1.xs1=13;
      blue1.xs2=21;
      blue1.ys1=18;
      blue1.ys2=21;
      blue1.px1=12;
      blue1.px2=22; }


     Line_H (blue1.xs1, blue1.xs2, blue1.ys1, 1);
     Line_V (blue1.ys1, blue1.ys2, blue1.xs1+4, 1);
     plot_pixel (blue1.px1, blue1.ys1, random(256));
     plot_pixel (blue1.px2, blue1.ys1, random(256));

  } // End of function.



   void Red()
{

     if (!red2.xs1) {
      red2.xs1=300;
      red2.xs2=308;
      red2.ys1=18;
      red2.ys2=21;
      red2.px1=299;
      red2.px2=309; }


     Line_H (red2.xs1, red2.xs2, red2.ys1, 12);
     Line_V (red2.ys1, red2.ys2, red2.xs1+4, 12);
     plot_pixel (red2.px1, red2.ys1, random(256));
     plot_pixel (red2.px2, red2.ys1, random(256));

  } // End of function.



// P R O T O T Y P E S ////////////////////////////////////////////////

void TimeDelay(double*); // Function prototype
void race1 (int *, int *); // Function prototype Blue.
void race2 (int *, int *); // Function Prototype Red.

////////////////////////////////////////////////////////////////////////



// M A I N ////////////////////////////////////////////////////////////

 int main()

{

 cout.setf(ios::fixed);

 srand(time(0)); // Seed randem number

    int limiter = 1, counter = 1, win = 0, winner = 0, loser = 0; // Declaration of one bonus input.
						       // counter keeper, wins, and losses.
    double speed; // Speed control declaration

    int Ships = 0; // Declaration of ship type

    char first[15]; // Declaration of first name

    char last[20]; // Declaration of last name

    char start[2]; // Declaration of start race

    float bet = 0, total = 500.00; // Declaration of bet

    VGAScreen();
    TextScreen();

    delay(1000);
    setborderc(1 + rand() % 12);
    buzz(2500); delay(25);
    buzz(1500); delay(25); buzz(750); delay(50);
    buzz(1000); delay(100); quiet();

    cout << "Enter your first name: ";
    cin >> first; // Read name
    buzz(2500); delay(25); buzz(1500);
    buzz(750);
    quiet();

    cout << "Enter your last name: "; // Prompt for last name
    cin >> last; // Read name
    buzz(2500); delay(25); buzz(1500);
    buzz(750);
    quiet();

    cout << "\n\n"; // Space

	cout << "-------------------SHIP RACES------------------\n";
	cout << "----------------------With speed control----------------------\n\n";

	cout << "                        *DIRECTIONS*\n\n\n";

	cout << "       A player places a bet on who will finish first: the blue ship or the\n";

	cout << " red ship. If the player reaches $3,000.00: a bonus $2,000.00 is given. If a \n";

	cout << " player can win the race in under 8 clicks: a bonus $500.00 is given. If a\n";

	cout << " player can reach $15,000.00: the player walks home with the money and wins the game.\n\n";

	cout << setprecision(2) << "Your total amount is: $" << total << "\n\n";

		 start:

	cout << "Pace your bet, but not over your total amount: $";
	cin >> bet;
	buzz(2500); delay(25); buzz(1500);
	buzz(750);
	quiet();

	if (bet > total){
	clrscr();
		cout << "You fool. I told you not to place a bet higher than you can afford!\n";
		cout << endl; // Space
		buzz(55); delay(25); buzz(rand() % 2500); buzz(100);
		delay(25); buzz(1200); quiet();
		goto start;}

	cout << "\n\n"; // Space

		  an:

	cout << "Now which ship are you going to bet on: The blue, or the red ?\n";
	cout << "Just type 1 for blue, or 2 for red. ";
	cin >> Ships; // Read decision
	buzz(2500); delay(25); buzz(1500);
	buzz(750);
	quiet();

	if (Ships <= 0 || Ships  > 2){
	clrscr();
		cout << endl; // Space
		cout << "You fool. You only have two ships to choose from!\n";
		cout << endl; // Space
		buzz(55); delay(25); buzz(rand() % 2500); buzz(100);
		delay(25); buzz(1200); quiet();
		goto an;}

			       sp:

	cout << endl; // Space
	cout << "Set the speed at which you want the game to run.\n";
	cout << "Enter 0 for no delay. 1, 2, or (3) for highest delay: "; // Prompt for delay
	cin >> speed; // Read the speed
	buzz(2500); delay(25); buzz(1500);
	buzz(750);
	quiet();

	if (speed < 0 || speed > 3){
	clrscr();
		cout << endl; // Space
		cout << "            	NO NUMBERS OVER 3 OR UNDER 0!\n";
		buzz(55); delay(25); buzz(rand() % 2500); buzz(100);
		delay(25); buzz(1200); quiet();
		goto sp;}

	if (speed == 1)
		speed = 39999;

	if (speed == 2)
		speed = 59999;

	if (speed == 3)
		speed = 599999;

    cout << endl; // Space
	cout << "                          Start the race ?\n"; // Prompt to start race
	cout << "                              (y or n) " ;

	cin >> start; // Read decision

	buzz(2500); delay(25); buzz(1500);
	buzz(750);
	quiet();

	cout << "\n\n\n"; // Space

	while (toupper(start[0]) != 'N') {

		   int timer = 1; // Declaration of click counter

	buzz(2500); delay(25);
	buzz(1500); delay(25); buzz(750); delay(50);
	buzz(1000); delay(100); quiet();

	VGAScreen();
	stars();

	cout << "     BANG!!!!!\n";
	cout << "      AND THEY'RE OFF!!!!\n\n\n\n";
	delay(100);

	setborderc(1 + rand() % 12);

	cout << " BLUE" << setw(25) << "RED\n";
	cout << " --------" << setw(25) << "----\n";

	delay(1000);

	int blue = 0, b, red = 0, r; // Declaration of ships


	while (!keyhit()) {

	if (blue >= 27 || red >= 27)
		goto end;

	b = 1 + rand() % 10;
	r = 1 + rand() % 10;

	if (b <= 5)
		blue += 3;

	if (b == 6 || b == 7)
		blue -= 6;

	if (b > 7 && b <= 10)
		blue += 1;

	if (r <= 2)
		red += 0;

	if (r == 3 || r == 4)
		red += 9;

	if (r == 5)
		red -= 12;

	if (r > 5 && r <= 8)
		red += 1;

	if (r > 8 && r <= 10)
		red -= 2;

	if (blue < 0)
		blue = 0;

	if (red < 0)
		red = 0;


	timer++; // keep track of clicks

	TimeDelay(&speed); // Function call

	race1(&blue, &red); // Function call

	race2(&red, &blue); // Function call


   if (blue >= 27 && red < blue){

      blue1.xs1=13;
      blue1.xs2=21;
      blue1.ys1=18;
      blue1.ys2=21;
      blue1.px1=12;
      blue1.px2=22;
      red2.xs1=300;
      red2.xs2=308;
      red2.ys1=18;
      red2.ys2=21;
      red2.px1=299;
      red2.px2=309;

	TextScreen();
	setborderc(rand() % 12);


	  if (Ships == 1){
		cout << setprecision(2) << first << ' ' << last << " WINS! $" << bet << endl;
		win++; // Add amount of winnings
		winner = 1; // Make variable equal one for bonus point
		total += bet; // Add winnings
		ship();
		buzz(2500); delay(25);
		buzz(1500); delay(25); buzz(750); delay(50);
		buzz(1000); delay(100); quiet();
		cout << setprecision(2) << "Your total amount is: $" << total << endl;}

		else {
			cout << setprecision(2) << first << ' ' << last << " LOSES. $" << bet << endl;
			loser++; // Add to losses
			winner = 0; // Make variable equal to zero for no bonus point
			total -= bet;  // Subtract bet
			pong(); lose();
			buzz(55); delay(25); buzz(rand() % 2500); buzz(100);
			delay(25); buzz(1200); quiet();
			cout << setprecision(2) << "Your total amount is: $" << total << endl;}


		cout << "\n\n\n";
		cout << "                     BLUE WINS!\n\n\n";}


    if (red >= 27 && blue < red){

      blue1.xs1=13;
      blue1.xs2=21;
      blue1.ys1=18;
      blue1.ys2=21;
      blue1.px1=12;
      blue1.px2=22;
      red2.xs1=300;
      red2.xs2=308;
      red2.ys1=18;
      red2.ys2=21;
      red2.px1=299;
      red2.px2=309;

	 TextScreen();
	 setborderc(rand() % 12);

	  if (Ships == 2){
		cout << setprecision(2) << first << ' ' << last << " WINS! $" << bet << endl;
		winner = 1; // Check bonus
		win++; // Add amount of winnings
		total += bet; // Add winnings
		ship();
		buzz(2500); delay(25);
		buzz(1500); delay(25); buzz(750); delay(50);
		buzz(1000); delay(100); quiet();
		cout << setprecision(2) << "Your total amount is: $" << total << endl;}

		else {
			cout << setprecision(2) <<  first << ' ' << last << " LOSES $" << bet << endl;
			loser++; // Add to losses
			winner = 0;
			total -= bet; // Subtract bet
			pong(); lose();
			buzz(55); delay(25); buzz(rand() % 2500); buzz(100);
			delay(25); buzz(1200); quiet();
			cout << setprecision(2) << "Your total amount is: $" << total << endl;}


		cout << "\n\n\n";
		cout << "                     RED WINS!\n\n\n"; }


	if (blue >= 27 && red == blue){
	TextScreen();
	setborderc(rand() % 12);

		cout << "\n\n\n";
		buzz(55); delay(25); buzz(rand() % 2500); buzz(100);
		delay(25); buzz(1200); quiet();
		cout << "                     A TIE RACE\n\n\n";}

	cout << "\n\n";} // Space

		 end:

	     if (total <= 0){

	     pong(); lose();

	     buzz(55); delay(25); buzz(rand() % 2500); buzz(100);
	     delay(25); buzz(1200); quiet();
		cout << "You are out of money!\n";
		cout << "    LOSER!	\n\n";
		cout << "CLOCK: " << timer << " Clicks" <<  endl;
		cout << "TOTAL WINNINGS: " << win << endl;
		cout << "TOTAL LOSSES: " << loser << endl;
		cout <<"\nHit spacebar to exit..\n";
		getch();
		goto EndGame;}

	     if (total >= 3000 && limiter == 1){

		limiter++; // Add one to limiter
		total += 2000; // Add bonus amount
		buzz(2500); delay(25);
		buzz(1500); delay(25); buzz(750); delay(50);
		buzz(1000); delay(100); quiet();
		cout << first << ' ' << last << " Hits the Jackpot of: $2000.00 " << endl;
		cout << setprecision(2) << "total winnings + bonus: $" << total << endl;}

	     if (timer < 8 && winner == 1){

		total += 500; // Add bonus amount
		buzz(2500); delay(25);
		buzz(1500); delay(25); buzz(750); delay(50);
		buzz(1000); delay(100); quiet();
		cout << first << ' ' << last << " Wins an extra $500.00 bonus for\n";
		cout << "Winning under 8 clicks!\n\n";
		cout << "Total winnings + bonus: $" << total << endl;}

		counter++; // Add one to counter

	     if (total >= 15000){

		cout << setprecision(2) << first << ' ' << last << " Takes home $" << total << endl;
		buzz(2500); delay(25);
		buzz(1500); delay(25); buzz(750); delay(50);
		buzz(1000); delay(100); quiet();
		cout << "                                    AND WINS THE GAME!\n\n\n";
		cout << "CLOCK: " << timer << endl;
		cout << "TOTAL WINNINGS: " << win << endl;
		cout << "TOTAL LOSSES: " << loser << endl;
		cout << "\nHit spacebar to exit..\n";
		getch();
		goto EndGame;}

      cout << "CLOCK: " << timer << " Clicks" << endl;
      cout << "----------------\n\n";

      cout << "WINNINGS: " << win << endl;
      cout << "LOSSES: " << loser << endl;

      cout << "\n\n\n"; // Space
      cout << "Would you like to start another race ?\n"; // Prompt for another game
      cout << "            (y or n) ";
      cin  >> start; // Read decision
      buzz(2500); delay(25); buzz(1500);
      buzz(750);
      quiet();

      if (toupper(start[0]) != 'N'){
	cout << "Place your bet, but not over your total amount: $"; // Prompt
	cin >> bet; // Read bet
	buzz(2500); delay(25); buzz(1500);
	buzz(750);
	quiet();

	while (bet > total){
	clrscr();
	  cout << "\n\n"; // Space
	  buzz(55); delay(25); buzz(rand() % 2500); buzz(100);
	  delay(25); buzz(1200); quiet();
		cout << "You fool.I told you not to place a higher bet than you can afford!\n";
		 cout << "Now place your bet, but not over your total amount: $";
		  cin >> bet;
		  buzz(2500); delay(25); buzz(1500);
		  buzz(750); quiet();}

	cout << "\n\n"; // Space

		 c:

	cout << "Now enter the ship you want to bet on\n"; // Prompt
	cout << "(1 for blue, or 2 for red) ";
	cin >> Ships;
	buzz(2500); delay(25); buzz(1500);
	buzz(750);
	quiet();


	if (Ships <= 0 || Ships > 2){
	clrscr();
	    cout << endl; // Space
	    buzz(55); delay(25); buzz(rand() % 2500); buzz(100);
	    delay(25); buzz(1200); quiet();
		cout << "There is only two ships to choose from!\n";
		goto c;}
					    sp2:
	cout << endl; // Space
	cout << "                      Set speed.\n"; // Prompt for speed
	cout << "                      (0, 1, 2, 3) ";
	cin >> speed; // Read speed
	buzz(2500); delay(25); buzz(1500);
	buzz(750);
	quiet();

	if (speed < 0 || speed >3){
	clrscr();
		cout << endl; // Space
		buzz(55); delay(25); buzz(rand() % 2500); buzz(100);
		delay(25); buzz(1200); quiet();
		cout << "                   NO NUMBERS OVER 3 OR UNDER 0!\n";
		goto sp2;}

	if (speed == 1)
		speed = 39999;

	if (speed == 2)
		speed = 59999;

	if (speed == 3)
		speed = 599999;


	cout << "\n\n"; // Space
	cout << "               Start race #" << counter << " ?"<< endl;
	cout << "                   (y or n) ";
	cin >> start;
	buzz(2500); delay(25); buzz(1500);
	buzz(750);
	quiet();}

      cout << "\n\n\n";} // Space

		EndGame:

	     pong(); lose();

   buzz(55); delay(25); buzz(rand() % 2500); buzz(100);
   delay(25); buzz(1200); quiet();

  cout << "\n\n"; // Space

  cout << "                         END OF THE RACES\n";
  cout << "                         ----------------\n\n";
  delay(1000);

  TextScreen();

return 0;


}

      void TimeDelay(double *xptr) // Function definition

     {

     for (double time = 0; time < *xptr; time++); // Body of function.

     }


     void race1 (int *aptr, int *bptr) // Function definition for blue.

     {

     int c1 = 0; // Declaration of "blue" output


	if (*aptr > 0 && *aptr > *bptr){

     for (int count = 1; count <= *aptr; count++){

	  stars();

	  Blue();

	  Red();

       if (blue1.ys2 <= 190) {
	 blue1.ys1++;
	 blue1.ys2++; }

       if (blue1.ys2 >= 190) {

	 blue1.xs1=13;
	 blue1.xs2=21;
	 blue1.ys1=18;
	 blue1.ys2=21;
	 blue1.px1=12;
	 blue1.px2=22;

      }


	 buzz(900); quiet();

	c1++;} // counter
	}

     }


     void race2 (int *bptr, int *aptr) // Function definition for red.

     {

     int c2 = 0; // Declaration of "red" output


	  if (*bptr > 0 && *bptr > *aptr){

     for (int count1 = 1; count1 <= *bptr; count1++){

	  stars();

	  Red();

	  Blue();

       if (red2.ys2 <= 190) {
	 red2.ys1++;
	 red2.ys2++; }

       if (red2.ys2 >= 190) {

       red2.xs1=300;
       red2.xs2=308;
       red2.ys1=18;
       red2.ys2=21;
       red2.px1=299;
       red2.px2=309;

       }


	buzz(900); quiet();

	c2++;} // counter
	}

     }