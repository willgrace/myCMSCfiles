// Color Square By Steven Ramponi


#include <iostream>
#include "Conlib.cpp"
#include <time.h>
#include <stdlib.h>

using namespace std;


struct Value { int OK; };




int main()
{
	Value Exit = { 0 }; 

	ConLib Con;

	int side, rowposition, size, counter;
	int I = 0;
	srand(time(0));

	Con.Clear();

	Con.SetTitle ("Color Square By Steven Ramponi");

	cout << "Enter The Amount Of Counts As An Integer You Want The Program To run To: ";
	cin >> int (counter);

    Con.Clear();

	while (++I < int (counter))
	{

		Con.Clear();

	side =  1 + rand() % 50; 


	size = side;

	while (side > 0)
	{
		rowposition = size;

		while (rowposition > 0)
		{
			if (size == side || side == 1 || rowposition == 1 || rowposition == size)
			{	Con.OutputString ( "*" );
			Con.SetTextColor (1 + rand() % 6); }
            else
			    Con.OutputString  ( " " );

			--rowposition;

		}

		cout << endl;
		--side;

	}
	}

Con.SetTextColor(7);

return (Exit.OK);

}

