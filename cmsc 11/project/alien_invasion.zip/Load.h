
/* CLass load by Steven Ramponi */

#ifndef LOAD_H
#define LOAD_H


#include "Black41.h"


// G L O B A L S ////////////////////////////////////////////////////////////

pcx_picture image_pcx; // Instance structure access,
		      //  image_pcx is of type pcx_picture.

 /* Instance objects, sprites are of type
  sprite.   */
sprite spaceship1, spaceship2, spaceship3, spaceship4, spaceship5,
spaceship6, spaceship7, spaceship8, spaceship9, spaceship10, spaceship11,
trans, alien1, alien2, alien3, alien4, alien5, alien6, 
alien7, alien8, alien9, alien10, alien11, alien12, alien13, alien14,
alien15, alien16, alien17, alien18, alien19, alien20, bomber, bomb,
explode, missle, missle2;

/////////////////////////////////////////////////////////////////////////////


class load 
{

public:
	load(void) // Constructor.
	{ x = 148; 
	  x2 = 152; 
	  y = 100; 
	  y2 = 100; 
	  x3 = 140;
	  y3 = 100;} 

	 ~load(void); // Destructor.

	 void load_aliens (void);
	 void transport (void);
	 void load_spaceships (void);
	 void load_background (void);
	 void Volcano (void);
	 void Bombs_Away (void);
	 void Explode (void);
	 void EXPLODE (void);
	 void MISSLE (void);
	 void MISSLE2 (void);

private:
	 unsigned short index;
	 short int x, x2, x3, y, y2, y3; 
};



void load::load_aliens (void)
{

	// Load alien one. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien1,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien1,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien two. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien2,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien2,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien three. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien3,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien3,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien four. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien4,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien4,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien five. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien5,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien5,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien six. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien6,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien6,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien seven. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien7,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien7,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien eight. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien8,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien8,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien nine. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien9,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien9,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien ten. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien10,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien10,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien eleven. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien11,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien11,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien twelve. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien12,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien12,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien thirteen. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien13,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien13,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien forteen. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien14,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien14,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien fifteen. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien15,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien15,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien sixteen. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien16,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien16,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien seventeen. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien17,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien17,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien eighteen. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien18,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien18,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien nineteen. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien19,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien19,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien twenty. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alienm.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien20,-100,-100,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien20,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


} // End of function. ////////////////////////////////////////////////////////



void load::transport (void)
{
	// load the imagery for the ship

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Ship.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the ship

Sprite_Init((sprite_ptr)&trans,400,30,40,10,0,0,0,0,0,0);

// extract the bitmaps for the ship, there are 4 animation cells

for (index=0; index<=4; index++)
    PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&trans,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);

} // End of function. /////////////////////////////////////////////////////////



void load::load_spaceships (void)
{

// load the imagery for spaceship one: 4 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Aship.pcx", (pcx_picture_ptr)&image_pcx,0);

Sprite_Init((sprite_ptr)&spaceship1,-100,0,14,8,0,0,0,0,0,0);

// extract the bitmaps, there are 4 animation cells.

for (index=0; index < 4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&spaceship1,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for spaceship two: 4 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Aship.pcx", (pcx_picture_ptr)&image_pcx,0);

Sprite_Init((sprite_ptr)&spaceship2,-100,0,14,8,0,0,0,0,0,0);

// extract the bitmaps, there are 4 animation cells.

for (index=0; index < 4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&spaceship2,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for spaceship three: 4 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Aship.pcx", (pcx_picture_ptr)&image_pcx,0);

Sprite_Init((sprite_ptr)&spaceship3,-100,0,14,8,0,0,0,0,0,0);

// extract the bitmaps, there are 4 animation cells.

for (index=0; index < 4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&spaceship3,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for spaceship four: 4 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Aship.pcx", (pcx_picture_ptr)&image_pcx,0);

Sprite_Init((sprite_ptr)&spaceship4,-100,0,14,8,0,0,0,0,0,0);

// extract the bitmaps, there are 4 animation cells.

for (index=0; index < 4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&spaceship4,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for spaceship five: 4 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Aship.pcx", (pcx_picture_ptr)&image_pcx,0);

Sprite_Init((sprite_ptr)&spaceship5,-100,0,14,8,0,0,0,0,0,0);

// extract the bitmaps, there are 4 animation cells.

for (index=0; index < 4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&spaceship5,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for spaceship six: 4 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Aship.pcx", (pcx_picture_ptr)&image_pcx,0);

Sprite_Init((sprite_ptr)&spaceship6,-100,0,14,8,0,0,0,0,0,0);

// extract the bitmaps, there are 4 animation cells.

for (index=0; index < 4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&spaceship6,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for spaceship seven: 4 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Aship.pcx", (pcx_picture_ptr)&image_pcx,0);

Sprite_Init((sprite_ptr)&spaceship7,-100,0,14,8,0,0,0,0,0,0);

// extract the bitmaps, there are 4 animation cells.

for (index=0; index < 4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&spaceship7,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for spaceship eight: 4 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Aship.pcx", (pcx_picture_ptr)&image_pcx,0);

Sprite_Init((sprite_ptr)&spaceship8,-100,0,14,8,0,0,0,0,0,0);

// extract the bitmaps, there are 4 animation cells.

for (index=0; index < 4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&spaceship8,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for spaceship nine: 4 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Aship.pcx", (pcx_picture_ptr)&image_pcx,0);

Sprite_Init((sprite_ptr)&spaceship9,-100,0,14,8,0,0,0,0,0,0);

// extract the bitmaps, there are 4 animation cells.

for (index=0; index < 4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&spaceship9,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for spaceship ten: 4 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Aship.pcx", (pcx_picture_ptr)&image_pcx,0);

Sprite_Init((sprite_ptr)&spaceship10,-100,0,14,8,0,0,0,0,0,0);

// extract the bitmaps, there are 4 animation cells.

for (index=0; index < 4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&spaceship10,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for spaceship eleven: 4 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Aship.pcx", (pcx_picture_ptr)&image_pcx,0);

Sprite_Init((sprite_ptr)&spaceship11,-100,0,14,8,0,0,0,0,0,0);

// extract the bitmaps, there are 4 animation cells.

for (index=0; index < 4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&spaceship11,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);

} // End of function. ////////////////////////////////////////////////////////



void load::load_background (void)
{

// now load the background

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Volcano.pcx",(pcx_picture_ptr)&image_pcx,1);

// copy PCX image to double buffer

PCX_Copy_To_Buffer((pcx_picture_ptr)&image_pcx,double_buffer);

// delete the pcx image

PCX_Delete((pcx_picture_ptr)&image_pcx);

} // End of function. /////////////////////////////////////////////////////////



void load::Bombs_Away (void)
{
	// load the imagery for bombs. //////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Tbombs.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the bombs.

Sprite_Init((sprite_ptr)&bomb,-30,-30,16,16,0,0,0,0,0,0);

// extract the bitmaps for the bombs, there are 4 animation cells

for (index=0; index<=4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&bomb,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for bomber one //////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("BOMBER.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the bomber spaceship.

Sprite_Init((sprite_ptr)&bomber,-75,20,18,15,0,0,0,0,0,0);

// extract the bitmaps for the enemy spaceship, there are 2 animation cells

for (index=0; index<2; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&bomber,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);

} // End of function. ////////////////////////////////////////////////////////



void load::EXPLODE (void)
{

	// load the imagery for the explosion there are 16 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Tank.pcx", (pcx_picture_ptr)&image_pcx,0);

// intialize the sprite

Sprite_Init((sprite_ptr)&explode,-15,-15,16,16,0,0,0,0,0,0);

// extract the bitmaps for the explosion, there are 3 animation cells for each
// direction thus 3 cells

for (index=0; index<3; index++)
    PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&explode,index,index,3);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);

} // End of function. /////////////////////////////////////////////////////////



void load::MISSLE (void)
{

// load the imagery for the missle. /////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Blazeshp.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the missle.

Sprite_Init((sprite_ptr)&missle,-200,40,22,18,0,0,0,0,0,0);

// extract the bitmaps for the missle, there are 12 animation cells

for (index=0; index<=12; index++)
    PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&missle,index,index,0);


// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);

} // End of function. /////////////////////////////////////////////////////////



void load::MISSLE2 (void)
{

// load the imagery for the second missle. /////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Blazeshp.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the missle.

Sprite_Init((sprite_ptr)&missle2,-100,-10,22,18,0,0,0,0,0,0);

// extract the bitmaps for the missle, there are 12 animation cells

for (index=0; index<=12; index++)
    PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&missle2,index,index,2);


// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);

} // End of function. ///////////////////////////////////////////////////////



void load::Explode (void)
{
	// Explode sequence. ///////////////////////////////////////////////////

 if (++explode.curr_frame > 2) {
  explode.curr_frame = 0;
  explode.x = -15;
  explode.y = -15; } // End if.

} // End of function. ///////////////////////////////////////////////////////



void load::Volcano (void)
{

	 if (y3 < 50) y=110;
     Write_Pixel (x, y-=2, 12);

     if (y < 80) y=100;
     Write_Pixel (x2, y-=3, 12);

	 if (y2 < 70) y2=105;
     Write_Pixel (x3, y--, 12);

} // End of function.
    

load::~load (void)
{
	Delete_Double_Buffer();
Sprite_Delete((sprite_ptr)&spaceship1);
Sprite_Delete((sprite_ptr)&spaceship2);
Sprite_Delete((sprite_ptr)&spaceship3);
Sprite_Delete((sprite_ptr)&spaceship4);
Sprite_Delete((sprite_ptr)&spaceship5);
Sprite_Delete((sprite_ptr)&spaceship6);
Sprite_Delete((sprite_ptr)&spaceship7);
Sprite_Delete((sprite_ptr)&spaceship8);
Sprite_Delete((sprite_ptr)&spaceship9);
Sprite_Delete((sprite_ptr)&spaceship10);
Sprite_Delete((sprite_ptr)&spaceship11);
Sprite_Delete((sprite_ptr)&trans);
Sprite_Delete((sprite_ptr)&alien1);
Sprite_Delete((sprite_ptr)&alien2);
Sprite_Delete((sprite_ptr)&alien3);
Sprite_Delete((sprite_ptr)&alien4);
Sprite_Delete((sprite_ptr)&alien5);
Sprite_Delete((sprite_ptr)&alien6);
Sprite_Delete((sprite_ptr)&alien7);
Sprite_Delete((sprite_ptr)&alien8);
Sprite_Delete((sprite_ptr)&alien9);
Sprite_Delete((sprite_ptr)&alien10);
Sprite_Delete((sprite_ptr)&alien11);
Sprite_Delete((sprite_ptr)&alien12);
Sprite_Delete((sprite_ptr)&alien13);
Sprite_Delete((sprite_ptr)&alien14);
Sprite_Delete((sprite_ptr)&alien15);
Sprite_Delete((sprite_ptr)&alien16);
Sprite_Delete((sprite_ptr)&alien17);
Sprite_Delete((sprite_ptr)&alien18);
Sprite_Delete((sprite_ptr)&alien19);
Sprite_Delete((sprite_ptr)&alien20);
Sprite_Delete((sprite_ptr)&bomber);
Sprite_Delete((sprite_ptr)&bomb);
Sprite_Delete((sprite_ptr)&explode);
Sprite_Delete((sprite_ptr)&missle);
Sprite_Delete((sprite_ptr)&missle2);

printf ("All sprites deleted. End of program..\n");

delay (2000);

} // End of destructor.


#endif
 