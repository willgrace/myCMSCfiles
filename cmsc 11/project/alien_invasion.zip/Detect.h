
/* Dectection class by Steven Ramponi */


#ifndef DETECT_H
#define DETECT_H


#include "Black41.h"
#include "Sound1.h"
#include "keys.h"
#include "Windate.h"


class Collide 
{

public:

	Collide (int); // Constructor.
	~Collide (void); // Destructor.

    
	int XOUT (int, int, int, int);

	char *name;


private:

	unsigned short size;

};


Collide::Collide (int input)
{
   size = input <= 10 ? input : 10;

   name = new char [size];

   puts ("            *** Welcome to Alien Invasion by Steven Ramponi ***\n\n");

   win();

   Date2(); // Function call from windate.h

   printf ("\n\n\n\nInput your nickname: ");
   scanf ("%s", name);

} // End of constructor.


Collide::~Collide (void)
{
	delete [] name;

                name = NULL;

	printf ("\n\nAllocated run time memory deleted..\n");

	delay (2000);

} // End of destructor.
   

int Collide::XOUT (int px, int py, int objx, int objy)
{

if (px >= objx - 20 && px <= objx + 20)
    if (py >= objy - 20 && py <= objy +20) return TRUE;

    return FALSE;

} // End of function.

     

#endif