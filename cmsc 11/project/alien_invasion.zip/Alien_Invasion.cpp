
/* Alien Invasion by Steven Ramponi */


// I N C L U D E S /////////////////////////////////////////

#include <iomanip.h>
#include <iostream.h>
#include <fstream.h>
#include <conio.h>
#include "Black41.h"
#include "Load.h"
#include "Sound1.h"
#include "Struc.h"
#include "keys.h"
#include "Detect.h"
#include "Death.h"
#include "Delay.h"

// S T R U C T U R E S ////////////////////////////////////

struct sprite_type
{
bool SUP;
bool dead;
};

 sprite_type Spaceship1 = { FALSE, FALSE }; // Set structure variables.


 struct sprite_type2
 {
   bool dead; // Alien in or out of game.
   bool set_cord; // Hold x value boolean.
   bool rein; // Ship reinstate boolean.
   bool drop, once; // When to drop spaceship variable.
   bool UP1; // Send ships up variable.
   unsigned short hold; //Hold alien's x position.
 };

  // Instance objects.
 // Aliens are of type sprite_type2.
 sprite_type2 Trans, SpaceShip2, SpaceShip3, SpaceShip4, SpaceShip5,
 SpaceShip6, SpaceShip7, SpaceShip8, SpaceShip9, SpaceShip10, SpaceShip11,
 Alien1, Alien2, Alien3, Alien4, Alien5, Alien6, Alien7, Alien8,
 Alien9, Alien10, Alien11, Alien12, Alien13, Alien14, Alien15, Alien16,
 Alien17, Alien18, Alien19, Alien20, Bomb, Bomber, Missle, Missle2,
 Building1, Gun, Bullet1;

// G L O B A L S /////////////////////////////////////////

 // Speed of game & x coordinates of spites.
unsigned short cord, cord2;


// Collision is of type Collide class access instance object.
Collide Collision(10);

final course; // Course is of type final class access instance object.



bool Next_Level = FALSE; // Declaration of next level boolean variable.

bool LAND = FALSE; // Declaration of alien land detection.

float count2 = 0; // Time of each level.

unsigned long score = 0; // Score value declaration.
char buffer[14];


 ofstream outClientFile( "Ascore.dat", ios::app );
 ifstream inClientFile( "Ascore.dat", ios::in );


// P R O T O T Y P E S ///////////////////////////////////////

void ship1_move (void);
void ship11_move (void);
void ships2_move (void);
void ships3_move (void);
void ships4_move (void);
void ships5_move (void);
void ships6_move (void);
void ships7_move (void);
void ships8_move (void);
void ships9_move (void);
void ships10_move (void);
void trans_ship (void);
void reinstate_ship1 (void);
void reinstate_ship11 (void);
void Alien1_Land (void);
void Alien2_Land (void);
void Alien3_Land (void);
void Alien4_Land (void);
void Alien5_Land (void);
void Alien6_Land (void);
void Alien16_Land (void);
void Alien17_Land (void);
void Alien18_Land (void);
void Alien19_Land (void);
void Alien20_Land (void);
void bomber_one (void);
void drop_bomb (void);
void drop_missle (void);
void drop_missle2 (void);
void buildingd (void);
void instruct (void);
void Levels (void);
void reset_level1 (void);
void reset_level2 (void);
void reset_level4 (void);
void reset_level5 (void);
void points (void);
void outputLine ( char*, long );
int fileout (void);
int filein (void);
void AddScore (int);

// M A I N ///////////////////////////////////////////////////

int main (void) // Control module.
{

char again; // Declaration of replay.

int inputOK = 0;
int outputOK = 0;


load loading; // loading is of type load class access instance object.

build make; // Make is of type build class access instance object.

count counting; // Counting is of type count class access instance object.


 instruct(); // Instruction function call.


 Set_Graphics_Mode(GRAPHICS_MODE13);

 setborderc (10);

 course.set_speed(); // Set speed function call from death.h

 Set_Graphics_Mode(GRAPHICS_MODE13);

 setborderc (12);


    Print_String (115, 115, 12, "GET READY !!", 0);
     win();
     counting.Show_Delay (4); // Function call from Delay.h.


srand(time(NULL)); // Seed the random functions.

Set_Graphics_Mode(GRAPHICS_MODE13);


start: // Goto start position.


Create_Double_Buffer(200);

 // Function calls from class Load.h.
loading.load_aliens();
loading.load_spaceships();
loading.load_background();
loading.transport();
loading.EXPLODE();
loading.Bombs_Away();
loading.MISSLE();
loading.MISSLE2();

// Function calls from class Struc.h
make.foundation();
make.gunner();
make.InsertBullet();

// Function calls from class Death.h
course.load_blood();

// Set sprites. /////////////////////////////////////////////////////////////// 

missle.curr_frame = 4; // Set missle facing east.
missle2.curr_frame = 8; // Set missle two down.

 cord = 5 + random(295); // Set spaceship one x value.
 cord2 = 10 + random(290); // Set spaceship eleven x value.

 spaceship1.x = cord;   ///////////////////////////
 spaceship11.x = cord2;   ///////////////////////////

///////////////////////////////////////////////////////////////////////////////


// scan under sprites before entering the event loop, this must be
// done or else on the first cycle the "erase" function will draw garbage.

Sprite_Under_Clip((sprite_ptr)&spaceship1,double_buffer);
Sprite_Under_Clip((sprite_ptr)&spaceship11,double_buffer);
Sprite_Under_Clip((sprite_ptr)&spaceship2,double_buffer);
Sprite_Under_Clip((sprite_ptr)&spaceship3,double_buffer);
Sprite_Under_Clip((sprite_ptr)&spaceship4,double_buffer);
Sprite_Under_Clip((sprite_ptr)&spaceship5,double_buffer);
Sprite_Under_Clip((sprite_ptr)&spaceship6,double_buffer);
Sprite_Under_Clip((sprite_ptr)&spaceship7,double_buffer);
Sprite_Under_Clip((sprite_ptr)&spaceship8,double_buffer);
Sprite_Under_Clip((sprite_ptr)&spaceship9,double_buffer);
Sprite_Under_Clip((sprite_ptr)&spaceship10,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien1,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien2,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien3,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien4,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien5,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien6,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien7,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien8,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien9,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien10,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien11,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien12,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien13,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien14,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien15,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien16,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien17,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien18,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien19,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien20,double_buffer);
Sprite_Under_Clip((sprite_ptr)&bomber,double_buffer);
Sprite_Under_Clip((sprite_ptr)&bomb,double_buffer);
Sprite_Under_Clip((sprite_ptr)&explode,double_buffer);
Sprite_Under_Clip((sprite_ptr)&trans,double_buffer);
Sprite_Under_Clip((sprite_ptr)&missle,double_buffer);
Sprite_Under_Clip((sprite_ptr)&missle2,double_buffer);
Sprite_Under_Clip((sprite_ptr)&building1,double_buffer);
Sprite_Under_Clip((sprite_ptr)&gun,double_buffer);
Sprite_Under_Clip((sprite_ptr)&bullet1,double_buffer);
Sprite_Under_Clip((sprite_ptr)&blood,double_buffer);


while (!make.Done) {

points(); // Points function call.

   if (LAND || Building1.dead)
     if (++count2 > 500) {
     end();
     gotoxy (15, 10);
     puts ("GAME OVER");
     delay (3500);
     make.Done = TRUE; } // End if.


 loading.Volcano(); // Volcano class function call.

 make.barrel(); // Barrel class movement function call.


if (course.level == 0 || Next_Level) {

course.LEVEL(); //  Level set function call from death.h
Next_Level = FALSE;

 } // End if.


  if (course.level == 1 && (count2+=1) > 800) {
  Levels();
  reset_level1(); } // End if.

  if (course.level == 2 && (count2+=1) > 1000) {
  Levels();
  reset_level1();
  reset_level2(); } // End if.

  if (course.level == 3 && (count2+=1) > 1000) {
  Levels();
  reset_level1();
  reset_level2(); } // End if.

  if (course.level == 4 && (count2+=1) > 1000) {
  Levels();
  reset_level1();
  reset_level2();
  reset_level4(); } // End if.

  if (course.level == 5 && (count2+=1) > 1200) {
  Levels();
  reset_level1();
  reset_level2();
  reset_level4();
  reset_level5(); } // End if.

  if (course.level == 6 && (count2+=1) > 1500) {
  Levels();
  reset_level1();
  reset_level2();
  reset_level4();
  reset_level5();  } // End if.

  if (course.level > 6 && (count2+=1) > 2000) {
   Levels();
   reset_level1();
   reset_level2();
   reset_level4();
   reset_level5();
   if (--course.timer < 25) course.timer = 25; } // End if.


 // Start animation cycle, erase draw.
 Sprite_Erase_Clip ((sprite_ptr)&spaceship1, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&spaceship11, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&spaceship2, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&spaceship3, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&spaceship4, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&spaceship5, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&spaceship6, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&spaceship7, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&spaceship8, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&spaceship9, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&spaceship10, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien1, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien2, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien3, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien4, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien5, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien6, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien7, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien8, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien9, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien10, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien11, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien12, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien13, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien14, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien15, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien16, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien17, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien18, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien19, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&alien20, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&bomber, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&bomb, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&explode, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&trans, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&missle, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&missle2, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&building1, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&gun, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&bullet1, double_buffer);

  buildingd(); // Building destroy function call.

 // Spaceships movement function calls ///////////////////////

  if (!Spaceship1.dead) ship1_move();
  if (Spaceship1.dead) reinstate_ship1();


  if (!SpaceShip11.dead) ship11_move();
  if (SpaceShip11.dead) reinstate_ship11();


  trans_ship(); // Transport ship function call.


 if (course.level >= 1) {

   Alien1_Land();
   Alien2_Land();
   Alien3_Land();
   Alien4_Land();
   Alien5_Land();
   Alien6_Land();
   Alien16_Land();
   Alien17_Land();
   Alien18_Land();
   Alien19_Land();
   Alien20_Land();

  ships2_move(); // Ships on transport.
  ships3_move(); //////////////////////
  ships4_move(); //////////////////////

 } // End if.


 if (course.level >= 2) {

  ships5_move(); //////////////////////
  ships6_move(); //////////////////////

  } // End if.


  if (course.level >= 3) {

  bomber_one(); // Bomber function calls.
  drop_bomb(); /////////////////////////

  } // End if.


 if (course.level >= 4) {

  drop_missle2(); // second missle function call.
  ships7_move(); //////////////////////
  ships8_move(); //////////////////////

  } // End if.


 if (course.level >=  5) {

  ships9_move(); //////////////////////
  ships10_move(); //////////////////////

  } // End if.


 if (course.level >= 6) {

  drop_missle(); // missle function call.

   } // End if.


  loading.Explode(); // Class load.h function call.

 //////////////////////////////////////////////////////////////

 Sprite_Under_Clip ((sprite_ptr)&spaceship1, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&spaceship11, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&spaceship2, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&spaceship3, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&spaceship4, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&spaceship5, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&spaceship6, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&spaceship7, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&spaceship8, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&spaceship9, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&spaceship10, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien1, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien2, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien3, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien4, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien5, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien6, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien7, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien8, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien9, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien10, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien11, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien12, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien13, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien14, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien15, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien16, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien17, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien18, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien19, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&alien20, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&bomber, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&bomb, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&explode, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&trans, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&missle, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&missle2, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&building1, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&gun, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&bullet1, double_buffer);
 Sprite_Under_Clip ((sprite_ptr)&blood, double_buffer);


 Sprite_Draw_Clip ((sprite_ptr)&spaceship1, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&spaceship11, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&spaceship2, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&spaceship3, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&spaceship4, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&spaceship5, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&spaceship6, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&spaceship7, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&spaceship8, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&spaceship9, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&spaceship10, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien1, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien2, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien3, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien4, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien5, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien6, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien7, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien8, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien9, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien10, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien11, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien12, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien13, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien14, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien15, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien16, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien17, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien18, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien19, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&alien20, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&bomber, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&bomb, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&explode, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&trans, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&missle, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&missle2, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&building1, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&gun, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&bullet1, double_buffer, 1);
 Sprite_Draw_Clip ((sprite_ptr)&blood, double_buffer, 1);


  Display_Double_Buffer(double_buffer,0);

 delay (course.timer);  // Game speed function.

 } // end of main header while.


Print_String (5, 170, 16, "Do you wish to try your luck again ?", 0);

 do {
 again = getch(); ship();
 } while (again != 'y' && again != 'n');


 if (again == 'y') {

     score = 0;
     count2 = 0;
     reset_level1();
     reset_level2();
     reset_level4();
     reset_level5();
     course.level = 0;
     make.Done = FALSE;
     Building1.dead = FALSE;
     building1.curr_frame = 0;
     LAND = FALSE;
     gun.x = 150;
     gun.y = 145;

	 Delete_Double_Buffer();
Sprite_Delete((sprite_ptr)&spaceship1);
Sprite_Delete((sprite_ptr)&spaceship2);
Sprite_Delete((sprite_ptr)&spaceship3);
Sprite_Delete((sprite_ptr)&spaceship4);
Sprite_Delete((sprite_ptr)&spaceship5);
Sprite_Delete((sprite_ptr)&spaceship6);
Sprite_Delete((sprite_ptr)&spaceship7);
Sprite_Delete((sprite_ptr)&spaceship8);
Sprite_Delete((sprite_ptr)&spaceship9);
Sprite_Delete((sprite_ptr)&spaceship10);
Sprite_Delete((sprite_ptr)&spaceship11);
Sprite_Delete((sprite_ptr)&trans);
Sprite_Delete((sprite_ptr)&alien1);
Sprite_Delete((sprite_ptr)&alien2);
Sprite_Delete((sprite_ptr)&alien3);
Sprite_Delete((sprite_ptr)&alien4);
Sprite_Delete((sprite_ptr)&alien5);
Sprite_Delete((sprite_ptr)&alien6);
Sprite_Delete((sprite_ptr)&alien7);
Sprite_Delete((sprite_ptr)&alien8);
Sprite_Delete((sprite_ptr)&alien9);
Sprite_Delete((sprite_ptr)&alien10);
Sprite_Delete((sprite_ptr)&alien11);
Sprite_Delete((sprite_ptr)&alien12);
Sprite_Delete((sprite_ptr)&alien13);
Sprite_Delete((sprite_ptr)&alien14);
Sprite_Delete((sprite_ptr)&alien15);
Sprite_Delete((sprite_ptr)&alien16);
Sprite_Delete((sprite_ptr)&alien17);
Sprite_Delete((sprite_ptr)&alien18);
Sprite_Delete((sprite_ptr)&alien19);
Sprite_Delete((sprite_ptr)&alien20);
Sprite_Delete((sprite_ptr)&bomber);
Sprite_Delete((sprite_ptr)&bomb);
Sprite_Delete((sprite_ptr)&explode);
Sprite_Delete((sprite_ptr)&missle);
Sprite_Delete((sprite_ptr)&missle2);
Sprite_Delete((sprite_ptr)&blood);
Sprite_Delete((sprite_ptr)&building1);
Sprite_Delete((sprite_ptr)&gun);
Sprite_Delete((sprite_ptr)&bullet1);


Screen_Transition(SCREEN_DISOLVE);

     pong();

     goto start;

    } // End if.


   Screen_Transition(SCREEN_SWIPE_X);

     pong();

     setborderc (random(256));

	 if (course.level >= 6) {

 printf("\n       *****NAMES AND SCORES*****\n");

     puts ("\n\n"); // Space.

     outputOK = fileout();
	
     if (outputOK == 0) { inputOK = filein(); }

     cout << "\n\n Game time: " << setiosflags(ios::showpoint) <<
     setprecision(2) << clock()/CLOCKS_PER_SEC/60 << " minutes.";

     } // End if.


   else {

    end();

    cout << " Game time: " << setiosflags(ios::showpoint) <<
    setprecision(2) << clock()/CLOCKS_PER_SEC/60 << " minutes.";

    delay (1500);

    AddScore (score); // Function call.

    } // End else.


     puts ("\n\n\n Hit any key to exit..");

	 getch();


Screen_Transition(SCREEN_DARKNESS);
Set_Graphics_Mode(TEXT_MODE);

return (inputOK && outputOK);

} // End of program.

// END OF MAIN /////////////////////////////////////////////////

// Functions //////////////////////////////////////////////////

 void ship1_move (void)
 {

 if (++spaceship1.curr_frame > 3) spaceship1.curr_frame = 0;

 if (!Spaceship1.SUP)
  if ((spaceship1.y+=2) > 170) { Spaceship1.SUP = TRUE; LAND = TRUE; }

if (Collision.XOUT (spaceship1.x, spaceship1.y, bullet1.x, bullet1.y) == TRUE) {
hit();
explode.x = spaceship1.x;
explode.y = spaceship1.y;
spaceship1.x = -100;
spaceship1.y = -100;
Spaceship1.dead = TRUE;
score+=100;

} // End if.

 if (Spaceship1.SUP && !Spaceship1.dead)
   if (--spaceship1.y > -5)
     if ((spaceship1.x-=7) < -5) {
    spaceship1.x = -100;
    spaceship1.y = -100;
    Spaceship1.SUP = FALSE;
    Spaceship1.dead = TRUE; } // End if.

 } // End of function.


 void ship11_move (void)
 {

 if (++spaceship11.curr_frame > 3) spaceship11.curr_frame = 0;

 if (!SpaceShip11.UP1)
  if ((spaceship11.y+=2) > 170) { SpaceShip11.UP1 = TRUE; LAND = TRUE; }

if (Collision.XOUT (spaceship11.x, spaceship11.y, bullet1.x, bullet1.y) == TRUE) {
hit();
explode.x = spaceship11.x;
explode.y = spaceship11.y;
spaceship11.x = -100;
spaceship11.y = -100;
SpaceShip11.dead = TRUE;
score+=100;

} // End if.

 if (SpaceShip11.UP1 && !SpaceShip11.dead)
   if (--spaceship11.y > -5)
     if ((spaceship11.x-=7) < -5) {
    spaceship11.x = -100;
    spaceship11.y = -100;
    SpaceShip11.UP1 = FALSE;
    SpaceShip11.dead = TRUE; } // End if.

 } // End of function.


 void trans_ship (void)
 {
      if (Trans.dead) {
	if (1+rand() %25 == 10) {
	key_tap();
	Trans.dead = FALSE;

	} // End if.
      }  //  End if.

      // Set spaceship#.dead = FALSE;
      // Set coordinates to negative numbers,
      // should continue game.

    if (!Trans.dead) {
    space();
     if ((trans.x-=3) < -100) { trans.x = 400; Trans.dead = TRUE; } // End if.
     if ((trans.curr_frame+=2) > 3) trans.curr_frame = 0;

if (Collision.XOUT (trans.x, trans.y, bullet1.x, bullet1.y) == TRUE) {
hit();
Trans.dead = TRUE;
explode.x = trans.x;
explode.y = trans.y;
score+=75;
trans.x = -100;  } // End if.

     } // End if.

 } // End of function.


 void reinstate_ship1 (void)
 {
    cord = 5 + random(295);

 // When alien shot: Alien2.rein = FALSE;
 // Set alien coordinates to negative numbers.
 // Set Alien2.set_cord = FALSE; will continue game.

    spaceship1.x = cord;
     // Pick-up aliens boolean.
  if (alien1.y >= 173 || Spaceship1.dead)
   { Spaceship1.dead = FALSE; Alien2.rein = TRUE; }

  if (alien2.y >= 173 || Spaceship1.dead)
   { Spaceship1.dead = FALSE; Alien3.rein = TRUE; }

  if (alien3.y >= 173 || Spaceship1.dead)
   { Spaceship1.dead = FALSE; Alien4.rein = TRUE; }

  if (alien4.y >= 173 || Spaceship1.dead)
   { Spaceship1.dead = FALSE; Alien5.rein = TRUE; }

  if (alien5.y >= 173 || Spaceship1.dead)
  { Spaceship1.dead = FALSE; Alien6.rein = TRUE; }

  if (alien6.y >= 173 || Spaceship1.dead) Spaceship1.dead = TRUE;

  } // End of function.


void reinstate_ship11 (void)
 {
    cord2 = 10 + random(290);

 // When alien shot: Alien17.rein = FALSE;
 // Set alien coordinates to negative numbers.
 // Set Alien17.set_cord = FALSE; will continue game.

    spaceship11.x = cord2;
     // Pick-up aliens boolean.
  if (alien16.y >= 173 || SpaceShip11.dead)
   { SpaceShip11.dead = FALSE; Alien17.rein = TRUE; }

  if (alien17.y >= 173 || SpaceShip11.dead)
   { SpaceShip11.dead = FALSE; Alien18.rein = TRUE; }

  if (alien18.y >= 173 || SpaceShip11.dead)
   { SpaceShip11.dead = FALSE; Alien19.rein = TRUE; }

  if (alien19.y >= 173 || SpaceShip11.dead)
   { SpaceShip11.dead = FALSE; Alien20.rein = TRUE; }

   if (alien20.y >= 173 || SpaceShip11.dead) SpaceShip11.dead = TRUE;

  } // End of function.


 void Alien1_Land (void)
 {

  if (!Alien1.set_cord) { Alien1.hold = cord; Alien1.set_cord = TRUE; }

  if (alien1.y < 175) {
    alien1.x = spaceship1.x+3;
    alien1.y = spaceship1.y+8;
    alien1.curr_frame = 15; } // End if.
  else {
    alien1.x = Alien1.hold;
    alien1.y = 176;
    } // End else.

  } // End of function.


 void Alien16_Land (void)
 {

  if (!Alien16.set_cord) { Alien16.hold = cord2; Alien16.set_cord = TRUE; }

  if (alien16.y < 175) {
    alien16.x = spaceship11.x+3;
    alien16.y = spaceship11.y+8;
    alien16.curr_frame = 15; } // End if.
  else {
    alien16.x = Alien16.hold;
    alien16.y = 176;
    } // End else.

  } // End of function.


 void Alien17_Land (void)
 {

 if (Alien17.rein) {

  if (!Alien17.set_cord) { Alien17.hold = cord2; Alien17.set_cord = TRUE; }

  if (alien17.y < 175) {
    alien17.x = spaceship11.x+3;
    alien17.y = spaceship11.y+8;
    alien17.curr_frame = 15; } // End if.
  else {
    alien17.x = Alien17.hold;
    alien17.y = 176;
    } // End else.
  } // End if.

  } // End of function.


 void Alien18_Land (void)
 {

 if (Alien18.rein) {

  if (!Alien18.set_cord) { Alien18.hold = cord2; Alien18.set_cord = TRUE; }

  if (alien18.y < 175) {
    alien18.x = spaceship11.x+3;
    alien18.y = spaceship11.y+8;
    alien18.curr_frame = 15; } // End if.
  else {
    alien18.x = Alien18.hold;
    alien18.y = 176;
    } // End else.
  } // End if.

  } // End of function.


 void Alien19_Land (void)
 {

 if (Alien19.rein) {

  if (!Alien19.set_cord) { Alien19.hold = cord2; Alien19.set_cord = TRUE; }

  if (alien19.y < 175) {
    alien19.x = spaceship11.x+3;
    alien19.y = spaceship11.y+8;
    alien19.curr_frame = 15; } // End if.
  else {
    alien19.x = Alien19.hold;
    alien19.y = 176;
    } // End else.
  } // End if.

  } // End of function.


 void Alien20_Land (void)
 {
 if (Alien20.rein) {

  if (!Alien20.set_cord) { Alien20.hold = cord2; Alien20.set_cord = TRUE; }

  if (alien20.y < 175) {
    alien20.x = spaceship11.x+3;
    alien20.y = spaceship11.y+8;
    alien20.curr_frame = 15; } // End if.
  else {
    alien20.x = Alien20.hold;
    alien20.y = 176;
    } // End else.
  } // End if.

  } // End of function.


 void Alien2_Land (void)
 {

if (Alien2.rein) {

  if (!Alien2.set_cord) { Alien2.hold = cord; Alien2.set_cord = TRUE; }

  if (alien2.y < 175) {
    alien2.x = spaceship1.x+3;
    alien2.y = spaceship1.y+8;
    alien2.curr_frame = 15; } // End if.
  else {
    alien2.x = Alien2.hold;
    alien2.y = 176;
    } // End else.
  } // End if.

  } // End of function.


 void Alien3_Land (void)
 {

if (Alien3.rein) {

  if (!Alien3.set_cord) { Alien3.hold = cord; Alien3.set_cord = TRUE; }

  if (alien3.y < 175) {
    alien3.x = spaceship1.x+3;
    alien3.y = spaceship1.y+8;
    alien3.curr_frame = 15; } // End if.
  else {
    alien3.x = Alien3.hold;
    alien3.y = 176;
    } // End else.
  } // End if.

  } // End of function.


void Alien4_Land (void)
 {

if (Alien4.rein) {

  if (!Alien4.set_cord) { Alien4.hold = cord; Alien4.set_cord = TRUE; }

  if (alien4.y < 175) {
    alien4.x = spaceship1.x+3;
    alien4.y = spaceship1.y+8;
    alien4.curr_frame = 15; } // End if.
  else {
    alien4.x = Alien4.hold;
    alien4.y = 176;
    } // End else.
  } // End if.

  } // End of function.


 void Alien5_Land (void)
 {

if (Alien5.rein) {

  if (!Alien5.set_cord) { Alien5.hold = cord; Alien5.set_cord = TRUE; }

  if (alien5.y < 175) {
    alien5.x = spaceship1.x+3;
    alien5.y = spaceship1.y+8;
    alien5.curr_frame = 15; } // End if.
  else {
    alien5.x = Alien5.hold;
    alien5.y = 176;
    } // End else.
  } // End if.

  } // End of function.


void Alien6_Land (void)
 {

if (Alien6.rein) {

  if (!Alien6.set_cord) { Alien6.hold = cord; Alien6.set_cord = TRUE; }

  if (alien6.y < 175) {
    alien6.x = spaceship1.x+3;
    alien6.y = spaceship1.y+8;
    alien6.curr_frame = 15; } // End if.
  else {
    alien6.x = Alien6.hold;
    alien6.y = 176;
    } // End else.
  } // End if.

  } // End of function.


void ships2_move (void)
{

 if (!SpaceShip2.drop && !SpaceShip2.dead)
 {
   spaceship2.x = trans.x;
   spaceship2.y = trans.y;

   if (1+rand() %25 == 10 && trans.x < 250 && trans.x > 50) {
   key_tap();
   SpaceShip2.drop = TRUE;

   } // End if.

 } // End if.

 if (SpaceShip2.drop)
 {

 if (++spaceship2.curr_frame > 3) spaceship2.curr_frame = 0;


if (Collision.XOUT (spaceship2.x, spaceship2.y, bullet1.x, bullet1.y) == TRUE
&& !Trans.dead) {
hit();
explode.x = spaceship2.x;
explode.y = spaceship2.y;
spaceship2.x = -100;
spaceship2.y = -100;
SpaceShip2.dead = TRUE;
Alien7.dead = TRUE;
score+=100;

} // End if.

if (Alien7.dead) {
if (++alien7.curr_frame > 15) alien7.curr_frame = 0;
 if ((alien7.y+=10) >= 175) {
blood.x = alien7.x;
blood.y = alien7.y;
blood.curr_frame = 4;
alien7.x = -100;
alien7.y = -100;

  } // End if.
} // End if.


 if (!SpaceShip2.UP1 && !Alien7.dead) {
 Alien7.hold = alien7.x = spaceship2.x+3;
 alien7.y = spaceship2.y+8;
 alien7.curr_frame = 15;

  if ((spaceship2.y+=2) > 170 && !Alien7.dead) {
  LAND = TRUE;
   SpaceShip2.UP1 = TRUE;
   alien7.x = Alien7.hold;
   alien7.y = 175; } // End if.

  } // End if spaceship2 up if.

 if (SpaceShip2.UP1)
   if (--spaceship2.y > -5)
     if ((spaceship2.x-=7) < -5) {
    spaceship2.x = -50;
    spaceship2.y = -50;
    SpaceShip2.UP1 = FALSE;
    SpaceShip2.drop = FALSE;
    SpaceShip2.dead = TRUE; } // End if.

    } // End if.

} // End of function.


void ships3_move (void)
{

 if (!SpaceShip3.drop && !SpaceShip3.dead)
 {
   spaceship3.x = trans.x;
   spaceship3.y = trans.y;

   if (1+rand() %25 == 10 && trans.x < 250 && trans.x > 50 &&
     alien7.y > 50) {

   key_tap();
   SpaceShip3.drop = TRUE;

   } // End if.

 } // End if.

 if (SpaceShip3.drop)
 {

 if (++spaceship3.curr_frame > 3) spaceship3.curr_frame = 0;

if (Collision.XOUT (spaceship3.x, spaceship3.y, bullet1.x, bullet1.y) == TRUE
&& !Trans.dead) {
hit();
explode.x = spaceship3.x;
explode.y = spaceship3.y;
spaceship3.x = -100;
spaceship3.y = -100;
SpaceShip3.dead = TRUE;
Alien8.dead = TRUE;
score+=100;

} // End if.

if (Alien8.dead) {
if (++alien8.curr_frame > 15) alien8.curr_frame = 0;
 if ((alien8.y+=10) >= 175) {
blood.x = alien8.x;
blood.y = alien8.y;
blood.curr_frame = 4;
alien8.x = -100;
alien8.y = -100;

  } // End if.
} // End if.


 if (!SpaceShip3.UP1 && !Alien8.dead) {
 Alien8.hold = alien8.x = spaceship3.x+3;
 alien8.y = spaceship3.y+8;
 alien8.curr_frame = 15;

  if ((spaceship3.y+=2) > 170 && !Alien8.dead) {
  LAND = TRUE;
   SpaceShip3.UP1 = TRUE;
   alien8.x = Alien8.hold;
   alien8.y = 175; } // End if.

  } // End if spaceship2 up if.

 if (SpaceShip3.UP1)
   if (--spaceship3.y > -5)
     if ((spaceship3.x-=7) < -5) {
    spaceship3.x = -50;
    spaceship3.y = -50;
    SpaceShip3.UP1 = FALSE;
    SpaceShip3.drop = FALSE;
    SpaceShip3.dead = TRUE; } // End if.

    } // End if.

} // End of function.


void ships4_move (void)
{

 if (!SpaceShip4.drop && !SpaceShip4.dead)
 {
   spaceship4.x = trans.x;
   spaceship4.y = trans.y;

   if (1+rand() %25 == 10 && trans.x < 250 && trans.x > 50 &&
     alien8.y > 50) {

   key_tap();
   SpaceShip4.drop = TRUE;

   } // End if.

 } // End if.

 if (SpaceShip4.drop)
 {

 if (++spaceship4.curr_frame > 3) spaceship4.curr_frame = 0;

if (Collision.XOUT (spaceship4.x, spaceship4.y, bullet1.x, bullet1.y) == TRUE
&& !Trans.dead) {
hit();
explode.x = spaceship4.x;
explode.y = spaceship4.y;
spaceship4.x = -100;
spaceship4.y = -100;
SpaceShip4.dead = TRUE;
Alien9.dead = TRUE;
score+=100;

} // End if.

if (Alien9.dead) {
if (++alien9.curr_frame > 15) alien9.curr_frame = 0;
 if ((alien9.y+=10) >= 175) {
blood.x = alien9.x;
blood.y = alien9.y;
blood.curr_frame = 4;
alien9.x = -100;
alien9.y = -100;

  } // End if.
} // End if.

 if (!SpaceShip4.UP1 && !Alien9.dead) {
 Alien9.hold = alien9.x = spaceship4.x+3;
 alien9.y = spaceship4.y+8;
 alien9.curr_frame = 15;

  if ((spaceship4.y+=2) > 170 && !Alien9.dead) {
  LAND = TRUE;
   SpaceShip4.UP1 = TRUE;
   alien9.x = Alien9.hold;
   alien9.y = 175; } // End if.

  } // End if spaceship2 up if.

 if (SpaceShip4.UP1)
   if (--spaceship4.y > -5)
     if ((spaceship4.x-=7) < -5) {
    spaceship4.x = -50;
    spaceship4.y = -50;
    SpaceShip4.UP1 = FALSE;
    SpaceShip4.drop = FALSE;
    SpaceShip4.dead = TRUE; } // End if.

    } // End if.

} // End of function.


void ships5_move (void)
{

 if (!SpaceShip5.drop && !SpaceShip5.dead)
 {
   spaceship5.x = trans.x;
   spaceship5.y = trans.y;

   if (1+rand() %25 == 10 && trans.x < 250 && trans.x > 50 &&
     alien9.y > 50) {

   key_tap();
   SpaceShip5.drop = TRUE;

   } // End if.

 } // End if.

 if (SpaceShip5.drop)
 {

 if (++spaceship5.curr_frame > 3) spaceship5.curr_frame = 0;

if (Collision.XOUT (spaceship5.x, spaceship5.y, bullet1.x, bullet1.y) == TRUE
&& !Trans.dead) {
hit();
explode.x = spaceship5.x;
explode.y = spaceship5.y;
spaceship5.x = -100;
spaceship5.y = -100;
SpaceShip5.dead = TRUE;
Alien10.dead = TRUE;
score+=100;

} // End if.

if (Alien10.dead) {
if (++alien10.curr_frame > 15) alien10.curr_frame = 0;
 if ((alien10.y+=10) >= 175) {
blood.x = alien10.x;
blood.y = alien10.y;
blood.curr_frame = 4;
alien10.x = -100;
alien10.y = -100;

  } // End if.
} // End if.

 if (!SpaceShip5.UP1 && !Alien10.dead) {
 Alien10.hold = alien10.x = spaceship5.x+3;
 alien10.y = spaceship5.y+8;
 alien10.curr_frame = 15;

  if ((spaceship5.y+=2) > 170 && !Alien10.dead) {
  LAND = TRUE;
   SpaceShip5.UP1 = TRUE;
   alien10.x = Alien10.hold;
   alien10.y = 175; } // End if.

  } // End if spaceship2 up if.

 if (SpaceShip5.UP1)
   if (--spaceship5.y > -5)
     if ((spaceship5.x-=7) < -5) {
    spaceship5.x = -50;
    spaceship5.y = -50;
    SpaceShip5.UP1 = FALSE;
    SpaceShip5.drop = FALSE;
    SpaceShip5.dead = TRUE; } // End if.

    } // End if.

} // End of function.


void ships6_move (void)
{

 if (!SpaceShip6.drop && !SpaceShip6.dead)
 {
   spaceship6.x = trans.x;
   spaceship6.y = trans.y;

   if (1+rand() %25 == 10 && trans.x < 250 && trans.x > 50 &&
     alien10.y > 50) {

   key_tap();
   SpaceShip6.drop = TRUE;

   } // End if.

 } // End if.

 if (SpaceShip6.drop)
 {

 if (++spaceship6.curr_frame > 3) spaceship6.curr_frame = 0;

if (Collision.XOUT (spaceship6.x, spaceship6.y, bullet1.x, bullet1.y) == TRUE
&& !Trans.dead) {
hit();
explode.x = spaceship6.x;
explode.y = spaceship6.y;
spaceship6.x = -100;
spaceship6.y = -100;
SpaceShip6.dead = TRUE;
Alien11.dead = TRUE;
score+=100;

} // End if.

if (Alien11.dead) {
if (++alien11.curr_frame > 15) alien11.curr_frame = 0;
 if ((alien11.y+=10) >= 175) {
blood.x = alien11.x;
blood.y = alien11.y;
blood.curr_frame = 4;
alien11.x = -100;
alien11.y = -100;

  } // End if.
} // End if.

 if (!SpaceShip6.UP1 && !Alien11.dead) {
 Alien11.hold = alien11.x = spaceship6.x+3;
 alien11.y = spaceship6.y+8;
 alien11.curr_frame = 15;

  if ((spaceship6.y+=2) > 170 && !Alien11.dead) {
  LAND = TRUE;
   SpaceShip6.UP1 = TRUE;
   alien11.x = Alien11.hold;
   alien11.y = 175; } // End if.

  } // End if spaceship2 up if.

 if (SpaceShip6.UP1)
   if (--spaceship6.y > -5)
     if ((spaceship6.x-=7) < -5) {
    spaceship6.x = -50;
    spaceship6.y = -50;
    SpaceShip6.UP1 = FALSE;
    SpaceShip6.drop = FALSE;
    SpaceShip6.dead = TRUE; } // End if.

    } // End if.

} // End of function.


void ships7_move (void)
{

 if (!SpaceShip7.drop && !SpaceShip7.dead)
 {
   spaceship7.x = trans.x;
   spaceship7.y = trans.y;

   if (1+rand() %25 == 10 && trans.x < 250 && trans.x > 50 &&
     alien11.y > 50) {

   key_tap();
   SpaceShip7.drop = TRUE;

   } // End if.

 } // End if.

 if (SpaceShip7.drop)
 {

 if (++spaceship7.curr_frame > 3) spaceship7.curr_frame = 0;

if (Collision.XOUT (spaceship7.x, spaceship7.y, bullet1.x, bullet1.y) == TRUE
&& !Trans.dead) {
hit();
explode.x = spaceship7.x;
explode.y = spaceship7.y;
spaceship7.x = -100;
spaceship7.y = -100;
SpaceShip7.dead = TRUE;
Alien12.dead = TRUE;
score+=100;

} // End if.

if (Alien12.dead) {
if (++alien12.curr_frame > 15) alien12.curr_frame = 0;
 if ((alien12.y+=10) >= 175) {
blood.x = alien12.x;
blood.y = alien12.y;
blood.curr_frame = 4;
alien12.x = -100;
alien12.y = -100;

  } // End if.
} // End if.

 if (!SpaceShip7.UP1 && !Alien12.dead) {
 Alien12.hold = alien12.x = spaceship7.x+3;
 alien12.y = spaceship7.y+8;
 alien12.curr_frame = 15;

  if ((spaceship7.y+=2) > 170 && !Alien12.dead) {
  LAND = TRUE;
   SpaceShip7.UP1 = TRUE;
   alien12.x = Alien12.hold;
   alien12.y = 175; } // End if.

  } // End if spaceship2 up if.

 if (SpaceShip7.UP1)
   if (--spaceship7.y > -5)
     if ((spaceship7.x-=7) < -5) {
    spaceship7.x = -50;
    spaceship7.y = -50;
    SpaceShip7.UP1 = FALSE;
    SpaceShip7.drop = FALSE;
    SpaceShip7.dead = TRUE; } // End if.

    } // End if.

} // End of function.


void ships8_move (void)
{

 if (!SpaceShip8.drop && !SpaceShip8.dead)
 {
   spaceship8.x = trans.x;
   spaceship8.y = trans.y;

   if (1+rand() %25 == 10 && trans.x < 250 && trans.x > 50 &&
     alien12.y > 50) {

   key_tap();
   SpaceShip8.drop = TRUE;

   } // End if.

 } // End if.

 if (SpaceShip8.drop)
 {

 if (++spaceship8.curr_frame > 3) spaceship8.curr_frame = 0;

if (Collision.XOUT (spaceship8.x, spaceship8.y, bullet1.x, bullet1.y) == TRUE
&& !Trans.dead) {
hit();
explode.x = spaceship8.x;
explode.y = spaceship8.y;
spaceship8.x = -100;
spaceship8.y = -100;
SpaceShip8.dead = TRUE;
Alien13.dead = TRUE;
score+=100;

} // End if.

if (Alien13.dead) {
if (++alien13.curr_frame > 15) alien13.curr_frame = 0;
 if ((alien13.y+=10) >= 175) {
blood.x = alien13.x;
blood.y = alien13.y;
blood.curr_frame = 4;
alien13.x = -100;
alien13.y = -100;

  } // End if.
} // End if.

 if (!SpaceShip8.UP1 && !Alien13.dead) {
 Alien13.hold = alien13.x = spaceship8.x+3;
 alien13.y = spaceship8.y+8;
 alien13.curr_frame = 15;

  if ((spaceship8.y+=2) > 170 && !Alien13.dead) {
  LAND = TRUE;
   SpaceShip8.UP1 = TRUE;
   alien13.x = Alien13.hold;
   alien13.y = 175; } // End if.

  } // End if spaceship2 up if.

 if (SpaceShip8.UP1)
   if (--spaceship8.y > -5)
     if ((spaceship8.x-=7) < -5) {
    spaceship8.x = -50;
    spaceship8.y = -50;
    SpaceShip8.UP1 = FALSE;
    SpaceShip8.drop = FALSE;
    SpaceShip8.dead = TRUE; } // End if.

    } // End if.

} // End of function.


void ships9_move (void)
{

 if (!SpaceShip9.drop && !SpaceShip9.dead)
 {
   spaceship9.x = trans.x;
   spaceship9.y = trans.y;

   if (1+rand() %25 == 10 && trans.x < 250 && trans.x > 50 &&
     alien13.y > 50) {

   key_tap();
   SpaceShip9.drop = TRUE;

   } // End if.

 } // End if.

 if (SpaceShip9.drop)
 {

 if (++spaceship9.curr_frame > 3) spaceship9.curr_frame = 0;

if (Collision.XOUT (spaceship9.x, spaceship9.y, bullet1.x, bullet1.y) == TRUE
&& !Trans.dead) {
hit();
explode.x = spaceship9.x;
explode.y = spaceship9.y;
spaceship9.x = -100;
spaceship9.y = -100;
SpaceShip9.dead = TRUE;
Alien14.dead = TRUE;
score+=100;

} // End if.

if (Alien14.dead) {
if (++alien14.curr_frame > 15) alien14.curr_frame = 0;
 if ((alien14.y+=10) >= 175) {
blood.x = alien14.x;
blood.y = alien14.y;
blood.curr_frame = 4;
alien14.x = -100;
alien14.y = -100;

  } // End if.
} // End if.

 if (!SpaceShip9.UP1 && !Alien14.dead) {
 Alien14.hold = alien14.x = spaceship9.x+3;
 alien14.y = spaceship9.y+8;
 alien14.curr_frame = 15;

  if ((spaceship9.y+=2) > 170 && !Alien14.dead) {
  LAND = TRUE;
   SpaceShip9.UP1 = TRUE;
   alien14.x = Alien14.hold;
   alien14.y = 175; } // End if.

  } // End if spaceship2 up if.

 if (SpaceShip9.UP1)
   if (--spaceship9.y > -5)
     if ((spaceship9.x-=7) < -5) {
    spaceship9.x = -50;
    spaceship9.y = -50;
    SpaceShip9.UP1 = FALSE;
    SpaceShip9.drop = FALSE;
    SpaceShip9.dead = TRUE; } // End if.

    } // End if.

} // End of function.


void ships10_move (void)
{

 if (!SpaceShip10.drop && !SpaceShip10.dead)
 {
   spaceship10.x = trans.x;
   spaceship10.y = trans.y;

   if (1+rand() %25 == 10 && trans.x < 250 && trans.x > 50 &&
     alien14.y > 50) {

   key_tap();
   SpaceShip10.drop = TRUE;

   } // End if.

 } // End if.

 if (SpaceShip10.drop)
 {

 if (++spaceship10.curr_frame > 3) spaceship10.curr_frame = 0;

if (Collision.XOUT (spaceship10.x, spaceship10.y, bullet1.x, bullet1.y) == TRUE
&& !Trans.dead) {
hit();
explode.x = spaceship10.x;
explode.y = spaceship10.y;
spaceship10.x = -100;
spaceship10.y = -100;
SpaceShip10.dead = TRUE;
Alien15.dead = TRUE;
score+=100;

} // End if.

if (Alien15.dead) {
if (++alien15.curr_frame > 15) alien15.curr_frame = 0;
 if ((alien15.y+=10) >= 175) {
blood.x = alien15.x;
blood.y = alien15.y;
blood.curr_frame = 4;
alien15.x = -100;
alien15.y = -100;

  } // End if.
} // End if.

 if (!SpaceShip10.UP1 && !Alien15.dead) {
 Alien15.hold = alien15.x = spaceship10.x+3;
 alien15.y = spaceship10.y+8;
 alien15.curr_frame = 15;

  if ((spaceship10.y+=2) > 170 && !Alien15.dead) {
  LAND = TRUE;
   SpaceShip10.UP1 = TRUE;
   alien15.x = Alien15.hold;
   alien15.y = 175; } // End if.

  } // End if spaceship2 up if.

 if (SpaceShip10.UP1)
   if (--spaceship10.y > -5)
     if ((spaceship10.x-=7) < -5) {
    spaceship10.x = -50;
    spaceship10.y = -50;
    SpaceShip10.UP1 = FALSE;
    SpaceShip10.drop = FALSE;
    SpaceShip10.dead = TRUE; } // End if.

    } // End if.

} // End of function.


void bomber_one (void)
 {

	if (Bomber.dead) {

		switch(1+rand() %150) {

		case 20: key_tap(); // Function call.
			 Bomber.dead = FALSE;
			 bomber.x = -10;
			 bomber.y = 20;
			 break;

		} // End of if.
	} // End of switch.


 if (!Bomber.dead) {

   if (++bomber.curr_frame >= 2) bomber.curr_frame = 0;

   if (bomber.x < 319) space(); // Function call.

   if (++bomber.x > 319) Bomber.dead = TRUE;

 } // End of bomber dead if.

if (Collision.XOUT (bomber.x, bomber.y, bullet1.x, bullet1.y) == TRUE) {
hit();
explode.x = bomber.x;
explode.y = bomber.y;
bomber.x = -100;
bomber.y = -100;
score+=75;
Bomber.dead = TRUE; } // End if.

} // End of function.


void drop_bomb (void)
{

 if (!Bomb.once && !Bomber.dead && !Bomb.dead)
 { bomb.x = bomber.x; Bomb.once = TRUE; bomb.y = bomber.y; } // End if.


 if (!Bomb.dead && !Bomber.dead) {
 bomb.y+=5;
 if (++bomb.curr_frame >= 4) bomb.curr_frame = 0; }  // End if.

 // Or collision detection.
 if (bomb.y >= 175) {
  Bomb.once = 0;
  explode.x = bomb.x;
  explode.y = bomb.y;
  lose(); lose();  } // End if.


 if (Bomber.dead) { bomb.x = -115; bomb.y = -115; }


 } // End of function.


 void drop_missle (void)
 {
     if (Missle.dead) {
	if (1+rand() %275 == 15) {
	key_tap();
	Missle.dead = FALSE;

     } // End if.
   } // End if.

  if (!Missle.dead) {
     if ((missle.x+=3) >= 150) {
     if (++missle.curr_frame >= 8) missle.curr_frame = 8;
     missle.x = 150;
       if ((missle.y+=3) >= 160) {
       explode.x = missle.x;
       explode.y = missle.y;
       missle.x = -200;
       missle.y = 40;
       Missle.dead = TRUE;
       wrong();
       missle.curr_frame = 4;

       }  // End if.
     } // End if.
   } // End if.

if (Collision.XOUT (missle.x, missle.y, bullet1.x, bullet1.y) == TRUE) {
hit();
explode.x = missle.x;
explode.y = missle.y;
missle.x = -200;
missle.y = 40;
missle.curr_frame = 4;
score+=50;
Missle.dead = TRUE; } // End if.

 } // End of function.


void drop_missle2 (void)
 {
     if (Missle2.dead) {
	if (1+rand() %300 == 15) {
	missle2.x = 5 + rand() %275;
	key_tap();
	Missle2.dead = FALSE;

     } // End if.
   } // End if.

  if (!Missle2.dead) {
    if ((missle2.y+=3) >= 175) {
    explode.x = missle2.x;
    explode.y = missle2.y;
    missle2.x = -100;
    missle2.y = -10;
    wrong();
    Missle2.dead = TRUE;

    } // End if.
  } // End if.

if (Collision.XOUT (missle2.x, missle2.y, bullet1.x, bullet1.y) == TRUE) {
hit();
explode.x = missle2.x;
explode.y = missle2.y;
missle2.x = -100;
missle2.y = -10;
score+=50;
Missle2.dead = TRUE; } // End if.

 } // End of function.


 void buildingd (void)
 {

if (Collision.XOUT (building1.x, building1.y, bomb.x, bomb.y) == TRUE) {
hit();
Building1.dead = TRUE;
Gun.dead = TRUE;
bomb.x = -100;
bomb.y = -100;
gun.x = -100;
gun.y = -100;
building1.curr_frame = 2; } // End if.

if (Collision.XOUT (building1.x, building1.y, missle.x, missle.y) == TRUE) {
hit();
Building1.dead = TRUE;
Gun.dead = TRUE;
missle.x = -100;
missle.y = -100;
gun.x = -200;
gun.y = -200;
building1.curr_frame = 2; } // End if.

if (Collision.XOUT (building1.x, building1.y, missle2.x, missle2.y) == TRUE) {
hit();
Building1.dead = TRUE;
Gun.dead = TRUE;
missle2.x = -100;
missle2.y = -100;
gun.x = -100;
gun.y = -100;
building1.curr_frame = 2; } // End if.


if (Building1.dead)
   if (++building1.curr_frame > 8) building1.curr_frame = 2;

} // End of function.


void instruct (void)
{
    char Dir;

    clrscr();


printf ("\n\nHello %s would you like instructions ? (y-n)", Collision.name);

   do {
   Dir = getch(); ship();
   } while (Dir != 'n' && Dir != 'y');


   if (Dir == 'y')
   {
      clrscr();

 puts ("\n\n         Alien Invasion is an action game where the player tries\n"
      "to keep invading aliens from landing while keeping enemy ships from\n"
      "destroying the only defense against them.  Once the player's building\n"
      "is destroyed or an alien lands: game over.\n\n"
      "         The guns barrel is controlled by the right and left arrow keys on \n"
      "your keyboard. The fire button is the spacebar. Esc is to quit at any time.\n\n");

      puts ("\n\nHit any key to get enemy points value..");

      getch();

     Set_Graphics_Mode(GRAPHICS_MODE13);

     setborderc (1);

     Print_String (5, 5, 10, "Aliens: 100" , 0);
     Print_String (5, 21, 100, "Bomber: 75", 0);
     Print_String (5, 41, 9, "Missles: 50", 0);
     Print_String (5, 71, 1, "Transporter: 75", 0);
     Print_String (5, 170, 100, "Hit any key to continue..", 0);

     getch();

     } // End if.

     ship();

} // End of function.


void Levels (void)
{
     gotoxy (5, 10);
     printf ("         End of LEVEL: %i", course.level);
     delay (2500);
     count2 = 0;
     Next_Level = TRUE;

 }  // End of function.


void reset_level1 (void)
{
   SpaceShip2.dead = FALSE;
   SpaceShip2.drop = FALSE;
   spaceship2.x = -100;
   Alien7.dead = FALSE;
   alien7.x = -100;

   SpaceShip3.dead = FALSE;
   SpaceShip3.drop = FALSE;
   spaceship3.x = -100;
   Alien8.dead = FALSE;
   alien8.x = -100;

   SpaceShip4.dead = FALSE;
   SpaceShip4.drop = FALSE;
   spaceship4.x = -100;
   Alien9.dead = FALSE;
   alien9.x = -100;

   trans.x = 350;

 } // End of function.


void reset_level2 (void)
{

   SpaceShip5.dead = FALSE;
   SpaceShip5.drop = FALSE;
   spaceship5.x = -100;
   Alien10.dead = FALSE;
   alien10.x = -100;

   SpaceShip6.dead = FALSE;
   SpaceShip6.drop = FALSE;
   spaceship6.x = -100;
   Alien11.dead = FALSE;
   alien11.x = -100;

 } // End of function.


 void reset_level4 (void)
 {

   SpaceShip7.dead = FALSE;
   SpaceShip7.drop = FALSE;
   spaceship7.x = -100;
   Alien12.dead = FALSE;
   alien12.x = -100;

   SpaceShip8.dead = FALSE;
   SpaceShip8.drop = FALSE;
   spaceship8.x = -100;
   Alien13.dead = FALSE;
   alien13.x = -100;

 } // End of function.


void reset_level5 (void)
{

   SpaceShip9.dead = FALSE;
   SpaceShip9.drop = FALSE;
   spaceship9.x = -100;
   Alien14.dead = FALSE;
   alien14.x = -100;

   SpaceShip10.dead = FALSE;
   SpaceShip10.drop = FALSE;
   spaceship10.x = -100;
   Alien15.dead = FALSE;
   alien15.x = -100;

 } // End of function.


void points (void)
{
    sprintf (buffer, "%s's SCORE: %d", Collision.name, score);
    Print_String_DB (90, 2, random(256), buffer, 0);


 } // End of function.


int filein (void)
{
   // ifstream constructor opens the file
   
   if ( !inClientFile ) {
      cerr << "File could not be opened\n";
      exit( 1 );
   }

   // Sends file in.
   while ( inClientFile >> Collision.name >> score )
      outputLine( Collision.name, score );

   return (0);  // ifstream destructor closes the file
} // End of function.


void outputLine( char *name1, long scores2 )
{
   cout << setiosflags (ios::left) <<  setw(10) << name1 << "    " <<
 setw(10) << scores2 << endl;
} // End of function.


int fileout(void)
{
   // ofstream constructor opens the file.

   if ( !outClientFile ) {  // overloaded ! operator
      cerr << "File could not be opened" << endl;
      exit( 1 );    // prototype in stdlib.h
   }

       // Sends file out.
outClientFile << setiosflags(ios::left) << setw(10) << Collision.name << setw(10) <<
 "   "<< score << endl;

   return (0);  // ofstream destructor closes file
} // End of function.


void AddScore (int POINT)
{

   for (unsigned short I = 0; I <= POINT; I+=10) {

  space();
  gotoxy (1, 18);
  cout << " Final score: " << I;

  } // End of for statement.

  I = POINT;

   gotoxy (1, 18);
   cout << " Final score: " << I;


  } // End of function.



