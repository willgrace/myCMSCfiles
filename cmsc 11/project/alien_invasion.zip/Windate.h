#ifndef WINDATE_H
#define WINDATE_H

#include <iostream.h>
#include <time.h>
#include <stdlib.h>


void Date2(void)
{
	char dchar[9];
	char *ptr;
	int month = NULL;
	int day = NULL;
	int year = NULL;


	_strdate(dchar);
	cout << "Today is: " << dchar << endl;

	ptr = strtok(dchar,"/");
	month = atoi(ptr);
	ptr = strtok(NULL,"/");
	day = atoi(ptr);
	ptr = strtok(NULL,"/");
	year = atoi(ptr);
	if (year == 0) year = 2000;
} // End of function.


#endif