
/* Header file structure by Steven RAmponi */

#ifndef STRUC_H
#define STRUC_H


#include "Black41.h"
#include "keys.h"



// G L O B A L S ////////////////////////////////////////////////////////////

pcx_picture image2_pcx; // Instance structure access,
		      //  image_pcx is of type pcx_picture.

 /* Instance objects, sprites are of type
  sprite.   */
sprite building1, gun, bullet1;

/////////////////////////////////////////////////////////////////////////////


class build
{
public:

	build(void){ // Constructor.

		mouse_x = 0; 
		mouse_y = 0; 
		count = 1; 
    	                Done = FALSE; 
    	                launch = FALSE;
	                one = FALSE;
		two = FALSE;
		three = FALSE;
		four = FALSE;
		five = FALSE;
		six = FALSE;
		seven = FALSE;

	} // End of constructor.

	~build(void); // Destructor.

	 void foundation (void);
	 void gunner (void);
	 void mouse1 (void);
	 void barrel (void);
	 void InsertBullet (void);

	 int mouse_x, mouse_y, buttons;
	 bool Done;


private:

	unsigned short index;
	unsigned short count;
	bool launch;
	bool one, two, three, four, five, six, seven; 

	void build::Set_Bullet (void) 
	{
		bullet1.x = -50;
		bullet1.y = -50;
		launch = FALSE;

	} // End of function.

};




void build::foundation (void)
{
	// load the imagery for foundation, there are 9 frames.

PCX_Init((pcx_picture_ptr)&image2_pcx);

PCX_Load("Building.pcx", (pcx_picture_ptr)&image2_pcx,0);

Sprite_Init((sprite_ptr)&building1,150,156,23,17,0,0,0,0,0,0);

// extract the bitmaps, there are 9 animation cells for each
// direction thus 9 cells

for (index=0; index < 9; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image2_pcx,(sprite_ptr)&building1,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image2_pcx);

} // End of function. //////////////////////////////////////////////////////////



void build::gunner (void)
{
	// load the imagery for gun, there are 7 frames.

PCX_Init((pcx_picture_ptr)&image2_pcx);

PCX_Load("Gunner.pcx", (pcx_picture_ptr)&image2_pcx,0);

Sprite_Init((sprite_ptr)&gun,150,145,23,17,0,0,0,0,0,0);

// extract the bitmaps, there are 7 animation cells for each
// direction thus 7 cells

for (index=0; index < 7; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image2_pcx,(sprite_ptr)&gun,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image2_pcx);

} // End of function. /////////////////////////////////////////////////////////



void build::mouse1 (void)
{
	Mouse_Control(MOUSE_POSITION_BUTTONS,&mouse_x,&mouse_y,&buttons);

   // Map the mouse position./////////////////////////////////////////////

		//  = mouse_x; 

	    //  = mouse_y; 
     
   // Fire button.///////////////////////////////////////////////////////

     if (buttons == MOUSE_LEFT_BUTTON) { shoot(); }

} // End of function. ///////////////////////////////////////////////////



void build::barrel (void)
{

	while (kbhit()) {
		switch (getch()) {
		case RIGHT:
			if (--gun.curr_frame < 0) gun.curr_frame = 0;
			break;

		case LEFT:
			if (++gun.curr_frame > 6) gun.curr_frame = 6;
			break;

		case SPACEBAR:

			if (++count > 2) {

			if (gun.curr_frame == 0 && launch == FALSE) {
				one = TRUE;
             bullet1.curr_frame = 4;
			 bullet1.x = gun.x;
			 bullet1.y = gun.y-5;
			 launch = TRUE;
			 	shoot();
			} // End if.

			if (gun.curr_frame == 1 && launch == FALSE) {
				two = TRUE;
             bullet1.curr_frame = 2;
			 bullet1.x = gun.x;
			 bullet1.y = gun.y-5;
			 launch = TRUE;
			 	shoot();
			} // End if.

			if (gun.curr_frame == 2 && launch == FALSE) {
				three = TRUE;
             bullet1.curr_frame = 0;
			 bullet1.x = gun.x+5;
			 bullet1.y = gun.y-5;
			 launch = TRUE;
			 	shoot();
			} // End if.

			if (gun.curr_frame == 3 && launch == FALSE) {
				four = TRUE;
             bullet1.curr_frame = 0;
			 bullet1.x = gun.x;
			 bullet1.y = gun.y-5;
			 launch = TRUE;
			 	shoot();
			} // End if.

			if (gun.curr_frame == 4 && launch == FALSE) {
				five = TRUE;
             bullet1.curr_frame = 0;
			 bullet1.x = gun.x-5;
			 bullet1.y = gun.y-5;
			 launch = TRUE;
			 	shoot();
			} // End if.

			if (gun.curr_frame == 5 && launch == FALSE) {
				six = TRUE;
             bullet1.curr_frame = 1;
			 bullet1.x = gun.x;
			 bullet1.y = gun.y-5;
			 launch = TRUE;
			 	shoot();
			} // End if.

			if (gun.curr_frame == 6 && launch == FALSE) {
				seven = TRUE;
             bullet1.curr_frame = 3;
			 bullet1.x = gun.x;
			 bullet1.y = gun.y-5;
			 launch = TRUE;
			 	shoot();
			} // End if.

			count = 0;

			} // End if.

			break;

		case ESC:
			Done = TRUE;
			Print_String (140, 40, 10, "Break..", 1); 
			end();
			delay (2000);
			break;

		} // End of switch.

	} // End of while.



	if (launch && one) 
		if ((bullet1.x+=35) > 310) { Set_Bullet(); one = FALSE; }

	if (launch && two) {
		 bullet1.y-=35;
		 if ((bullet1.x+=35) > 310) { Set_Bullet(); two = FALSE; }

		} // End if.


    if (launch && three) 
		if ((bullet1.y-=35) < -50) { Set_Bullet(); three = FALSE; } 

 
	if (launch && four) 
		if ((bullet1.y-=35) < -50) { Set_Bullet(); four = FALSE; }


	if (launch && five) 
		if ((bullet1.y-=35) < -50) { Set_Bullet(); five = FALSE; }

	if (launch && six) {
		 bullet1.y-=35;
		 if ((bullet1.x-=35) < -15) { Set_Bullet(); six = FALSE; } 

		} // End if.

	if (launch && seven) 
		if ((bullet1.x-=35) < -15) { Set_Bullet(); seven = FALSE; } 
		

} // End of function. ////////////////////////////////////////////////////



void build::InsertBullet (void)
{
	// load the imagery for bullet one, there are 5 frames.

PCX_Init((pcx_picture_ptr)&image2_pcx);

PCX_Load("missle.pcx", (pcx_picture_ptr)&image2_pcx,0);

Sprite_Init((sprite_ptr)&bullet1,-50,-50,23,17,0,0,0,0,0,0);

// extract the bitmaps, there are 5 animation cells.

for (index=0; index < 5; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image2_pcx,(sprite_ptr)&bullet1,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


} // End of function. /////////////////////////////////////////////////////////



build::~build (void)  // Destructor.
{

      Sprite_Delete((sprite_ptr)&building1);
      Sprite_Delete((sprite_ptr)&gun);
      Sprite_Delete((sprite_ptr)&bullet1);


printf ("\nFoundation deleted. ");


} // End of destructor. /////////////////////////////////////////////////////



#endif
