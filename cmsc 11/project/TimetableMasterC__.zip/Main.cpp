#include <windows.h>
#include <time.h>
#include "resource.h"
//---------------------------------------------------------------------------

HWND hWnd;LRESULT CALLBACK DlgProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);

BOOL Once = FALSE, bSuccess, ChangeOver = FALSE, CheckAnswer = FALSE;
INT Num1 = 0, Num2 = 0, Answer = 0, Length = 35, Human_Answer = 0;
INT Right = 0, Wrong = 0;
INT Decrease1 = 11, Decrease2 = 11;
TCHAR *Text = new TCHAR[Length];

INT StackNum1[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
INT StackNum2[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

// Mix Numbers Functions ***************************
void Mix_Number1(void)
{
   INT Temp, J; 
 

  for (int i = 0; i <= 11; i++)
  {
    J = rand() % 11;
    Temp = StackNum1[i];
    StackNum1[i] = StackNum1[J];
    StackNum1[J] = Temp;
   } // End For

} // End Of Function

void Mix_Number2(void)
{
  INT Temp2, J2; 

  for (int i2 = 0; i2 <= 11; i2++)
  {
    J2 = rand() % 11;
    Temp2 = StackNum2[i2];
    StackNum2[i2] = StackNum2[J2];
    StackNum2[J2] = Temp2;
   } // End For

 } // End Of Function 2

// **************************************************


//---------------------------------------------------------------------------
INT WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
				   LPSTR lpCmdLine, int nCmdShow)
{
	
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_DLGFIRST),	         
			  hWnd, reinterpret_cast<DLGPROC>(DlgProc));


	 delete [] Text;
	 Text = 0;

     return FALSE;

}
//---------------------------------------------------------------------------


LRESULT CALLBACK DlgProc(HWND hWndDlg, UINT Msg, WPARAM wParam, LPARAM lParam)
{	
	switch(Msg)	
	{	
	
	case WM_INITDIALOG:
		 srand(time(NULL));
		 // Show All Text boxes
		 SetDlgItemInt(hWndDlg, IDC_ANSWER, 0, FALSE);
		 SetDlgItemInt(hWndDlg, IDC_NUMBER1, 0, FALSE);
		 SetDlgItemInt(hWndDlg, IDC_NUMBER2, 0, FALSE);
		return TRUE;
		
	case WM_COMMAND:
		
		switch(LOWORD(wParam))	
		{	
		
		case IDCANCEL:
             EndDialog(hWndDlg, 0);			
			return TRUE;

		case IDNEXT:
		  if(!ChangeOver) {
            ChangeOver = TRUE;
			if (!Once) { // Scramble Number One Array Once   
			Mix_Number1(); // After Unloaded 
			Mix_Number2();
			Once = TRUE;
			} // End If

			if (Decrease1 < 2 ) { // Reset Subscript In Arrays 
				Once = FALSE; // Remix Numbers     
                Decrease1 = 11;
				Decrease2 = 11;
			} // End If

			// Show Numbers Being Calculated
			SetDlgItemInt(hWndDlg, IDC_NUMBER1, StackNum1[Decrease1] , FALSE);
			SetDlgItemInt(hWndDlg, IDC_NUMBER2, StackNum2[Decrease2] , FALSE);
			// Get Computation
			Answer = StackNum1[Decrease1--] * StackNum2[Decrease2--];

			} // End Changeover If
			return TRUE;

		case IDC_Check_Answer:
			if(ChangeOver) {
				ChangeOver = FALSE;
				CheckAnswer = TRUE;
			// Get Human answer
			Human_Answer = GetDlgItemInt(hWndDlg, IDC_ANSWER, &bSuccess, FALSE);
			if(bSuccess)
			{
				if(Answer == Human_Answer) {
					Right++;
					SetDlgItemInt(hWndDlg, IDC_RIGHT, Right , FALSE);
					PlaySound("win.wav", NULL, SND_FILENAME | SND_ASYNC);
				}
				else {
					Wrong++;
					SetDlgItemInt(hWndDlg, IDC_WRONG, Wrong , FALSE);
					PlaySound("boo.wav", NULL, SND_FILENAME | SND_ASYNC);
				} // End Else
			}
			} // End If ChangeOver
			return TRUE;

		case IDC_SHOW_ANSWER:
			if(!ChangeOver) {
				if (CheckAnswer == TRUE) { CheckAnswer = FALSE; }
			   wsprintf(Text, "%d", Answer);
	           ::MessageBox(NULL, Text, "ANSWER", MB_OK);
			} // End IF
			return TRUE;

			} break;
	
	} // End Switch
	
	return FALSE;

} // End LRESULT CALLBACK








