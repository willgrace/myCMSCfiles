//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Win32D.rc
//
#define DIALOG1                         101
#define IDD_DLGFIRST                    101
#define IDI_ICON1                       102
#define IDC_CHECK1                      1000
#define IDC_NUMBER                      1001
#define IDC_NUMBER1                     1001
#define IDC_NUMBER2                     1002
#define IDC_NUMBER3                     1004
#define IDC_LARGEST                     1005
#define IDC_ANSWER                      1005
#define LARGEST                         1006
#define IDNEXT                          1006
#define IDC_Check_Answer                1007
#define IDC_WRONG                       1008
#define IDC_RIGHT                       1009
#define IDC_SHOW_ANSWER                 1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
