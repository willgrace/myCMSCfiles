/* Key defines by Steven Ramponi*/


#ifndef KEYS_H
#define KEYS_H


#define TRUE 1
#define FALSE 0
#define UP 72
#define DOWN 80
#define LEFT 75
#define RIGHT 77
#define ESC 27
#define SPACEBAR 32


#endif