
/* Tank Battle by Steven Ramponi */

#include <fstream.h>
#include <iostream.h>
#include "Sound1.h"
#include "Black41.h"
#include "keys.h"
#include "Windate.h"

// S T R U C T U R E S ///////////////////////////////////////////////////////

struct tank_type
{

bool dead; // In game or out of game.

bool start; // Start tank stop tank.

bool right, left, forward, backward; // Tanks direction.

bool once_left, once_right; // Reposition of tanks.

int to_right, to_left, counter;  // Tank direction & missle placement & counter.

};

tank_type P_tank, Enemy1, Enemy2, Enemy3, Enemy4, Alien,
Potion1, Potion2, Bomb; // Structure access.


struct next { bool once; };

next level_one, level_three, level_four, level_greater;  // level
							// limiter.

// G L O B A L S  ////////////////////////////////////////////////////////////

pcx_picture image_pcx;  // general PCX image used to load background and imagery

sprite explode, blood, p_tank, enemy1, enemy2, enemy3, enemy4, alien,
potion1, potion2, bomb, enemyH; // the sprites structure access.


float Timer = 2000; // Game timer.

int index, temp; // Loop counter & temp variable holder.

int tanks; // Amount of tanks.

int level = 1, wait; // Level of game & wait for score variables.

float skill = 40; // Skill level.

long score = 0; // Score keeper.

char buffer[14]; // Holding score titles.

  bool seq2 = FALSE; // sequance exchange.

  bool Done = FALSE, WAIT = FALSE; // End of game variables.

  int outputOK = 0;
  int inputOK = 0;

  char name[20];

  bool Break = FALSE; // Break out of speed adjustment.

 ofstream outClientFile( "tank.dat", ios::app );
 ifstream inClientFile( "tank.dat", ios::in );


 // End game sayings. ///////////////////////////////////////////////////////

char pick[75];

char one[] = "Awesome shooting, NOT !";
char two[] =  "Where did you learn how to shoot ?";
char three[] = "Ever play a video game before ?";
char four[] = "Try again you wimp..";
char five[] = "You should of toasted those guys !!";
char six[] = "Enemy got you, loser !!";
char seven[] = "HA HA HA HA you lose !";
char eight[] = "TOASTED !!";

// P R O T O T Y P E S ////////////////////////////////////////////////////////

void END_GAME (void);
void LEVEL (void);
void POINTS (void);
void tank_position (void);
void potion_collide (void);
void alien_collide (void);
void rumble (void);
void enemy_explode (void);
void tank_movement (void);
void Enemy_One (void);
void Enemy_Two (void);
void Enemy_Three (void);
void Enemy_Four (void);
void alien_seq1 (void);
void POTION1 (void);
void POTION2 (void);
void BOMB (void);
void TANKS_(void);
void outputLine( char*, long );
int fileout(void);
int filein(void);

//////////////////////////////////////////////////////////////////////////////



// M A I N //////////////////////////////////////////////////////////////////

int main(void)   // Control module.
{

char instruct; // Instruction variable.

int count = 0, key_in;  // counter for move button & tank amount.

bool SHOOT; //  Missle fire controller.

int Ewait = 0; // Hold off on enemy, variable.


// H e a d e r. ////////////////////////////////////////////////////////////////

 // set the graphics mode to mode 13h

Set_Graphics_Mode(GRAPHICS_MODE13);

delay (2500);


Create_Double_Buffer(200);


// load the imagery for Header tank there are 16 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Tank.pcx", (pcx_picture_ptr)&image_pcx,0);

Sprite_Init((sprite_ptr)&enemyH,300,120,16,16,0,0,0,0,0,0);

// extract the bitmaps for the tank, there are 16 animation cells for each
// direction thus 16 cells

for (index=0; index<16; index++)
    PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&enemyH,index,index,1);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// now load the background

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Bak.pcx",(pcx_picture_ptr)&image_pcx,1);

// copy PCX image to double buffer

PCX_Copy_To_Buffer((pcx_picture_ptr)&image_pcx,double_buffer);

// delete the pcx image

PCX_Delete((pcx_picture_ptr)&image_pcx);


// scan under sprites before entering the event loop, this must be
// done or else on the first cycle the "erase" function will draw garbage.

Sprite_Under_Clip((sprite_ptr)&p_tank,double_buffer);


Print_String_DB (85, 185, 15, "Hit any key to continue..", 1);


 enemyH.curr_frame = 12;  // Face header tank to left.


 while (!kbhit()) {

 // Start animation cycle, erase draw.
 Sprite_Erase_Clip ((sprite_ptr)&enemyH, double_buffer);

 setborderc (random (256));

 if (enemyH.x > 150) rumble();

 if (--enemyH.x <= 150) enemyH.x = 150;


 Print_String_DB (80, 5, random (256), "TANK BATTLE", 1);
 Print_String_DB (95, 15, random (256), "BY", 1);
 Print_String_DB (80, 25, random (256), "Steven Ramponi", 1);


 Sprite_Under_Clip ((sprite_ptr)&enemyH, double_buffer);
 Sprite_Draw_Clip ((sprite_ptr)&enemyH, double_buffer, 1);

  Display_Double_Buffer(double_buffer,0);

 delay (50);

 } // end of header while.

 ship();

Screen_Transition(SCREEN_SWIPE_Y);

pong();

enemyH.x = -32;
enemyH.y = -32;


 // P l a n e t  i n f o. ////////////////////////////////////////////////////////////

 // set the graphics mode to mode 13h

Set_Graphics_Mode(GRAPHICS_MODE13);


Create_Double_Buffer(200);


 // load the background

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("planet.pcx",(pcx_picture_ptr)&image_pcx,1);

// copy PCX image to double buffer

PCX_Copy_To_Buffer((pcx_picture_ptr)&image_pcx,double_buffer);

// delete the pcx image

PCX_Delete((pcx_picture_ptr)&image_pcx);


Print_String_DB (85, 185, 15, "Hit any key to continue..", 1);


delay (50); space();
Print_String_DB (1, 12, 16, "Planet Caravan", 1);
delay (50); space();
Print_String_DB (1, 22, 16, "Home of the tank battles.", 1);
delay (50); space();
Print_String_DB (1, 62, 16, "Average temp: 90 degrees Fahrenheit.", 1);
delay (50); space();
Print_String_DB (1, 72, 16, "Atmosphere: Nitrogen, Oxygen based.", 1);
delay (50); space();


 Display_Double_Buffer(double_buffer,0);


getch();
getch();

 ship();

Screen_Transition(SCREEN_SWIPE_Y);

pong();


// I n s t r u c t i o n s. ///////////////////////////////////////////////


// Set back to text mode.

Set_Graphics_Mode(TEXT_MODE);

setborderc (random (256));

gotoxy (10, 10);
printf ("Instructions ? (y-n) ");


do{
instruct = getch();
} while (instruct != 'n' && instruct != 'y');


if (instruct == 'y') {

ship();

setborderc (random (256));


Set_Graphics_Mode(TEXT_MODE); // Reset the screen.


gotoxy (1, 1);
puts ("   Tank battle is a game in which the player has to survive enemy fire.\n");
puts ("To win a level the player must capture the enemy's glowing potion, before\n");
puts ("running out of time, or having theirs taken first by the green alien.\n\n");
puts ("   The game will seem very hard at first. To get past the enemy tanks: the\n");
puts ("player should try to out maneuver the enemy. The enemy is slower than the\n");
puts ("player, but a better aim.\n\n");
puts (" Arrows keys: move tank, 's' key: stop tank, 'f' key: fire, 'q' key: quit.\n\n");
puts ("Tanks: 200 points.\n");
puts ("Potion: 500 points, and new level.\n");
puts ("Alien: 50 points.\n");
puts ("Hit any key to continue..");

 getch();  } // End of instructions.




Set_Graphics_Mode(TEXT_MODE); // Reset the screen.

Date2(); // Function call from Windate.h.

cout << "Enter the amount of tanks you want\n";
cout << "(2-7)  ";

   while (key_in < 50 || key_in > 55) key_in = getch();

   switch (key_in) {

   case 50: tanks=2;
	    ship();
	    cout << "2";
	    break;

  case 51: tanks=3;
	   ship();
	   cout << "3";
	   break;

  case 52: tanks=4;
	   ship();
	   cout << "4";
	   break;

  case 53: tanks=5;
	   ship();
	   cout << "5";
	   break;

   case 54: tanks=6;
	    ship();
	    cout << "6";
	    break;

   case 55: tanks=7;
	    ship();
	    cout << "7";
	    break;

	    } // End of ship switch.


       cout << "\n\n\n\n";

   cout << "\n\nEnter the speed you want\n" << "the game to play:\n\n";
   cout << "arrow up to increase or arrow\n" << "down to decrease delay.\n\n";
   cout << "When you want to continue with\n";
   cout << "game options hit spacebar." << endl;

     gotoxy(10, 20);
     printf ("Speed delay:  %.2f%", skill);

   getch();

   while (!Break) {

 switch (getch()) {

    case UP:
     if (++skill > 90) skill = 30;
     gotoxy(10, 20);
     printf ("Speed delay:  %.2f%", skill);
     break;

    case DOWN:
    if (--skill < 30) skill = 30;
    gotoxy(10, 20);
    printf ("Speed delay:  %.2f%", skill);
    break;

    case SPACEBAR:
    ship();
    Break = TRUE;
    break;

    } // End of while.

      } // End of switch.

    Set_Graphics_Mode(GRAPHICS_MODE13);  // Reset the screen again.

   Print_String (100, 90, 12, "GET READY !!", 0);

    win();

    delay (2000);


 // G A M E. ////////////////////////////////////////////////////////////////


// set the graphics mode to mode 13h

Set_Graphics_Mode(GRAPHICS_MODE13);

delay (500);

// create the double buffer

Create_Double_Buffer(200);


// load the imagery for player tank there are 16 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Tank.pcx", (pcx_picture_ptr)&image_pcx,0);

// intialize the tank sprite

Sprite_Init((sprite_ptr)&p_tank,160,165,16,16,0,0,0,0,0,0);

// extract the bitmaps for the tank, there are 16 animation cells for each
// direction thus 16 cells

for (index=0; index<16; index++)
    PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&p_tank,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for enemy1 tank there are 16 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Tank.pcx", (pcx_picture_ptr)&image_pcx,0);

// intialize the tank sprite

Sprite_Init((sprite_ptr)&enemy1,80,10,16,16,0,0,0,0,0,0);

// extract the bitmaps for the tank, there are 16 animation cells for each
// direction thus 16 cells

for (index=0; index<16; index++)
    PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&enemy1,index,index,1);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for enemy2 tank there are 16 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Tank.pcx", (pcx_picture_ptr)&image_pcx,0);

// intialize the tank sprite

Sprite_Init((sprite_ptr)&enemy2,260,10,16,16,0,0,0,0,0,0);

// extract the bitmaps for the tank, there are 16 animation cells for each
// direction thus 16 cells

for (index=0; index<16; index++)
    PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&enemy2,index,index,1);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for enemy3 tank there are 16 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Tank.pcx", (pcx_picture_ptr)&image_pcx,0);

// intialize the tank sprite

Sprite_Init((sprite_ptr)&enemy3,25,10,16,16,0,0,0,0,0,0);

// extract the bitmaps for the tank, there are 16 animation cells for each
// direction thus 16 cells

for (index=0; index<16; index++)
    PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&enemy3,index,index,1);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for enemy4 tank there are 16 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Tank.pcx", (pcx_picture_ptr)&image_pcx,0);

// intialize the tank sprite

Sprite_Init((sprite_ptr)&enemy4,200,10,16,16,0,0,0,0,0,0);

// extract the bitmaps for the tank, there are 16 animation cells for each
// direction thus 16 cells

for (index=0; index<16; index++)
    PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&enemy4,index,index,1);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for the explosion there are 16 frames.

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Tank.pcx", (pcx_picture_ptr)&image_pcx,0);

// intialize the sprite

Sprite_Init((sprite_ptr)&explode,-15,-15,16,16,0,0,0,0,0,0);

// extract the bitmaps for the explosion, there are 3 animation cells for each
// direction thus 3 cells

for (index=0; index<3; index++)
    PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&explode,index,index,3);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alien1.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien,150,20,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien,index,index,0);


// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load imagery for blood. ////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Hammer.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the blood. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&blood,-32,-32,22,20,0,0,0,0,0,0);

// extract the bitmaps for the blood, there are 5. //////////////////////

for (index=0; index < 5; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&blood,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for potion one. //////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Potions.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the potion.

Sprite_Init((sprite_ptr)&potion1,100,1,16,16,0,0,0,0,0,0);

// extract the bitmaps for the potion, there are 4 animation cells

for (index=0; index<=4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&potion1,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for potion two. //////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Potions.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the potion.

Sprite_Init((sprite_ptr)&potion2,148,180,16,16,0,0,0,0,0,0);

// extract the bitmaps for the potion, there are 4 animation cells

for (index=0; index<=4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&potion2,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for blue bomb. //////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("bluebomb.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the bomb.

Sprite_Init((sprite_ptr)&bomb,-30,-30,11,11,0,0,0,0,0,0);

// extract the bitmaps for the bomb, there are 5 animation cells

for (index=0; index<=5; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&bomb,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);



// now load the background

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Bak.pcx",(pcx_picture_ptr)&image_pcx,1);

// copy PCX image to double buffer

PCX_Copy_To_Buffer((pcx_picture_ptr)&image_pcx,double_buffer);

// delete the pcx image

PCX_Delete((pcx_picture_ptr)&image_pcx);

// scan under sprites before entering the event loop, this must be
// done or else on the first cycle the "erase" function will draw garbage.

Sprite_Under_Clip((sprite_ptr)&p_tank,double_buffer);
Sprite_Under_Clip((sprite_ptr)&enemy1,double_buffer);
Sprite_Under_Clip((sprite_ptr)&enemy2,double_buffer);
Sprite_Under_Clip((sprite_ptr)&enemy3,double_buffer);
Sprite_Under_Clip((sprite_ptr)&enemy4,double_buffer);
Sprite_Under_Clip((sprite_ptr)&explode,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien,double_buffer);
Sprite_Under_Clip((sprite_ptr)&blood,double_buffer);
Sprite_Under_Clip((sprite_ptr)&potion1,double_buffer);
Sprite_Under_Clip((sprite_ptr)&potion2,double_buffer);
Sprite_Under_Clip((sprite_ptr)&bomb,double_buffer);




 enemy1.curr_frame = 8;   // Set enemy facing player.
 enemy2.curr_frame = 8;
 enemy3.curr_frame = 8;
 enemy4.curr_frame = 8;
 alien.curr_frame = 12;


   while (!Done)  {

	   LEVEL();
	   POINTS();
	   TANKS_();

  // Start animation cycle, erase draw.
 if (!P_tank.dead) Sprite_Erase_Clip ((sprite_ptr)&p_tank, double_buffer);
 if (!Enemy1.dead) Sprite_Erase_Clip ((sprite_ptr)&enemy1, double_buffer);
 if (!Enemy2.dead) Sprite_Erase_Clip ((sprite_ptr)&enemy2, double_buffer);
 if (!Enemy3.dead) Sprite_Erase_Clip ((sprite_ptr)&enemy3, double_buffer);
 if (!Enemy4.dead) Sprite_Erase_Clip ((sprite_ptr)&enemy4, double_buffer);

 Sprite_Erase_Clip ((sprite_ptr)&explode, double_buffer);
 Sprite_Erase_Clip ((sprite_ptr)&blood, double_buffer);

 if (!Alien.dead) Sprite_Erase_Clip ((sprite_ptr)&alien, double_buffer);
 if (!Potion1.dead) Sprite_Erase_Clip ((sprite_ptr)&potion1, double_buffer);
 if (!Potion2.dead) Sprite_Erase_Clip ((sprite_ptr)&potion2, double_buffer);
 if (!Bomb.dead) Sprite_Erase_Clip ((sprite_ptr)&bomb, double_buffer);


 // Explode sequence. ///////////////////////////////////////////////////

 if (++explode.curr_frame > 2) {
  explode.curr_frame = 0;
  explode.x = -15;
  explode.y = -15; } // End if.

 // Player movement. ////////////////////////////////////////////////////

while (kbhit()) {

  switch (getch()) {

   case 'f': enemy_explode();
	     break;

   case 'q': ship();
	     Done = TRUE;
	     break;

   case 's': if (count >= 4 && !P_tank.dead) {
	     ship();
	     P_tank.start = FALSE;
	     count = 0; } // End of counter if.
	     break;

   case UP: if (count >= 4 && !P_tank.dead) {
	    ship();
   P_tank.right = FALSE; P_tank.left = FALSE; P_tank.backward = FALSE;
	    P_tank.to_right = 0;
	    P_tank.to_left = 0;
	    p_tank.curr_frame = 0;
	    P_tank.forward = TRUE;
	    P_tank.start = TRUE;
	    P_tank.once_left = FALSE;
	    P_tank.once_right = FALSE;
	    count = 0; } // End of counter if.
	    break;

   case DOWN: if (count >= 4 && !P_tank.dead) {
	      ship();
   P_tank.right = FALSE; P_tank.left = FALSE; P_tank.forward = FALSE;
	    P_tank.to_right = 0;
	    P_tank.to_left = 0;
	    p_tank.curr_frame = 8;
	    P_tank.backward = TRUE;
	    P_tank.start = TRUE;
	    P_tank.once_left = FALSE;
	    P_tank.once_right = FALSE;
	    count = 0; } // End of counter if.
	    break;

   case RIGHT: if (count >= 4 && !P_tank.dead) {
	       ship();
   P_tank.forward = FALSE; P_tank.left = FALSE; P_tank.backward = FALSE;
	      if (!P_tank.once_right) { p_tank.curr_frame = 1; P_tank.once_right = TRUE; }
	      if (++p_tank.curr_frame >= 4) p_tank.curr_frame = 4;
	      if (++P_tank.to_right >= 3) P_tank.to_right = 3;
	       P_tank.to_left = 0;
	       P_tank.start = TRUE;
	       P_tank.right = TRUE;
	       P_tank.once_left = FALSE;
	       count = 0; } // End of counter if.
	       break;

  case LEFT: if (count >= 4 && !P_tank.dead) {
	     ship();
   P_tank.forward = FALSE; P_tank.right = FALSE; P_tank.backward = FALSE;
	      if (!P_tank.once_left) { p_tank.curr_frame = 16; P_tank.once_left = TRUE; }
	      if (--p_tank.curr_frame <= 12) p_tank.curr_frame = 12;
	      if (++P_tank.to_left >= 4) P_tank.to_left = 4;
	       P_tank.to_right = 0;
	       P_tank.start = TRUE;
	       P_tank.left = TRUE;
	       P_tank.once_right = FALSE;
	       count = 0; } // End of counter if.
	       break;


     }  // End of while.
   } // End of switch.


// Movement functions. ///////////////////////////////////

 tank_movement();

 if (++Ewait >= 40) {
 Enemy_One();
 Enemy_Two();
 Enemy_Three();
 Enemy_Four();
 alien_seq1();
 POTION1();
 POTION2();
 BOMB(); } // End wait if.

//End of movement. /////////////////////////////////////


  if (!P_tank.dead) Sprite_Under_Clip ((sprite_ptr)&p_tank, double_buffer);
  if (!Enemy1.dead) Sprite_Under_Clip ((sprite_ptr)&enemy1, double_buffer);
  if (!Enemy2.dead) Sprite_Under_Clip ((sprite_ptr)&enemy2, double_buffer);
  if (!Enemy3.dead) Sprite_Under_Clip ((sprite_ptr)&enemy3, double_buffer);
  if (!Enemy4.dead) Sprite_Under_Clip ((sprite_ptr)&enemy4, double_buffer);

  Sprite_Under_Clip ((sprite_ptr)&explode, double_buffer);
  Sprite_Under_Clip ((sprite_ptr)&blood, double_buffer);

  if (!Alien.dead) Sprite_Under_Clip ((sprite_ptr)&alien, double_buffer);
  if (!Potion1.dead) Sprite_Under_Clip ((sprite_ptr)&potion1, double_buffer);
  if (!Potion2.dead) Sprite_Under_Clip ((sprite_ptr)&potion2, double_buffer);
  if (!Bomb.dead) Sprite_Under_Clip ((sprite_ptr)&bomb, double_buffer);


  if (!P_tank.dead) Sprite_Draw_Clip ((sprite_ptr)&p_tank, double_buffer, 1);
  if (!Enemy1.dead) Sprite_Draw_Clip ((sprite_ptr)&enemy1, double_buffer, 1);
  if (!Enemy2.dead) Sprite_Draw_Clip ((sprite_ptr)&enemy2, double_buffer, 1);
  if (!Enemy3.dead) Sprite_Draw_Clip ((sprite_ptr)&enemy3, double_buffer, 1);
  if (!Enemy4.dead) Sprite_Draw_Clip ((sprite_ptr)&enemy4, double_buffer, 1);

  Sprite_Draw_Clip ((sprite_ptr)&explode, double_buffer, 1);
  Sprite_Draw_Clip ((sprite_ptr)&blood, double_buffer, 1);

  if (!Alien.dead) Sprite_Draw_Clip ((sprite_ptr)&alien, double_buffer, 1);
  if (!Potion1.dead) Sprite_Draw_Clip ((sprite_ptr)&potion1, double_buffer, 1);
  if (!Potion2.dead) Sprite_Draw_Clip ((sprite_ptr)&potion2, double_buffer, 1);
  if (!Bomb.dead) Sprite_Draw_Clip ((sprite_ptr)&bomb, double_buffer, 1);




  Display_Double_Buffer(double_buffer,0);


  if (++count >= 100) count = 0; // overflow protector for move button delay.

  if (++P_tank.counter >= 100) P_tank.counter = 0; // Overflow protector for fire.


  END_GAME();

  if (WAIT) if (++wait > 1) Done = TRUE; // Wait for scores to tally up.

  Timer--; // Game timer.

  delay (skill);   // Game speed.


  } // End of main while.

  quiet();


Screen_Transition(SCREEN_DARKNESS);
Set_Graphics_Mode(TEXT_MODE);


 if (level >= 6) {

cout << "\n\n                               *****NAMES AND SCORES*****\n\n";

cout << "\nInput your name: ";
cin >> name;

cout << "\n\n";

outputOK = fileout();
	
	if (outputOK == 0)
	{	
		inputOK = filein();
	}

    } // End if.

	cout << "\n\nHit any key to exit.." << endl;

	getch();


// free up all resources

Sprite_Delete((sprite_ptr)&p_tank);
Sprite_Delete((sprite_ptr)&enemy1);
Sprite_Delete((sprite_ptr)&enemy2);
Sprite_Delete((sprite_ptr)&enemy3);
Sprite_Delete((sprite_ptr)&enemy4);
Sprite_Delete((sprite_ptr)&explode);
Sprite_Delete((sprite_ptr)&blood);
Sprite_Delete((sprite_ptr)&alien);
Sprite_Delete((sprite_ptr)&potion1);
Sprite_Delete((sprite_ptr)&potion2);
Sprite_Delete((sprite_ptr)&bomb);
Sprite_Delete((sprite_ptr)&enemyH);


Delete_Double_Buffer();

Set_Graphics_Mode(TEXT_MODE);

  pong();


  	return (inputOK && outputOK);


 }  // End of program.

// E N D  O F  M A I N ///////////////////////////////////////////////////////



 // F U N C T I O N S ////////////////////////////////////////////////////////


   void POINTS()
   {

  sprintf (buffer, "LEVEL: %d", level);
  Print_String_DB (220, 2, 187, buffer, 0);

  sprintf (buffer, "TANKS: %d", tanks);
  Print_String_DB (2, 2, 32, buffer, 0);

  sprintf (buffer, "SCORE: %d", score);
  Print_String_DB (2, 190, 137, buffer, 0);

  sprintf (buffer, "TIME: %.2f", Timer);
  Print_String_DB (197, 190, 137, buffer, 0);

  } // End of points function.

  // Tanks decrease function. /////////////////////////////////////////////

  void TANKS_(void)
  {

    if ((tanks > 0) && P_tank.dead) {
    lose(); hit();

     Print_String (100, 90, 65, "Most unfortunate dude..", 0);

    P_tank.dead = FALSE;
    p_tank.x = 160; p_tank.y = 165;
    win();
    tanks--;
    delay (2000);

    if (level == 1 && !Enemy4.dead) {
    enemy4.x = 200; enemy4.y = 10; } // End if level one.


    if (level == 2) {

     if (!Enemy4.dead) {
     enemy4.x = 200; enemy4.y = 10; } // End enemy4 if.

     if (!Enemy3.dead) {
     enemy3.x = 25; enemy3.y = 10; } // End enemy3 if.

     } // End level two if.


    if (level == 3) {

     if (!Enemy4.dead) {
     enemy4.x = 200; enemy4.y = 10; } // End enemy4 if.

     if (!Enemy3.dead) {
     enemy3.x = 25; enemy3.y = 10; } // End enemy3 if.

     if (!Enemy2.dead) {
     enemy2.x = 260; enemy2.y = 10; } //  End of enemy2 if.

     } // End of level 3 if.


   if (level >= 4) {

     if (!Enemy4.dead) {
     enemy4.x = 200; enemy4.y = 10; } // End enemy4 if.

     if (!Enemy3.dead) {
     enemy3.x = 25; enemy3.y = 10; } // End enemy3 if.

     if (!Enemy2.dead) {
     enemy2.x = 260; enemy2.y = 10; } //  End of enemy2 if.

     if (!Enemy1.dead) {
     enemy1.x = 80; enemy1.y = 10; } // End of enemy1 if.

   } // End of level 4 and greater if.

    win();  } // End if p_tank dead.

  } // End of tank decrease function.

 // Level increase function. /////////////////////////////////////////////

 void LEVEL (void)
 {

      if (level <= 1 && !level_one.once) {
       Enemy1.dead = TRUE;
       enemy1.x = -32; enemy1.y = -32;

       Enemy3.dead = TRUE;
       enemy3.x = -32; enemy3.y = -32;

       Enemy2.dead = TRUE;
       enemy2.x = -32; enemy2.y = -32;

       Enemy4.dead = FALSE;
       enemy4.x = 200; enemy4.y = 10;

	level_one.once = TRUE; } // End if level one & two.


       if (level == 2 && !level_three.once) {
       Enemy4.dead = FALSE;
       enemy4.x = 200; enemy4.y = 10;

       Enemy3.dead = FALSE;
       enemy3.x = 25; enemy3.y = 10;

	level_three.once = TRUE; } // End if level three.


       if (level == 3 && !level_four.once) {
       Enemy4.dead = FALSE;
       enemy4.x = 200; enemy4.y = 10;

       Enemy3.dead = FALSE;
       enemy3.x = 25; enemy3.y = 10;

       Enemy2.dead = FALSE;
       enemy2.x = 260; enemy2.y = 10;

	level_four.once = TRUE; } // End if level four.


       if (level >= 4 && !level_greater.once) {

       if ((skill-=2) <= 25) skill = 25;

       Enemy4.dead = FALSE;
       enemy4.x = 200; enemy4.y = 10;

       Enemy3.dead = FALSE;
       enemy3.x = 25; enemy3.y = 10;

       Enemy2.dead = FALSE;
       enemy2.x = 260; enemy2.y = 10;

       Enemy1.dead = FALSE;
       enemy1.x = 80; enemy1.y = 10;

	level_greater.once = TRUE; } // End if level five and better.


      if (Potion1.dead) {
      win();

      sprintf (buffer, "WINNER OF LEVEL: %d", level);
      Print_String (95, 50, 65, buffer, 0);

      sprintf (buffer, "WELCOME TO LEVEL: %d", level+1);
      Print_String (95, 70, 65, buffer, 0);

      delay (3000);
      level++;
      p_tank.x = 160; p_tank.y = 165;
      Potion1.dead = FALSE;
      level_greater.once = FALSE;
      P_tank.start = FALSE;
      win(); } // End if.

  } // End of function.

 // Tank noise function. ////////////////////////////////////////////////

 void rumble (void)
 {
   buzz (200); quiet();
  }  // End of rumble function.

 // Alien collosion. //////////////////////////////////////////////////

 void alien_collide (void)
 {
      if (p_tank.x <= alien.x+10 && p_tank.x >= alien.x-10)
       if (p_tank.y <= alien.y+10 && p_tank.y >= alien.y-10) {
       score += 50;
       lose(); lose();
       blood.x = alien.x;
       blood.y = alien.y;
       alien.x = -25;
       alien.y = -25;
       blood.curr_frame = 4;
       Sprite_Draw_Clip ((sprite_ptr) &blood, double_buffer, 1); } // End if.

  } // End of function.

 // Tank position. ////////////////////////////////////////////////////

 void tank_position (void)
 {
       explode.x = p_tank.x;
       explode.y = p_tank.y;
       p_tank.x = -45;
       p_tank.y = -45;
       P_tank.dead = 1;
       hit();

  } // End of collision detection reposition function.

  // Potion collide funtion. //////////////////////////////////////////

  void potion_collide (void)
  {

      if (p_tank.x <= potion1.x+10 && p_tank.x >= potion1.x-10)
       if (p_tank.y <= potion1.y+10 && p_tank.y >= potion1.y-10) {

       if (level > 3) Timer = 1000;
       else Timer = 2000;

       score += 500;
       win();
       Potion1.dead = TRUE; } // End if collision detection.

  }  // End of potion collide function.

 // Tank movement. ///////////////////////////////////////////////////

 void tank_movement (void)
 {

   if (P_tank.start == TRUE && P_tank.forward == TRUE) {
   rumble();
   alien_collide();
   potion_collide();
   if (p_tank.y > -5) p_tank.y-=2; } // End of player forward if.


   if (P_tank.start == TRUE && P_tank.backward == TRUE) {
   rumble();
   alien_collide();
   potion_collide();
   if (p_tank.y < 190) p_tank.y+=2; } // End of player backward if.


   if (P_tank.start == TRUE && P_tank.right == TRUE) {
   rumble();
   alien_collide();
   potion_collide();
   if (p_tank.x < 300) p_tank.x += P_tank.to_right + 1;
   if (P_tank.to_right <= 2 && p_tank.y > -5) p_tank.y -= 2; } // End of player right if.


   if (P_tank.start == TRUE && P_tank.left == TRUE) {
   rumble();
   alien_collide();
   potion_collide();
   if (p_tank.x > 0) p_tank.x -= P_tank.to_left + 1;
   if (P_tank.to_left <= 3 && p_tank.y > -5) p_tank.y -= 2; } // End of player right if.

  } // End of tank movement function.


 // Enemy explosion function. ///////////////////////////////////////////////

 void enemy_explode (void)
 {

	    if (P_tank.forward && P_tank.counter > 10) {

	     P_tank.counter = 0;

	     for (index=p_tank.y; index >= -5; index--) {
	     Write_Pixel (p_tank.x+8, index, 12);
	     buzz(1500); buzz(750); quiet();

	  if (p_tank.x <= enemy1.x+5 && p_tank.x >= enemy1.x-5)
	   if (index == enemy1.y) {
	   score += 200;
	   explode.x = enemy1.x;
	   explode.y = enemy1.y;
	   enemy1.x = -25;
	   enemy1.y = -25;
	   Enemy1.dead = 1;

	    hit(); } // End of collision detection if.

	  if (p_tank.x <= enemy2.x+5 && p_tank.x >= enemy2.x-5)
	   if (index == enemy2.y) {
	   score += 200;
	   explode.x = enemy2.x;
	   explode.y = enemy2.y;
	   enemy2.x = -25;
	   enemy2.y = -25;
	   Enemy2.dead = 1;

	    hit(); } // End of collision detection if.

	  if (p_tank.x <= enemy3.x+5 && p_tank.x >= enemy3.x-5)
	   if (index == enemy3.y) {
	   score += 200;
	   explode.x = enemy3.x;
	   explode.y = enemy3.y;
	   enemy3.x = -25;
	   enemy3.y = -25;
	   Enemy3.dead = 1;

	    hit(); } // End of collision detection if.

	  if (p_tank.x <= enemy4.x+5 && p_tank.x >= enemy4.x-5)
	   if (index == enemy4.y) {
	   score += 200;
	   explode.x = enemy4.x;
	   explode.y = enemy4.y;
	   enemy4.x = -25;
	   enemy4.y = -25;
	   Enemy4.dead = 1;

	    hit(); } // End of collision detection if.

	  if (p_tank.x <= alien.x+5 && p_tank.x >= alien.x-5)
	   if (index == alien.y) {
	   score += 50;
	   blood.x = alien.x;
	   blood.y = alien.y;
	   blood.curr_frame = 4;
	   Sprite_Draw_Clip ((sprite_ptr) &blood, double_buffer, 1);
	   alien.x = -25;
	   alien.y = -25;
	   Alien.dead = 1;

	    lose(); lose(); } // End of collision detection if.

	  } // End of for statement.
	 } // End of forward statement.


	    if (P_tank.backward && P_tank.counter > 10) {

	     P_tank.counter = 0;

	     for (index=p_tank.y+10; index <= 200; index++) {
	     Write_Pixel (p_tank.x+8, index, 12);
	     buzz(1500); buzz(750); quiet();

	  if (p_tank.x <= enemy1.x+5 && p_tank.x >= enemy1.x-5)
	   if (index == enemy1.y) {
	   score += 200;
	   explode.x = enemy1.x;
	   explode.y = enemy1.y;
	   enemy1.x = -25;
	   enemy1.y = -25;
	   Enemy1.dead = 1;

	    hit(); } // End of collision detection if.

	  if (p_tank.x <= enemy2.x+5 && p_tank.x >= enemy2.x-5)
	   if (index == enemy2.y) {
	   score += 200;
	   explode.x = enemy2.x;
	   explode.y = enemy2.y;
	   enemy2.x = -25;
	   enemy2.y = -25;
	   Enemy2.dead = 1;

	    hit(); } // End of collision detection if.

	  if (p_tank.x <= enemy3.x+5 && p_tank.x >= enemy3.x-5)
	   if (index == enemy3.y) {
	   score += 200;
	   explode.x = enemy3.x;
	   explode.y = enemy3.y;
	   enemy3.x = -25;
	   enemy3.y = -25;
	   Enemy3.dead = 1;

	    hit(); } // End of collision detection if.

	  if (p_tank.x <= enemy4.x+5 && p_tank.x >= enemy4.x-5)
	   if (index == enemy4.y) {
	   score += 200;
	   explode.x = enemy4.x;
	   explode.y = enemy4.y;
	   enemy4.x = -25;
	   enemy4.y = -25;
	   Enemy4.dead = 1;

	    hit(); } // End of collision detection if.

	  if (p_tank.x <= alien.x+5 && p_tank.x >= alien.x-5)
	   if (index == alien.y) {
	   score += 50;
	   blood.x = alien.x;
	   blood.y = alien.y;
	   blood.curr_frame = 4;
	   Sprite_Draw_Clip ((sprite_ptr) &blood, double_buffer, 1);
	   alien.x = -25;
	   alien.y = -25;
	   Alien.dead = 1;

	   lose(); lose(); } // End of collision detection if.

	   } // End of for statement.
	  } // End of backward statement.


	    if (P_tank.to_right == 1 && P_tank.counter > 10) {

	    temp = p_tank.x+12;

	     P_tank.counter = 0;

	     for (index=p_tank.y+3; index >= -5; index--) {
	     Write_Pixel (temp++, index, 12);
	     buzz(1500); buzz(750); quiet();

	  if (temp <= enemy1.x+15 && temp >= enemy1.x-5)
	   if (index <= enemy1.y+5 && index >= enemy1.y-5) {
	   score += 200;
	   explode.x = enemy1.x;
	   explode.y = enemy1.y;
	   enemy1.x = -25;
	   enemy1.y = -25;
	   Enemy1.dead = 1;

	    hit(); } // End of collision detection if.

	  if (temp <= enemy2.x+15 && temp >= enemy2.x-5)
	   if (index <= enemy2.y+5 && index >= enemy2.y-5) {
	   score += 200;
	   explode.x = enemy2.x;
	   explode.y = enemy2.y;
	   enemy2.x = -25;
	   enemy2.y = -25;
	   Enemy2.dead = 1;

	    hit(); } // End of collision detection if.

	  if (temp <= enemy3.x+15 && temp >= enemy3.x-5)
	   if (index <= enemy3.y+5 && index >= enemy3.y-5) {
	   score += 200;
	   explode.x = enemy3.x;
	   explode.y = enemy3.y;
	   enemy3.x = -25;
	   enemy3.y = -25;
	   Enemy3.dead = 1;

	    hit(); } // End of collision detection if.

	  if (temp <= enemy4.x+15 && temp >= enemy4.x-5)
	   if (index <= enemy4.y+5 && index >= enemy4.y-5) {
	   score += 200;
	   explode.x = enemy4.x;
	   explode.y = enemy4.y;
	   enemy4.x = -25;
	   enemy4.y = -25;
	   Enemy4.dead = 1;

	    hit(); } // End of collision detection if.

	  if (temp <= alien.x+15 && temp >= alien.x-5)
	   if (index <= alien.y+5 && index >= alien.y-5) {
	   score += 50;
	   blood.x = alien.x;
	   blood.y = alien.y;
	   blood.curr_frame = 4;
	   Sprite_Draw_Clip ((sprite_ptr) &blood, double_buffer, 1);
	   alien.x = -25;
	   alien.y = -25;
	   Alien.dead = 1;

	   lose(); lose(); } // End of collision detection if.

	      } // End of for statement.
	     } // End of to right one statement.


	if (P_tank.to_right == 2 && P_tank.counter > 10) {

	    temp = p_tank.x+15;

	     P_tank.counter = 0;

	     for (index=p_tank.y+4; index >= -5; index--) {
	     Write_Pixel (temp+=2, index, 12);
	     buzz(1500); buzz(750); quiet();

	  if (temp <= enemy1.x+15 && temp >= enemy1.x-5)
	   if (index <= enemy1.y+5 && index >= enemy1.y-5) {
	   score += 200;
	   explode.x = enemy1.x;
	   explode.y = enemy1.y;
	   enemy1.x = -25;
	   enemy1.y = -25;
	   Enemy1.dead = 1;

	    hit(); } // End of collision detection if.

	  if (temp <= enemy2.x+15 && temp >= enemy2.x-5)
	   if (index <= enemy2.y+5 && index >= enemy2.y-5) {
	   score += 200;
	   explode.x = enemy2.x;
	   explode.y = enemy2.y;
	   enemy2.x = -25;
	   enemy2.y = -25;
	   Enemy2.dead = 1;

	    hit(); } // End of collision detection if.

	  if (temp <= enemy3.x+15 && temp >= enemy3.x-5)
	   if (index <= enemy3.y+5 && index >= enemy3.y-5) {
	   score += 200;
	   explode.x = enemy3.x;
	   explode.y = enemy3.y;
	   enemy3.x = -25;
	   enemy3.y = -25;
	   Enemy3.dead = 1;

	    hit(); } // End of collision detection if.

	  if (temp <= enemy4.x+15 && temp >= enemy4.x-5)
	   if (index <= enemy4.y+5 && index >= enemy4.y-5) {
	   score += 200;
	   explode.x = enemy4.x;
	   explode.y = enemy4.y;
	   enemy4.x = -25;
	   enemy4.y = -25;
	   Enemy4.dead = 1;

	    hit(); } // End of collision detection if.

	  if (temp <= alien.x+15 && temp >= alien.x-5)
	   if (index <= alien.y+5 && index >= alien.y-5) {
	   score += 50;
	   blood.x = alien.x;
	   blood.y = alien.y;
	   blood.curr_frame = 4;
	   Sprite_Draw_Clip ((sprite_ptr) &blood, double_buffer, 1);
	   alien.x = -25;
	   alien.y = -25;
	   Alien.dead = 1;

	   lose(); lose(); } // End of collision detection if.

	      } // End of for statement.
	     } // End of to right two statement.


	if (P_tank.to_right == 3 && P_tank.counter > 10) {

	     temp = p_tank.x+15;

	     P_tank.counter = 0;

	     for (index=temp; index <= 320; index++) {
	     Write_Pixel (index, p_tank.y+7, 12);
	     buzz(1500); buzz(750); quiet();


	  if (index == enemy1.x)
	   if (p_tank.y <= enemy1.y+3 && p_tank.y >= enemy1.y-3) {
	   score += 200;
	   explode.x = enemy1.x;
	   explode.y = enemy1.y;
	   enemy1.x = -25;
	   enemy1.y = -25;
	   Enemy1.dead = 1;

	    hit(); } // End of collision detection if.

	  if (index == enemy2.x)
	   if (p_tank.y <= enemy2.y+3 && p_tank.y >= enemy2.y-3) {
	   score += 200;
	   explode.x = enemy2.x;
	   explode.y = enemy2.y;
	   enemy2.x = -25;
	   enemy2.y = -25;
	   Enemy2.dead = 1;

	    hit(); } // End of collision detection if.

	  if (index == enemy3.x)
	   if (p_tank.y <= enemy3.y+3 && p_tank.y >= enemy3.y-3) {
	   score += 200;
	   explode.x = enemy3.x;
	   explode.y = enemy3.y;
	   enemy3.x = -25;
	   enemy3.y = -25;
	   Enemy3.dead = 1;

	    hit(); } // End of collision detection if.

	  if (index == enemy4.x)
	   if (p_tank.y <= enemy4.y+3 && p_tank.y >= enemy4.y-3) {
	   score += 200;
	   explode.x = enemy4.x;
	   explode.y = enemy4.y;
	   enemy4.x = -25;
	   enemy4.y = -25;
	   Enemy4.dead = 1;

	    hit(); } // End of collision detection if.

	  if (index == alien.x)
	   if (p_tank.y <= alien.y+3 && p_tank.y >= alien.y-3) {
	   score += 50;
	   blood.x = alien.x;
	   blood.y = alien.y;
	   blood.curr_frame = 4;
	   Sprite_Draw_Clip ((sprite_ptr) &blood, double_buffer, 1);
	   alien.x = -25;
	   alien.y = -25;
	   Alien.dead = 1;

	    lose(); lose(); } // End of collision detection if.

	      } // End of for statement.
	     } // End of to right three statement.


	 if (P_tank.to_left == 2 && P_tank.counter > 10) {

	    temp = p_tank.x+3;

	     P_tank.counter = 0;

	     for (index=p_tank.y-2; index >= -5; index--) {
	     Write_Pixel (temp--, index+2, 12);
	     buzz(1500); buzz(750); quiet();

	  if (temp <= enemy1.x+5 && temp >= enemy1.x-5)
	   if (index <= enemy1.y+5 && index >= enemy1.y-5) {
	   score += 200;
	   explode.x = enemy1.x;
	   explode.y = enemy1.y;
	   enemy1.x = -25;
	   enemy1.y = -25;
	   Enemy1.dead = 1;

	    hit(); } // End of collision detection if.

	  if (temp <= enemy2.x+5 && temp >= enemy2.x-5)
	   if (index <= enemy2.y+5 && index >= enemy2.y-5) {
	   score += 200;
	   explode.x = enemy2.x;
	   explode.y = enemy2.y;
	   enemy2.x = -25;
	   enemy2.y = -25;
	   Enemy2.dead = 1;

	    hit(); } // End of collision detection if.

	  if (temp <= enemy3.x+5 && temp >= enemy3.x-5)
	   if (index <= enemy3.y+5 && index >= enemy3.y-5) {
	   score += 200;
	   explode.x = enemy3.x;
	   explode.y = enemy3.y;
	   enemy3.x = -25;
	   enemy3.y = -25;
	   Enemy3.dead = 1;

	    hit(); } // End of collision detection if.

	  if (temp <= enemy4.x+5 && temp >= enemy4.x-5)
	   if (index <= enemy4.y+5 && index >= enemy4.y-5) {
	   score += 200;
	   explode.x = enemy4.x;
	   explode.y = enemy4.y;
	   enemy4.x = -25;
	   enemy4.y = -25;
	   Enemy4.dead = 1;

	    hit(); } // End of collision detection if.

	  if (temp <= alien.x+5 && temp >= alien.x-5)
	   if (index <= alien.y+5 && index >= alien.y-5) {
	   score += 50;
	   blood.x = alien.x;
	   blood.y = alien.y;
	   blood.curr_frame = 4;
	   Sprite_Draw_Clip ((sprite_ptr) &blood, double_buffer, 1);
	   alien.x = -25;
	   alien.y = -25;
	   Alien.dead = 1;

	   lose(); lose(); } // End of collision detection if.

	       } // End of for statement.
	     } // End of to left two statement.


	  if (P_tank.to_left == 3 && P_tank.counter > 10) {

	    temp = p_tank.x+2;

	     P_tank.counter = 0;

	     for (index=p_tank.y-2; index >= -5; index--) {
	     Write_Pixel (temp-=2, index+5, 12);
	     buzz(1500); buzz(750); quiet();

	  if (temp <= enemy1.x+5 && temp >= enemy1.x-5)
	   if (index <= enemy1.y+5 && index >= enemy1.y-5) {
	   score += 200;
	   explode.x = enemy1.x;
	   explode.y = enemy1.y;
	   enemy1.x = -25;
	   enemy1.y = -25;
	   Enemy1.dead = 1;

	    hit(); } // End of collision detection if.

	  if (temp <= enemy2.x+5 && temp >= enemy2.x-5)
	   if (index <= enemy2.y+5 && index >= enemy2.y-5) {
	   score += 200;
	   explode.x = enemy2.x;
	   explode.y = enemy2.y;
	   enemy2.x = -25;
	   enemy2.y = -25;
	   Enemy2.dead = 1;

	    hit(); } // End of collision detection if.

	  if (temp <= enemy3.x+5 && temp >= enemy3.x-5)
	   if (index <= enemy3.y+5 && index >= enemy3.y-5) {
	   score += 200;
	   explode.x = enemy3.x;
	   explode.y = enemy3.y;
	   enemy3.x = -25;
	   enemy3.y = -25;
	   Enemy3.dead = 1;

	    hit(); } // End of collision detection if.

	  if (temp <= enemy4.x+5 && temp >= enemy4.x-5)
	   if (index <= enemy4.y+5 && index >= enemy4.y-5) {
	   score += 200;
	   explode.x = enemy4.x;
	   explode.y = enemy4.y;
	   enemy4.x = -25;
	   enemy4.y = -25;
	   Enemy4.dead = 1;

	    hit(); } // End of collision detection if.

	  if (temp <= alien.x+5 && temp >= alien.x-5)
	   if (index <= alien.y+5 && index >= alien.y-5) {
	   score += 50;
	   blood.x = alien.x;
	   blood.y = alien.y;
	   blood.curr_frame = 4;
	   Sprite_Draw_Clip ((sprite_ptr) &blood, double_buffer, 1);
	   alien.x = -25;
	   alien.y = -25;
	   Alien.dead = 1;

	   lose(); lose(); } // End of collision detection if.

	      } // End of for statement.
	     } // End of to left three statement.


	if (P_tank.to_left == 4 && P_tank.counter > 10) {

	     temp = p_tank.x;

	     P_tank.counter = 0;

	     for (index=temp; index >= -5; index--) {
	     Write_Pixel (index, p_tank.y+7, 12);
	     buzz(1500); buzz(750); quiet();

	  if (index == enemy1.x)
	   if (p_tank.y <= enemy1.y+3 && p_tank.y >= enemy1.y-3) {
	   score += 200;
	   explode.x = enemy1.x;
	   explode.y = enemy1.y;
	   enemy1.x = -25;
	   enemy1.y = -25;
	   Enemy1.dead = 1;

	    hit(); } // End of collision detection if.

	  if (index == enemy2.x)
	   if (p_tank.y <= enemy2.y+3 && p_tank.y >= enemy2.y-3) {
	   score += 200;
	   explode.x = enemy2.x;
	   explode.y = enemy2.y;
	   enemy2.x = -25;
	   enemy2.y = -25;
	   Enemy2.dead = 1;

	    hit(); } // End of collision detection if.

	  if (index == enemy3.x)
	   if (p_tank.y <= enemy3.y+3 && p_tank.y >= enemy3.y-3) {
	   score += 200;
	   explode.x = enemy3.x;
	   explode.y = enemy3.y;
	   enemy3.x = -25;
	   enemy3.y = -25;
	   Enemy3.dead = 1;

	    hit(); } // End of collision detection if.

	  if (index == enemy4.x)
	   if (p_tank.y <= enemy4.y+3 && p_tank.y >= enemy4.y-3) {
	   score += 200;
	   explode.x = enemy4.x;
	   explode.y = enemy4.y;
	   enemy4.x = -25;
	   enemy4.y = -25;
	   Enemy4.dead = 1;

	    hit(); } // End of collision detection if.

	  if (index == alien.x)
	   if (p_tank.y <= alien.y+3 && p_tank.y >= alien.y-3) {
	   score += 50;
	   blood.x = alien.x;
	   blood.y = alien.y;
	   blood.curr_frame = 4;
	   Sprite_Draw_Clip ((sprite_ptr) &blood, double_buffer, 1);
	   alien.x = -25;
	   alien.y = -25;
	   Alien.dead = 1;

	    lose(); lose(); } // End of collision detection if.

	      } // End of for statement.
	     } // End of to left four statement.

  } // End of enemy explode function.


 // Enemy one tank movement function.  ///////////////////////////////////////

 void Enemy_One (void)
 {

	int I; // For loop counter.


      if (!Enemy1.dead && !P_tank.dead) {

	if (enemy1.y < p_tank.y && enemy1.x < p_tank.x) {
	 enemy1.y++; enemy1.x++; rumble();
	 enemy1.curr_frame = 7; } // End if.

	if (enemy1.y > p_tank.y && enemy1.x > p_tank.x) {
	 enemy1.y--; enemy1.x--; rumble();
	 enemy1.curr_frame = 15; } // End if

	if (enemy1.y == p_tank.y && enemy1.x < p_tank.x) {
	enemy1.curr_frame = 4;
	for (I=enemy1.x+13; I <= 320; I++) {
	Write_Pixel (I, enemy1.y+7, 1);
	buzz (1500); buzz (700); quiet();

	 if (I == p_tank.x)
	   if (p_tank.y == enemy1.y) tank_position();

	  } // End of for loop.
	 } // End if.

	if (enemy1.y == p_tank.y && enemy1.x > p_tank.x) {
	enemy1.curr_frame = 12;
	for (I=enemy1.x; I >= -5; I--) {
	Write_Pixel (I, enemy1.y+7, 1);
	buzz (1500); buzz (700); quiet();

	  if (I == p_tank.x)
	   if (p_tank.y == enemy1.y) tank_position();

	  } // End of for loop.
	 } // End if.

	if (enemy1.x == p_tank.x && enemy1.y < p_tank.y) {
	enemy1.curr_frame = 8;
	for (I=enemy1.y+12; I <= 200; I++) {
	Write_Pixel (enemy1.x+8, I, 1);
	buzz (1500); buzz (700); quiet();

	if (enemy1.x <= p_tank.x+5 && enemy1.x >= p_tank.x-5)
	   if (I == p_tank.y) tank_position();

	  } // End of for loop.
	 } // End if.

	if (enemy1.x == p_tank.x && enemy1.y > p_tank.y) {
	enemy1.curr_frame = 0;
	for (I=enemy1.y; I >= -5; I--) {
	Write_Pixel (enemy1.x+8, I, 1);
	buzz (1500); buzz (700); quiet();

	 if (enemy1.x <= p_tank.x+5 && enemy1.x >= p_tank.x-5)
	   if (I == p_tank.y) tank_position();

	  } // End of for loop.
	 } // End if.

       } // End of enemy1 dead if.

     } // End of Enemy_One function.


 // Enemy two tank movement function.  ///////////////////////////////////////

 void Enemy_Two (void)
 {

	int I; // For loop counter.


       if (!Enemy2.dead && !P_tank.dead) {

	if (enemy2.y < p_tank.y && enemy2.x < p_tank.x) {
	 enemy2.y++; enemy2.x++; rumble();
	 enemy2.curr_frame = 7; } // End if.

	if (enemy2.y > p_tank.y && enemy2.x > p_tank.x) {
	 enemy2.y--; enemy2.x--; rumble();
	 enemy2.curr_frame = 15; } // End if

	if (enemy2.y == p_tank.y && enemy2.x < p_tank.x) {
	enemy2.curr_frame = 4;
	for (I=enemy2.x+13; I <= 320; I++) {
	Write_Pixel (I, enemy2.y+7, 1);
	buzz (1500); buzz (700); quiet();

	  if (I == p_tank.x)
	   if (p_tank.y == enemy2.y) tank_position();

	} // End of for loop.
	 } // End if.

	if (enemy2.y == p_tank.y && enemy2.x > p_tank.x) {
	enemy2.curr_frame = 12;
	for (I=enemy2.x; I >= -5; I--) {
	Write_Pixel (I, enemy2.y+7, 1);
	buzz (1500); buzz (700); quiet();

	  if (I == p_tank.x)
	   if (p_tank.y == enemy2.y) tank_position();

	} // End of for loop.
	 } // End if.

	if (enemy2.x == p_tank.x && enemy2.y < p_tank.y) {
	enemy2.curr_frame = 8;
	for (I=enemy2.y+12; I <= 200; I++) {
	Write_Pixel (enemy2.x+8, I, 1);
	buzz (1500); buzz (700); quiet();

	  if (enemy2.x <= p_tank.x+5 && enemy2.x >= p_tank.x-5)
	   if (I == p_tank.y) tank_position();

	} // End of for loop.
	 } // End if.

	if (enemy2.x == p_tank.x && enemy2.y > p_tank.y) {
	enemy2.curr_frame = 0;
	for (I=enemy2.y; I >= -5; I--) {
	Write_Pixel (enemy2.x+8, I, 1);
	buzz (1500); buzz (700); quiet();

	  if (enemy2.x <= p_tank.x+5 && enemy2.x >= p_tank.x-5)
	   if (I == p_tank.y) tank_position();

	} // End of for loop.
	 } // End if.

      } // End of enemy2 dead if.

     } // End of Enemy_Two function.


 // Enemy three tank movement function.  ///////////////////////////////////////

 void Enemy_Three (void)
 {

	int I; // For loop counter.


       if (!Enemy3.dead && !P_tank.dead) {

	if (enemy3.y < p_tank.y && enemy3.x < p_tank.x) {
	 enemy3.y++; enemy3.x++; rumble();
	 enemy3.curr_frame = 7; } // End if.

	if (enemy3.y > p_tank.y && enemy3.x > p_tank.x) {
	 enemy3.y--; enemy3.x--; rumble();
	 enemy3.curr_frame = 15; } // End if

	if (enemy3.y == p_tank.y && enemy3.x < p_tank.x) {
	enemy3.curr_frame = 4;
	for (I=enemy3.x+13; I <= 320; I++) {
	Write_Pixel (I, enemy3.y+7, 1);
	buzz (1500); buzz (700); quiet();

	  if (I == p_tank.x)
	   if (p_tank.y == enemy3.y) tank_position();

	} // End of for loop.
	 } // End if.

	if (enemy3.y == p_tank.y && enemy3.x > p_tank.x) {
	enemy3.curr_frame = 12;
	for (I=enemy3.x; I >= -5; I--) {
	Write_Pixel (I, enemy3.y+7, 1);
	buzz (1500); buzz (700); quiet();

	  if (I == p_tank.x)
	   if (p_tank.y == enemy3.y) tank_position();

	} // End of for loop.
	 } // End if.

	if (enemy3.x == p_tank.x && enemy3.y < p_tank.y) {
	enemy3.curr_frame = 8;
	for (I=enemy3.y+12; I <= 200; I++) {
	Write_Pixel (enemy3.x+8, I, 1);
	buzz (1500); buzz (700); quiet();

	  if (enemy3.x <= p_tank.x+5 && enemy3.x >= p_tank.x-5)
	   if (I == p_tank.y) tank_position();

	} // End of for loop.
	 } // End if.

	if (enemy3.x == p_tank.x && enemy3.y > p_tank.y) {
	enemy3.curr_frame = 0;
	for (I=enemy3.y; I >= -5; I--) {
	Write_Pixel (enemy3.x+8, I, 1);
	buzz (1500); buzz (700); quiet();

	  if (enemy3.x <= p_tank.x+5 && enemy3.x >= p_tank.x-5)
	   if (I == p_tank.y) tank_position();

	} // End of for loop.
	 } // End if.

      } // End of enemy3 dead if.

     } // End of Enemy_Three function.


// Enemy four tank movement function.  ///////////////////////////////////////

 void Enemy_Four (void)
 {

	int I; // For loop counter.


       if (!Enemy4.dead && !P_tank.dead) {

	if (enemy4.y < p_tank.y && enemy4.x < p_tank.x) {
	 enemy4.y++; enemy4.x++; rumble();
	 enemy4.curr_frame = 7; } // End if.

	if (enemy4.y > p_tank.y && enemy4.x > p_tank.x) {
	 enemy4.y--; enemy4.x--; rumble();
	 enemy4.curr_frame = 15; } // End if

	if (enemy4.y == p_tank.y && enemy4.x < p_tank.x) {
	enemy4.curr_frame = 4;
	for (I=enemy4.x+13; I <= 320; I++) {
	Write_Pixel (I, enemy4.y+7, 1);
	buzz (1500); buzz (700); quiet();

	  if (I == p_tank.x)
	   if (p_tank.y == enemy4.y) tank_position();

	} // End of for loop.
	 } // End if.

	if (enemy4.y == p_tank.y && enemy4.x > p_tank.x) {
	enemy4.curr_frame = 12;
	for (I=enemy4.x; I >= -5; I--) {
	Write_Pixel (I, enemy4.y+7, 1);
	buzz (1500); buzz (700); quiet();

	  if (I == p_tank.x)
	   if (p_tank.y == enemy4.y) tank_position();

	} // End of for loop.
	 } // End if.

	if (enemy4.x == p_tank.x && enemy4.y < p_tank.y) {
	enemy4.curr_frame = 8;
	for (I=enemy4.y+12; I <= 200; I++) {
	Write_Pixel (enemy4.x+8, I, 1);
	buzz (1500); buzz (700); quiet();

	  if (enemy4.x <= p_tank.x+5 && enemy4.x >= p_tank.x-5)
	   if (I == p_tank.y) tank_position();

	} // End of for loop.
	 } // End if.

	if (enemy4.x == p_tank.x && enemy4.y > p_tank.y) {
	enemy4.curr_frame = 0;
	for (I=enemy4.y; I >= -5; I--) {
	Write_Pixel (enemy4.x+8, I, 1);
	buzz (1500); buzz (700); quiet();

	  if (enemy4.x <= p_tank.x+5 && enemy4.x >= p_tank.x-5)
	   if (I == p_tank.y) tank_position();

	} // End of for loop.
	 } // End if.

      } // End of enemy4 dead if.

     } // End of Enemy_Four function.


 // Alien_seq1. /////////////////////////////////////////////////////////////

  void alien_seq1 (void)
  {

  if (Alien.dead && !seq2) {

     switch (random (250)) {

     case 50: key_tap();
	      alien.x = 150;
	      alien.y = -15;
	      Alien.dead = FALSE;
	      break;

    case 100: key_tap();
	      alien.x = 150;
	      alien.y = -15;
	      Alien.dead = FALSE;
	      break;

      } // End of if.
    } // End of switch.


     if (!Alien.dead && !seq2) {
  if (++alien.curr_frame >= 15) alien.curr_frame = 12;
     if ((alien.y += 2) > 215) { Alien.dead = TRUE; seq2 = TRUE; } // End if.

     if (alien.x <= potion2.x+10 && alien.x >= potion2.x-10)
       if (alien.y <= potion2.y+10 && alien.y >= potion2.y-10) {
       lose(); lose(); lose(); delay (100); lose(); lose();
       Potion2.dead = TRUE; } // End if collision detection.

      } // End main if.


   if (Alien.dead && seq2) {

     switch (random (250)) {

     case 50: key_tap();
	      Alien.dead = FALSE;
	      alien.x = 0;
	      alien.y = 20;
	      break;

       case 100: key_tap();
	      Alien.dead = FALSE;
	      alien.x = 0;
	      alien.y = 20;
	      break;

       } // End if.
     } // End switch.


  if (!Alien.dead && seq2) {

   if ((alien.x += 3) > 350) { alien.y += 25; alien.x = -15; }

   if (alien.y >= 190)  { Alien.dead = TRUE; seq2 = FALSE; }

   if (++alien.curr_frame > 2) alien.curr_frame = 0;

   if (alien.x <= potion2.x+10 && alien.x >= potion2.x-10)
     if (alien.y <= potion2.y+10 && alien.y >= potion2.y-10) {
     lose(); lose(); lose(); delay (100); lose(); lose();
     Potion2.dead = TRUE; } // End if collision detection.

   } // End if alien dead seq2.


     } // End of alien_seq1 function.


 // Potion one function. ///////////////////////////////////////////////

  void POTION1 (void)
  {
       if (!Potion1.dead) {

       potion1.x = 100; potion1.y = 1;

       if (++potion1.curr_frame >= 4) potion1.curr_frame = 0; } // End if.


       else { potion1.x = -65; potion1.y = -65; } // End else.

  } // End potion one function.


 // Potion two function. ///////////////////////////////////////////////

  void POTION2 (void)
  {
       if (!Potion2.dead) {

       potion2.x = 148; potion2.y = 180;

       if (++potion2.curr_frame >= 4) potion2.curr_frame = 0; } // End if.


       else { potion2.x = -65; potion2.y = -65; } // End else.

  } // End potion two function.


 // Bomb function. /////////////////////////////////////////////////////////

 void BOMB (void)
 {

    if (Bomb.dead) {

     switch (random (300)) {

     case 50: key_tap();
	      bomb.x = 5 + rand() %315;
	      Bomb.dead = FALSE;
	      break;

    case 100: key_tap();
	      bomb.x = 5 + rand() %315;
	      Bomb.dead = FALSE;
	      break;

      } // End of if.
    } // End of switch.


     if (!Bomb.dead) {
     bomb.y += 4;
     beep();

     if (++bomb.curr_frame >= 5) bomb.curr_frame = 0;

     if (bomb.y >= 200) {
      bomb.x = -30;
      bomb.y = -30;
      Bomb.dead = TRUE;
      quiet(); } // End if.

     if (bomb.x <= p_tank.x+5 && bomb.x >= p_tank.x-5)
      if (bomb.y <= p_tank.y+5 && bomb.y >= p_tank.y-5) {
       tank_position();
       bomb.x = -30;
       bomb.y = -30;
       Bomb.dead = TRUE;
       quiet(); } // End if.

  } // End of bomb dead if.

 } // End of bomb function.


 // End game function. ////////////////////////////////////////

 void END_GAME (void)
 {

     if (Potion2.dead || tanks <= 0 || Timer <= 0) {

     srand(time(0)); // Seed the random function.

	switch (1+rand() %8) {

     case 1: strcpy(pick, one);
		      break;

     case 2: strcpy(pick, two);
		      break;

     case 3: strcpy(pick, three);
		      break;

     case 4: strcpy(pick, four);
		      break;

     case 5: strcpy(pick, five);
		      break;

     case 6: strcpy(pick, six);
		      break;

     case 7: strcpy(pick, seven);
		      break;

     case 8: strcpy(pick, eight);
		      break;

  } // End of switch.


	 Print_String (1, 135, 12, pick, 0);

	 Print_String (118, 1, 12, "END OF GAME", 0);

	 key_tap(); lose(); ship(); pong(); hit();

	 delay (3000);

	 WAIT = TRUE; } // End of if.


 } // End of End game funtion.


int filein (void)
{
   // ifstream constructor opens the file
   
   if ( !inClientFile ) {
      cerr << "File could not be opened\n";
      exit( 1 );
   }

   // Sends file in.
   while ( inClientFile >> name >> score )
      outputLine( name, score );

   return (0);  // ifstream destructor closes the file
} // End of function.


void outputLine( char *names, long scores2 )
{
   cout << names << "  " << scores2 << endl;
} // End of function.


int fileout(void)
{
   // ofstream constructor opens the file.

   if ( !outClientFile ) {  // overloaded ! operator
      cerr << "File could not be opened" << endl;
      exit( 1 );    // prototype in stdlib.h
   }

       // Sends file out.
      outClientFile << name << " "<< score << endl;
   
   return (0);  // ofstream destructor closes file
} // End of function.


