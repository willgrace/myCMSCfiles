
// I N C L U D E S ///////////////////////////////////////////////////////////

#define WIN32_LEAN_AND_MEAN

#include <windows.h>  
#include <windowsx.h>  
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// D E F I N E S   ///////////////////////////////////////////////////////////

// defines for windows 
#define WINDOW_CLASS_NAME "WINCLASS1"
#define WINDOW_WIDTH  400
#define WINDOW_HEIGHT 400

#define NUM_ASTEROIDS 10
#define ERASE 0
#define DRAW  1

// T Y P E D E F S ///////////////////////////////////////////////////////////

// the structure for a vertex

typedef struct vertex_typ
           {
           float x,y; // a single point in the 2-D plane.
           } vertex, *vertex_ptr;


// the structure for an object

typedef struct object_typ
           {
           int num_vertices;     // number of vertices in this object
           int color;            // color of object
           float xo,yo;          // position of object
           float x_velocity;     // x velocity of object
           float y_velocity;     // y velocity of object
           float scale;          // scale factor
           float angle;          // rotation rate
           vertex vertices[16];  // 16 vertices
           } object, *object_ptr;


// G L O B A L S /////////////////////////////////////////////////////////////

HWND main_window_handle = NULL; // save the window handle
HPEN green_pen, black_pen;       // pens to draw with

object asteroids[NUM_ASTEROIDS];



// C L A S S /////////////////////////////////////////////////////////////////
class field
{
public:

	field(){}
	~field(){}

void Scale_Object(object_ptr object,float scale);
void Rotate_Object(object_ptr object, float angle);
void Create_Field(void);
void Draw_Asteroids(HDC hdc, int erase);
void Translate_Asteroids(void);
void Rotate_Asteroids(void);

};



//////////////////////////////////////////////////////////////////////////////

void field::Scale_Object(object_ptr object,float scale)
{
int index;

// for all vertices scale the x and y component

for (index = 0; index<object->num_vertices; index++)
      {
      object->vertices[index].x *= scale;
      object->vertices[index].y *= scale; 
      } // end for index

} // end Scale_Object

//////////////////////////////////////////////////////////////////////////////

void field::Rotate_Object(object_ptr object, float angle)
{
int index;
float x_new, y_new,cs,sn;

// pre-compute sin and cos
cs = cos(angle);
sn = sin(angle);

// for each vertex rotate it by angle
for (index=0; index<object->num_vertices; index++)
      {
       // rotate the vertex
      x_new  = object->vertices[index].x * cs -  object->vertices[index].y * sn;
      y_new  = object->vertices[index].y * cs + object->vertices[index].x * sn;

      // store the rotated vertex back into structure
      object->vertices[index].x = x_new;
      object->vertices[index].y = y_new;    

      } // end for index

} // end Rotate_Object

//////////////////////////////////////////////////////////////////////////////

void field::Create_Field(void)
{

int index;

for (index=0; index<NUM_ASTEROIDS; index++)
    {

    // fill in the fields

    asteroids[index].num_vertices = 6;
    asteroids[index].color = 1  + rand() % 14; // always visable
    asteroids[index].xo    = 41 + rand() % 599;
    asteroids[index].yo    = 41 + rand() % 439;

    asteroids[index].x_velocity = -10 + rand() % 20;
    asteroids[index].y_velocity = -10 + rand() % 20;
    asteroids[index].scale      = (float)(rand() % 30) / 10;
    asteroids[index].angle      = (float)(- 50 + (float)(rand() % 100)) / 100;

    asteroids[index].vertices[0].x = 4.0;
    asteroids[index].vertices[0].y = 3.5;
    asteroids[index].vertices[1].x = 8.5;
    asteroids[index].vertices[1].y = -3.0;
    asteroids[index].vertices[2].x = 6;
    asteroids[index].vertices[2].y = -5;
    asteroids[index].vertices[3].x = 2;
    asteroids[index].vertices[3].y = -3;
    asteroids[index].vertices[4].x = -4;
    asteroids[index].vertices[4].y = -6;
    asteroids[index].vertices[5].x = -3.5;
    asteroids[index].vertices[5].y = 5.5;

    // now scale the asteroid to proper size

    Scale_Object((object_ptr)&asteroids[index], asteroids[index].scale);

    } // end for index

} // end Create_Field

//////////////////////////////////////////////////////////////////////////////

void field::Draw_Asteroids(HDC hdc, int erase)
{

int index,vertex;
float xo,yo;

for (index=0; index<NUM_ASTEROIDS; index++)
    {

    // draw the asteroid

    if (erase==ERASE) SelectObject(hdc, black_pen);
    else
       SelectObject(hdc, green_pen);

    // get position of object
    xo = asteroids[index].xo;
    yo = asteroids[index].yo;


    // moveto first vertex

    MoveToEx(hdc, (int)(xo+asteroids[index].vertices[0].x),(int)(yo+asteroids[index].vertices[0].y), NULL);

    for (vertex=1; vertex<asteroids[index].num_vertices; vertex++)
        {
        LineTo(hdc, (int)(xo+asteroids[index].vertices[vertex].x),(int)(yo+asteroids[index].vertices[vertex].y));

        } // end for vertex

    // close object

    LineTo(hdc, (int)(xo+asteroids[index].vertices[0].x),(int)(yo+asteroids[index].vertices[0].y));

    } // end for index

} // end Draw_Asteroids

//////////////////////////////////////////////////////////////////////////////

void field::Translate_Asteroids(void)
{

int index;

for (index=0; index<NUM_ASTEROIDS; index++)
    {
    // translate current asteroid

    asteroids[index].xo += asteroids[index].x_velocity;
    asteroids[index].yo += asteroids[index].y_velocity;

    // collision detection i.e. bounds check

    if (asteroids[index].xo > 600 || asteroids[index].xo < 40)
        {
        asteroids[index].x_velocity = -asteroids[index].x_velocity;
        asteroids[index].xo += asteroids[index].x_velocity;
        }

    if (asteroids[index].yo > 440 || asteroids[index].yo < 40)
        {
        asteroids[index].y_velocity = -asteroids[index].y_velocity;
        asteroids[index].yo += asteroids[index].y_velocity;
        }

    } // end for index

} // end Translate_Asteroids

//////////////////////////////////////////////////////////////////////////////

void field::Rotate_Asteroids(void)
{

int index;

for (index=0; index<NUM_ASTEROIDS; index++)
    {
    // rotate current asteroid
    Rotate_Object((object_ptr)&asteroids[index], asteroids[index].angle);

    } // end for index

} // end Rotate_Asteroids

