/*GALAXY BAD BOY By Steven Ramponi*/

// I N C L U D E S ///////////////////////////////////////////////////////////

#include <stdlib.h>
#include <iostream.h>
#include <fstream.h>
#include "Black41.h"
#include "Sound1.h"
#include "Game.h"

// S T R U C T U R E S //////////////////////////////////////////////////////

typedef struct Ship_type { bool dead, bombs_once; } ships;


ships player, Enemy1, Enemy2, Enemy3, Alien1, Alien2, Alien3,
Bomber, Bombs, Asteroid1, Monster1, Monster2,
Blue1, Blue2, Blue3;  // Access ship type structure.

// G L O B A L S  ////////////////////////////////////////////////////////////

pcx_picture image_pcx;  // General PCX image used to load background and imagery

sprite P_ship, enemy1, enemy2, enemy3, alien1, alien2, alien3,
bomber, bombs, asteroid1, monster1, monster2,
blue1, blue2, blue3; // Access sprite structure.

char name[20];
char buffer[14]; // Points display.
int level = 1, SHips = 3, wait = 0;
long score = 0;
bool header1 = 1, header2 = 1, header3 = 1; // True false for header display.

bool Done = 0;  // True or false end game variable.


 ofstream outClientFile( "Gal.dat", ios::app );
 ifstream inClientFile( "Gal.dat", ios::in );


// P R O T O T Y P E S ///////////////////////////////////////////////////////

void points (void);

void Level_Add (void);

void SHIPS (void);

void outputLine( char*, long );

int fileout(void);

int filein(void);

// M A I N //////////////////////////////////////////////////////////////////

int main(void) //Control module.
{

char hed1[] = "GALAXY BAD BOY";
char hed2[] = "By Steven Ramponi";


char DIR1[] = " Arrow keys: ships movement.";
char DIR2[] = "The 'f' key: fire button.";
char DIR3[] = "The 'q' key: quit game at anytime.";
char DIRB[] = "Blue balls take four hits to take down.";
char B[] = "Shoot bombs..";
char ASS[] = "Pick up asteroids for extra points.";
char DIR4[] = "Hit any key to continue. ";

 char instructions;

int index, Hit = 0, Hit2 = 0, Hit3 = 0, Hit4 = 0;   // Counter Variable for bitmaps & hit delay.

int Fire = 0, Move = 0; // Fire button reload & move reload.

int outputOK = 0;
int inputOK = 0;


game queue; // Instance object from Game.h, queue is of type game.


// set the graphics mode to mode 13h

Set_Graphics_Mode(GRAPHICS_MODE13);

delay(2000);

// create the double buffer

Create_Double_Buffer(200);


// load the imagery for the spaceships. /////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Blazeshp.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the spaceship.

Sprite_Init((sprite_ptr)&P_ship,160,170,22,18,0,0,0,0,0,0);

// extract the bitmaps for the spaceship, there are 12 animation cells

for (index=0; index<=12; index++)
    PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&P_ship,index,index,0);


// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for the enemy one. //////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Enemy.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the enemy spaceship.

Sprite_Init((sprite_ptr)&enemy1,-3,0,14,8,0,0,0,0,0,0);

// extract the bitmaps for the enemy spaceship, there are 4 animation cells

for (index=0; index<=4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&enemy1,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for the enemy two. //////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Enemy.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the enemy spaceship.

Sprite_Init((sprite_ptr)&enemy2,-44,20,14,8,0,0,0,0,0,0);

// extract the bitmaps for the enemy spaceship, there are 4 animation cells

for (index=0; index<=4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&enemy2,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for the enemy three. //////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Enemy.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the enemy spaceship.

Sprite_Init((sprite_ptr)&enemy3,-25,36,14,8,0,0,0,0,0,0);

// extract the bitmaps for the enemy spaceship, there are 4 animation cells

for (index=0; index<=4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&enemy3,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien one. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alien1.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien1,0,0,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien1,index,index,0);


// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// Load alien two. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alien1.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien2,0,0,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien2,index,index,0);


// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


 // Load alien three. ////////////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);

PCX_Load("Alien1.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the alien. ///////////////////////////////////////////////

Sprite_Init((sprite_ptr)&alien3,0,0,8,12,0,0,0,0,0,0);

// extract the bitmaps for the alien, there are 16. //////////////////////

for (index=0; index < 16; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&alien3,index,index,0);


// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for bomber one //////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("BOMBER.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the bomber spaceship.

Sprite_Init((sprite_ptr)&bomber,300,10,18,15,0,0,0,0,0,0);

// extract the bitmaps for the enemy spaceship, there are 2 animation cells

for (index=0; index<=2; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&bomber,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for bombs. //////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Tbombs.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the bombs.

Sprite_Init((sprite_ptr)&bombs,0,0,16,16,0,0,0,0,0,0);

// extract the bitmaps for the bombs, there are 4 animation cells

for (index=0; index<=4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&bombs,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for asteroids. //////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Asteroid.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the asteroid.

Sprite_Init((sprite_ptr)&asteroid1,-100,-100,16,14,0,0,0,0,0,0);

// extract the bitmaps for asteroid, there are 8 animation cells

for (index=0; index<=8; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&asteroid1,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for monster one. //////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Monster.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the monster.

Sprite_Init((sprite_ptr)&monster1,150,25,24,12,0,0,0,0,0,0);

// extract the bitmaps for monster, there are 4 animation cells

for (index=0; index<=4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&monster1,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for monster two. //////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Monster.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the monster.

Sprite_Init((sprite_ptr)&monster2,250,5,24,12,0,0,0,0,0,0);

// extract the bitmaps for monster, there are 4 animation cells

for (index=0; index<=4; index++)
PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&monster2,index,index,0);

// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for blue dot. /////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Blue.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the blue dot.

Sprite_Init((sprite_ptr)&blue1,180,-20,26,20,0,0,0,0,0,0);

// extract the bitmaps for the spaceship, there are 8 animation cells

for (index=0; index<=8; index++)
 PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&blue1,index,index,0);


// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for blue dot two. /////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Blue.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the blue dot.

Sprite_Init((sprite_ptr)&blue2,130,-20,26,20,0,0,0,0,0,0);

// extract the bitmaps for the spaceship, there are 8 animation cells

for (index=0; index<=8; index++)
 PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&blue2,index,index,0);


// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// load the imagery for blue dot three. /////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Blue.pcx", (pcx_picture_ptr)&image_pcx,1);

// intialize the blue dot.

Sprite_Init((sprite_ptr)&blue3,250,-20,26,20,0,0,0,0,0,0);

// extract the bitmaps for the spaceship, there are 8 animation cells

for (index=0; index<=8; index++)
 PCX_Get_Sprite((pcx_picture_ptr)&image_pcx,(sprite_ptr)&blue3,index,index,0);


// done with this PCX file so delete memory associated with it

PCX_Delete((pcx_picture_ptr)&image_pcx);


// now load the background image /////////////////////////////////////////////

PCX_Init((pcx_picture_ptr)&image_pcx);
PCX_Load("Frontier.pcx",(pcx_picture_ptr)&image_pcx,1);

// copy PCX image to double buffer

PCX_Copy_To_Buffer((pcx_picture_ptr)&image_pcx,double_buffer);
PCX_Delete((pcx_picture_ptr)&image_pcx);


// scan background before entering event loop

Sprite_Under_Clip((sprite_ptr)&P_ship,double_buffer);
Sprite_Under_Clip((sprite_ptr)&enemy1,double_buffer);
Sprite_Under_Clip((sprite_ptr)&enemy2,double_buffer);
Sprite_Under_Clip((sprite_ptr)&enemy3,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien1,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien2,double_buffer);
Sprite_Under_Clip((sprite_ptr)&alien3,double_buffer);
Sprite_Under_Clip((sprite_ptr)&bomber,double_buffer);
Sprite_Under_Clip((sprite_ptr)&bombs,double_buffer);
Sprite_Under_Clip((sprite_ptr)&asteroid1,double_buffer);
Sprite_Under_Clip((sprite_ptr)&monster1,double_buffer);
Sprite_Under_Clip((sprite_ptr)&monster2,double_buffer);
Sprite_Under_Clip((sprite_ptr)&blue1,double_buffer);
Sprite_Under_Clip((sprite_ptr)&blue2,double_buffer);
Sprite_Under_Clip((sprite_ptr)&blue3,double_buffer);


Alien1.dead = 1;  // Delete alien till ships get hit.
Alien2.dead = 1; /////////////////////////////////////
Alien3.dead = 1; /////////////////////////////////////


    ship();
	Print_String (51, 5, 61, hed1, 0);
    delay (100); ship();
	Print_String (51, 25, 61, hed2, 0);
	hit();
	delay (4000);
    Screen_Transition(SCREEN_SWIPE_X);  
	pong();




     Print_String (51, 1, 37, " INSTRUCTIONS ? (y-n) ", 0);

     do{
     instructions = getch(); ship();
     } while (instructions != 'n' && instructions != 'y');

     if (instructions == 'y') {

      Screen_Transition(SCREEN_SWIPE_X);  pong();

     Print_String (0, 1, 189, DIR1, 0);
     Print_String (1, 21, 17, DIR2, 0);
     Print_String (1, 41, 61, DIR3, 0);
     Print_String (1, 61, 151, DIRB, 0);
     Print_String (1, 81, 107, B, 0);
     Print_String (1, 101, 89, ASS, 0);
     Print_String (1, 141, 37, DIR4, 0);

     getch();

     Screen_Transition(SCREEN_SWIPE_X);  pong();

     } // End if.


     else  {  Screen_Transition(SCREEN_SWIPE_X);  pong();  }  // End of else.


	queue.Game_Speed(); // Function call from Game.h

    Screen_Transition(SCREEN_SWIPE_X);  pong();


while(!Done)
     {

     points();
     Level_Add();
     SHIPS();

     // do animation cycle, erase, move draw...

     // erase all objects by replacing what was under them

if (!player.dead) Sprite_Erase_Clip((sprite_ptr)&P_ship,double_buffer);

if (level == 1 || level == 2 || level >= 3)
if (!Enemy1.dead) Sprite_Erase_Clip((sprite_ptr)&enemy1,double_buffer);

if (level == 2 || level >= 3)
if (!Enemy2.dead) Sprite_Erase_Clip((sprite_ptr)&enemy2,double_buffer);

if (level >= 3)
if (!Enemy3.dead) Sprite_Erase_Clip((sprite_ptr)&enemy3,double_buffer);

if (!Alien1.dead) Sprite_Erase_Clip((sprite_ptr)&alien1,double_buffer);

if (!Alien2.dead) Sprite_Erase_Clip((sprite_ptr)&alien2,double_buffer);

if (!Alien3.dead) Sprite_Erase_Clip((sprite_ptr)&alien3,double_buffer);

if (!Bomber.dead) Sprite_Erase_Clip((sprite_ptr)&bomber,double_buffer);

if (!Bombs.dead) Sprite_Erase_Clip((sprite_ptr)&bombs,double_buffer);

if (!Asteroid1.dead) Sprite_Erase_Clip((sprite_ptr)&asteroid1,double_buffer);

if (!Monster1.dead) Sprite_Erase_Clip((sprite_ptr)&monster1,double_buffer);

if (!Monster2.dead) Sprite_Erase_Clip((sprite_ptr)&monster2,double_buffer);

if (level == 1 || level == 2 || level >= 3)
if (!Blue1.dead) Sprite_Erase_Clip((sprite_ptr)&blue1,double_buffer);

if (level == 2 || level >= 3)
if (!Blue2.dead) Sprite_Erase_Clip((sprite_ptr)&blue2,double_buffer);

if (level >= 3)
if (!Blue3.dead) Sprite_Erase_Clip((sprite_ptr)&blue3,double_buffer);



// BEGIN PATTERN MOTION LOGIC ////////////////////////////////////////////

  while (kbhit()) {

	switch(getch())
	      {

	      case 77: // right
	      {

		   // move spaceship

		  if (!player.dead) {

		   if (Move >= 1) {

		   Move = 0;

		   P_ship.curr_frame = 0;
		   P_ship.x+=15;

		   // ships thrust fire. ////////////////////////////////////////
  if (P_ship.x <= 290 && P_ship.x >= 0 && P_ship.y <= 175 && P_ship.y >= 0) {
		   for (index=0; index<= 20; index++)
     Write_Pixel (P_ship.x-5 + rand() %10, P_ship.y+15 + rand() %10, 12);

			lose(); } // End of thrust if.

		   // test if off edge

		   if (P_ship.x > 320)
		      P_ship.x=-30;

		      } // End of move delay.
			}// End of dead if.

		   } break;

	      case 75: // left
		   {

		   // move spaceship

		 if (!player.dead) {

		  if (Move >= 1) {

		  Move = 0;

		  P_ship.curr_frame = 0;
		  P_ship.x-=15;

		  // ships thrust fire./////////////////////////////////////
   if (P_ship.x <= 290 && P_ship.x >= 0 && P_ship.y <= 175 && P_ship.y >= 0) {
		  for (index=0; index<= 20; index++)
     Write_Pixel (P_ship.x+17 + rand() %10, P_ship.y+15 + rand() %10, 12);

			lose();  } // End of thrust if.

		   // test if off edge

		   if (P_ship.x < -30)
		      P_ship.x=320;

			} // End of move delay.
			 } // End of dead if.


		   } break;


		   case 72: // Up
		   {

		   // move spaceship

		 if (!player.dead) {

		  if (Move >= 1) {

		  Move = 0;

		  P_ship.curr_frame = 0;
		  P_ship.y-=15;

		  // ships thrust fire. ////////////////////////
		  if (P_ship.x > 0 && P_ship.x < 300)
		  if (P_ship.y <= 168 && P_ship.y >= 0) {
		  for (index=0; index<= 20; index++)
     Write_Pixel (P_ship.x+7 + rand() %10, P_ship.y+30 + rand() %10, 12);

			lose(); } // End of thrust if.

		   // test if off edge

		   if (P_ship.y < -30)
		      P_ship.y=200;

		      } // End of move delay.
		       } // End of dead if.

		   } break;


		   case 80: // Down
		   {

		   // move spaceship

		  if (!player.dead) {

		   if (Move >= 1) {

		   Move = 0;

		  P_ship.curr_frame = 0;
		  P_ship.y+=15;

		  // ships thrust fire. ///////////////////////////
		  if (P_ship.x > 0 && P_ship.x < 300)
		  if (P_ship.y <= 188 && P_ship.y >= 0) {
		  for (index=0; index<= 20; index++)
     Write_Pixel (P_ship.x+5 + rand() %10, P_ship.y+3 + rand() %10, 12);

			lose(); } // End of thrust if.

		    // test if off edge

		   if (P_ship.y > 185)
		      P_ship.y=-100;

		      } // End of move delay.
		       } // End of dead if.

		   } break;

     case 'f': if (Fire >= 6) {
	       Fire = 0;

	       for (int f = P_ship.y; f >= -1; f--) {


  // Collision detection for enemy one. //////////////////////////////////////

      if (P_ship.x <= enemy1.x+10 && P_ship.x >= enemy1.x-10)
      if (f == enemy1.y) {

	for (index=0; index<=100; index++)
   Write_Pixel (enemy1.x+rand() %20, enemy1.y+rand() %20, 12);
   Alien1.dead = 0;
   alien1.x = enemy1.x; alien1.y = enemy1.y;
   Enemy1.dead = 1;
	hit();  Hit = 0; score += 200;

    }  // End of collision detection for enemy one.
    /////////////////////////////////////////////////

    // Collision detection for enemy two. //////////////////////////////////////

      if (P_ship.x <= enemy2.x+10 && P_ship.x >= enemy2.x-10)
      if (f == enemy2.y) {

	for (index=0; index<=100; index++)
   Write_Pixel (enemy2.x+rand() %20, enemy2.y+rand() %20, 12);
   Alien2.dead = 0;
   alien2.x = enemy2.x; alien2.y = enemy2.y;
   Enemy2.dead = 1;
	hit(); Hit = 0;  score += 200;

    }  // End of collision detection for enemy two.
    /////////////////////////////////////////////////

    // Collision detection for enemy three. //////////////////////////////////////

      if (P_ship.x <= enemy3.x+10 && P_ship.x >= enemy3.x-10)
      if (f == enemy3.y) {

	for (index=0; index<=100; index++)
   Write_Pixel (enemy3.x+rand() %20, enemy3.y+rand() %20, 12);
   Alien3.dead = 0;
   alien3.x = enemy3.x; alien3.y = enemy3.y;
   Enemy3.dead = 1;
	hit();  Hit = 0; score += 200;

    }  // End of collision detection for enemy three.
    /////////////////////////////////////////////////


// Collision detection for alien one./////////////////////////////////////////

     if (!Alien1.dead) {

     if (P_ship.x <= alien1.x+10 && P_ship.x >= alien1.x-10)
     if (f == alien1.y) Hit++;


     if (Hit >= 2) {
     Print_String (alien1.x, alien1.y - 5, random(256), "AAAAA !!", 1);
     space(); score += 50;

	for (index=0; index<=100; index++)
   Write_Pixel (alien1.x+rand() %20, alien1.y+rand() %20, 12);
   Alien1.dead = 1;
   alien1.x = -100; alien1.y = -100;
	hit(); Hit = 0;

       } // --------------------------------------

    }  // End of collision detection for alien one.
    /////////////////////////////////////////////////

    // Collision detection for alien two./////////////////////////////////////////

     if (!Alien2.dead) {

     if (P_ship.x <= alien2.x+10 && P_ship.x >= alien2.x-10)
     if (f == alien2.y) Hit++;


     if (Hit >= 2) {
     Print_String (alien2.x, alien2.y - 5, random(256), "AAAAA !!", 1);
     space();  score += 50;


	for (index=0; index<=100; index++)
   Write_Pixel (alien2.x+rand() %20, alien2.y+rand() %20, 12);
   Alien2.dead = 1;
   alien2.x = -100; alien2.y = -100;
	hit(); Hit = 0;

       } // --------------------------------------

    }  // End of collision detection for alien two.
    /////////////////////////////////////////////////

   // Collision detection for alien three./////////////////////////////////////////

     if (!Alien3.dead) {

     if (P_ship.x <= alien3.x+10 && P_ship.x >= alien3.x-10)
     if (f == alien3.y) Hit++;


     if (Hit >= 2) {
     Print_String (alien3.x, alien3.y - 5, random(256), "AAAAA !!", 1);
     space();  score += 50;

	for (index=0; index<=100; index++)
   Write_Pixel (alien3.x+rand() %20, alien3.y+rand() %20, 12);
   Alien3.dead = 1;
   alien3.x = -100; alien3.y = -100;
	hit(); Hit = 0;

       } // --------------------------------------

    }  // End of collision detection for alien three.
    /////////////////////////////////////////////////

    // Collision detection for bomber. //////////////////////////////////////

      if (P_ship.x <= bomber.x+10 && P_ship.x >= bomber.x-10)
      if (f == bomber.y) {
	  score += 300;
	for (index=0; index<=100; index++)
   Write_Pixel (bomber.x+rand() %20, bomber.y+rand() %20, 12);
   Bomber.dead = 1;
   bomber.x = -100; bomber.y = -100;
	hit();

    }  // End of collision detection for bomber.
    /////////////////////////////////////////////////

   // Collision detection for bombs. //////////////////////////////////////

      if (P_ship.x <= bombs.x+10 && P_ship.x >= bombs.x-10)
      if (f == bombs.y) {
	 score += 100;
	for (index=0; index<=100; index++)
   Write_Pixel (bombs.x+rand() %20, bombs.y+rand() %20, 12);
   Bombs.bombs_once = 0; asteroid1.x = bombs.x; asteroid1.y = bombs.y;
   Bombs.dead = 1; hit();

    }  // End of collision detection for bombs.
    /////////////////////////////////////////////////

    // Collision detection for monster one./////////////////////////////////////////

     if (!Monster1.dead) {

     if (P_ship.x <= monster1.x+10 && P_ship.x >= monster1.x-10)
     if (f == monster1.y) Hit++;


     if (Hit >= 2) {
     Print_String (monster1.x, monster1.y - 5, random(256), "AAAAA !!", 1);
     space();  score += 500;


	for (index=0; index<=100; index++)
   Write_Pixel (monster1.x+rand() %20, monster1.y+rand() %20, 12);
   Monster1.dead = 1;
   monster1.x = -14; monster1.y = -14;
	hit(); Hit = 0;

       } // --------------------------------------

    }  // End of collision detection for monster one.
    /////////////////////////////////////////////////


    // Collision detection for monster two./////////////////////////////////////////

     if (!Monster2.dead) {

     if (P_ship.x <= monster2.x+10 && P_ship.x >= monster2.x-10)
     if (f == monster2.y) Hit++;


     if (Hit >= 2) {
     Print_String (monster2.x, monster2.y - 5, random(256), "AAAAA !!", 1);
     space();  score += 500;


	for (index=0; index<=100; index++)
   Write_Pixel (monster2.x+rand() %20, monster2.y+rand() %20, 12);
   Monster2.dead = 1;
   monster2.x = -14; monster2.y = -14;
	hit(); Hit = 0;

       } // --------------------------------------

    }  // End of collision detection for monster two.
    /////////////////////////////////////////////////

   // Collision detection for blue one./////////////////////////////////////////

     if (!Blue1.dead) {

     if (P_ship.x <= blue1.x+10 && P_ship.x >= blue1.x-10)
     if (f == blue1.y) {
      Hit2++; pong();
	for (index=0; index<=100; index++)
      Write_Pixel (blue1.x+rand() %20, blue1.y+rand() %20, 12); } // End if.


     if (Hit2 >= 4) {
     Blue1.bombs_once= 0;
     lose();
     space(); score += 550;

	for (index=0; index<=100; index++)
   Write_Pixel (blue1.x+rand() %20, blue1.y+rand() %20, 12);
   Blue1.dead = 1;
   blue1.x = -44; blue1.y = -90;
	hit(); Hit2 = 0; quiet();

       } // --------------------------------------

    }  // End of collision detection blue one.
    /////////////////////////////////////////////////

 // Collision detection for blue two./////////////////////////////////////////

     if (!Blue2.dead) {

     if (P_ship.x <= blue2.x+10 && P_ship.x >= blue2.x-10)
     if (f == blue2.y) {
      Hit3++; pong();
	for (index=0; index<=100; index++)
      Write_Pixel (blue2.x+rand() %20, blue2.y+rand() %20, 12); } // End if.


     if (Hit3 >= 4) {
     Blue2.bombs_once= 0;
     lose();
     space(); score += 550;

	for (index=0; index<=100; index++)
   Write_Pixel (blue2.x+rand() %20, blue2.y+rand() %20, 12);
   Blue2.dead = 1;
   blue2.x = -4; blue2.y = -50;
	hit(); Hit3 = 0; quiet();

       } // --------------------------------------

    }  // End of collision detection blue two.
    /////////////////////////////////////////////////

  // Collision detection for blue three./////////////////////////////////////////

     if (!Blue3.dead) {

     if (P_ship.x <= blue3.x+10 && P_ship.x >= blue3.x-10)
     if (f == blue3.y) {
      Hit4++; pong();
	for (index=0; index<=100; index++)
      Write_Pixel (blue3.x+rand() %20, blue3.y+rand() %20, 12); } // End if.


     if (Hit4 >= 4) {
     Blue3.bombs_once= 0;
     lose();
     space(); score += 550;

	for (index=0; index<=100; index++)
   Write_Pixel (blue3.x+rand() %20, blue3.y+rand() %20, 12);
   Blue3.dead = 1;
   blue3.x = -24; blue3.y = -34;
	hit(); Hit4 = 0; quiet();

       } // --------------------------------------

    }  // End of collision detection blue three.
    /////////////////////////////////////////////////


     buzz(750); buzz(1500); quiet();
     Write_Pixel (P_ship.x+10, f, 12);  }
     } // End of if.
	       break;

    case 'q':
		   {
		   Done=1;
		   key_tap();
		   lose();
		   quiet();
		    } break;


		      } // End of switch.

			} // End of while keyboard hit.


       //Reinstate bomber. //////////////////////////////////

       if (Bomber.dead) {

    switch (1+rand() %500) {

    case 100: key_tap();
	      Bomber.dead = 0;
	      bomber.y = 10;
	      break;

	      } // End of bomber relife switch.
	       } // End of if bomber dead if.

  ///////////////////////////////////////////////////////////////


// Enemy one movement./////////////////////////////////////////////////////////////

if (level == 1 || level == 2 || level >= 3) {

   switch (1+rand() %20) {

      case 10:  if (!Enemy1.dead && !player.dead) {
		for (index=enemy1.y; index <= 200; index++) {

	       if (P_ship.x <= enemy1.x+10 && P_ship.x >= enemy1.x-10)
	       if (index == P_ship.y) {

		for (index=0; index<=100; index++)
		Write_Pixel (P_ship.x+rand() %20, P_ship.y+rand() %20, 12);
		P_ship.x=-130; P_ship.y=-130;
		player.dead = 1; hit(); }  // End collision detection if.

		buzz(750); buzz(1500); quiet();
		Write_Pixel (4+enemy1.x, index, 1+rand() %256);
		  } // End of enemy fire.
		   } // ---------------
		break;

	       } // End of switch.


//   Enemy one touching ship detection.

   if (enemy1.x <= P_ship.x+10 && enemy1.x >= P_ship.x-10)
   if (enemy1.y <= P_ship.y+10 && enemy1.y >= P_ship.y-10) {

	for (index=0; index<=100; index++)
   Write_Pixel (P_ship.x+rand() %30, P_ship.y+rand() %30, 12);
   P_ship.x=-130; P_ship.y=-130;
   player.dead = 1;
    hit();
    } // End if collision detection.

   if (!Enemy1.dead && !player.dead) {
       if (enemy1.x < P_ship.x) { space(); enemy1.x+=2; }
       if (enemy1.y < P_ship.y) { space(); enemy1.y+=2; }
       if (enemy1.x > P_ship.x) { space(); enemy1.x-=2; }
       if (enemy1.y > P_ship.y) { space(); enemy1.y-=2; }
   if (++enemy1.curr_frame >= 4) enemy1.curr_frame = 0;

  } // End of enemy dead sequence.


  if (player.dead) {
   if (++enemy1.curr_frame == 4) enemy1.curr_frame = 0;
   if (--enemy1.x <= 0 && --enemy1.y <= 0) {
   enemy1.x = 0; enemy1.y = 0;  } // End  if.
   } // End if.

   } // End of level one if.
// End of enemy one movement. //////////////////////////////////////////////////

// Enemy two movement./////////////////////////////////////////////////////////////

if (level == 2 || level >= 3) {

   switch (1+rand() %20) {

      case 10:  if (!Enemy2.dead && !player.dead) {
		for (index=enemy2.y; index <= 200; index++) {

	       if (P_ship.x <= enemy2.x+10 && P_ship.x >= enemy2.x-10)
	       if (index == P_ship.y) {

		for (index=0; index<=100; index++)
		Write_Pixel (P_ship.x+rand() %20, P_ship.y+rand() %20, 12);
		P_ship.x=-130; P_ship.y=-130;
		player.dead = 1; hit(); }  // End collision detection if.

		buzz(750); buzz(1500); quiet();
		Write_Pixel (4+enemy2.x, index, 1+rand() %256);
		  } // End of enemy fire.
		   } // ---------------
		break;

	       } // End of switch.


//   Enemy two touching ship detection.

   if (enemy2.x <= P_ship.x+10 && enemy2.x >= P_ship.x-10)
   if (enemy2.y <= P_ship.y+10 && enemy2.y >= P_ship.y-10) {

	for (index=0; index<=100; index++)
   Write_Pixel (P_ship.x+rand() %30, P_ship.y+rand() %30, 12);
   P_ship.x=-130; P_ship.y=-130;
   player.dead = 1;
    hit();
    } // End if collision detection.

   if (!Enemy2.dead && !player.dead) {
       if (enemy2.x < P_ship.x) { space(); enemy2.x+=5; }
       if (enemy2.y < P_ship.y) { space(); enemy2.y+=5; }
       if (enemy2.x > P_ship.x) { space(); enemy2.x-=5; }
       if (enemy2.y > P_ship.y) { space(); enemy2.y-=5; }
   if (++enemy2.curr_frame >= 4) enemy2.curr_frame = 0;

  } // End of enemy dead sequence.


  if (player.dead) {
   if (++enemy2.curr_frame == 4) enemy2.curr_frame = 0;
   if (--enemy2.x <= 0 && --enemy2.y <= 0) {
   enemy2.x = 0; enemy2.y = 0;  } // End  if.
   } // End if.

   } // End of level two if.
// End of enemy two movement. //////////////////////////////////////////////////

// Enemy three movement./////////////////////////////////////////////////////////////

if (level >= 3) {

   switch (1+rand() %20) {

      case 10:  if (!Enemy3.dead && !player.dead) {
		for (index=enemy3.y; index <= 200; index++) {

	       if (P_ship.x <= enemy3.x+10 && P_ship.x >= enemy3.x-10)
	       if (index == P_ship.y) {

		for (index=0; index<=100; index++)
		Write_Pixel (P_ship.x+rand() %20, P_ship.y+rand() %20, 12);
		P_ship.x=-130; P_ship.y=-130;
		player.dead = 1; hit(); }  // End collision detection if.

		buzz(750); buzz(1500); quiet();
		Write_Pixel (4+enemy3.x, index, 1+rand() %256);
		  } // End of enemy fire.
		   } // ---------------
		break;

	       } // End of switch.


//   Enemy one touching ship detection.

   if (enemy3.x <= P_ship.x+10 && enemy3.x >= P_ship.x-10)
   if (enemy3.y <= P_ship.y+10 && enemy3.y >= P_ship.y-10) {

	for (index=0; index<=100; index++)
   Write_Pixel (P_ship.x+rand() %30, P_ship.y+rand() %30, 12);
   P_ship.x=-130; P_ship.y=-130;
   player.dead = 1;
    hit();
    } // End if collision detection.

   if (!Enemy3.dead && !player.dead) {
       if (enemy3.x < P_ship.x) { space(); enemy3.x+=2; }
       if (enemy3.y < P_ship.y) { space(); enemy3.y+=2; }
       if (enemy3.x > P_ship.x) { space(); enemy3.x-=2; }
       if (enemy3.y > P_ship.y) { space(); enemy3.y-=2; }
   if (++enemy3.curr_frame >= 4) enemy3.curr_frame = 0;

  } // End of enemy dead sequence.


  if (player.dead) {
   if (++enemy3.curr_frame == 4) enemy3.curr_frame = 0;
   if (--enemy3.x <= 0 && --enemy3.y <= 0) {
   enemy3.x = 0; enemy3.y = 0;  } // End  if.
   } // End if.

   } // End of level three and higher if.
// End of enemy three movement. //////////////////////////////////////////////////

// alien one movement. //////////////////////////////////////////////////////


 if (Enemy1.dead) {

  enemy1.x = -11; enemy1.y = -11;

  if (alien1.x++ >= 320) alien1.x = -130;
  if (alien1.y++ > 200) alien1.y = -130;

  if (++alien1.curr_frame == 16) alien1.curr_frame = 0;  }   // End of alien.


// End of alien one movement. ///////////////////////////////////////////////

// alien two movement. //////////////////////////////////////////////////////


 if (Enemy2.dead) {

  enemy2.x = -10; enemy2.y = -25;

  if (alien2.x++ >= 320) alien2.x = -130;
  if (alien2.y++ > 200) alien2.y = -130;

  if (++alien2.curr_frame == 16) alien2.curr_frame = 0;  }   // End of alien.


// End of alien two movement. //////////////////////////////////////////////////

// alien three movement. //////////////////////////////////////////////////////


 if (Enemy3.dead) {

  enemy3.x = -10; enemy3.y = -110;

  if (alien3.x++ >= 320) alien3.x = -130;
  if (alien3.y++ > 200) alien3.y = -130;

  if (++alien3.curr_frame == 16) alien3.curr_frame = 0;  }   // End of alien.


// End of alien three movement. ///////////////////////////////////////////////

// Bomber movement ////////////////////////////////////////////////////////////

  if (bomber.x-- <= 0 && !Bomber.dead) bomber.x = 320;
  if (++bomber.curr_frame >= 2 && !Bomber.dead) bomber.curr_frame = 0;
  if (bomber.x <= 0) Bomber.dead = 1;
  if (!Bomber.dead) { buzz(2000); quiet(); }


 // Bomb movement. ///////////////////////////////////////////////////////////

 if (!Bombs.bombs_once && !Bomber.dead && !Bombs.dead)
 { bombs.x = bomber.x; Bombs.bombs_once = 1; bombs.y = bomber.y; } // End if.


 if (!Bombs.dead && !Bomber.dead) {
 bombs.y+=5;
 if (++bombs.curr_frame >= 4) bombs.curr_frame = 0; }  // End if.


 if (bombs.y >= 190)  Bombs.bombs_once = 0;

 if (Bomber.dead) { bombs.x = -115; bombs.y = -115; }


 // Monster movement one. /////////////////////////////////////////////////////////

 if (monster1.x >= 320) monster1.x = -200;
 if (monster1.y >= 200) monster1.y = -200;

 monster1.x+= 5;
 monster1.y++;

if (++monster1.curr_frame >= 4) monster1.curr_frame = 0;

// Monster movement two. /////////////////////////////////////////////////////////

 if (monster2.x >= 320) monster2.x = -200;
 if (monster2.y >= 200) monster2.y = -200;

 monster2.x+= 5;
 monster2.y++;

if (++monster2.curr_frame >= 4) monster2.curr_frame = 0;


 // Bombs collision detection. ///////////////////////////////////////////////

   if (bombs.x <= P_ship.x+10 && bombs.x >= P_ship.x-10)
   if (bombs.y <= P_ship.y+10 && bombs.y >= P_ship.y-10) {

	for (index=0; index<=100; index++)
   Write_Pixel (P_ship.x+rand() %30, P_ship.y+rand() %30, 12);

   P_ship.x=-130; P_ship.y=-130;
   player.dead = 1; Bombs.bombs_once = 0;
    hit();
    } // End if collision detection.


   //Asteroid movement. ////////////////////////////////////////////////////////

   if (Bombs.dead) {
   bombs.x = -100; bombs.y = -100;
   Asteroid1.dead = 0;
   asteroid1.y+=5;
   if (++asteroid1.curr_frame == 8) asteroid1.curr_frame = 0; }

   if (asteroid1.y >= 185) {
    Asteroid1.dead = 1;
    asteroid1.x = -200; asteroid1.y = -200;
    Bombs.dead = 0; }


  // Asteroid collision detection. ///////////////////////////////////////////

   if (asteroid1.x <= P_ship.x+10 && asteroid1.x >= P_ship.x-10)
   if (asteroid1.y <= P_ship.y+10 && asteroid1.y >= P_ship.y-10) {

   asteroid1.x= -200; asteroid1.y= -200;
   Asteroid1.dead = 1;
    win(); score += 1000;
    } // End if collision detection.


 // Blue movement. ///////////////////////////////////////////////////////////

 if (level == 1 || level == 2 || level >= 3) {

 if (blue1.y <= 85 && !Blue1.dead && !Blue1.bombs_once) {
  blue1.y += 20; beep();
   if (blue1.y >= 85) Blue1.bombs_once = 1; } // End if.

 if (++blue1.curr_frame >= 8) blue1.curr_frame = 0;


 if (!Blue1.dead && !player.dead && Blue1.bombs_once) {

       if (blue1.x < P_ship.x) blue1.x++;
       if (blue1.y < P_ship.y) blue1.y++;
       if (blue1.x > P_ship.x) blue1.x--;
       if (blue1.y > P_ship.y) blue1.y--;

   } // End if.


  // blue collision detection. ///////////////////////////////////////////

   if (blue1.x <= P_ship.x+10 && blue1.x >= P_ship.x-10)
   if (blue1.y <= P_ship.y+10 && blue1.y >= P_ship.y-10) {
	for (index=0; index<=100; index++)
   Write_Pixel (P_ship.x+rand() %30, P_ship.y+rand() %30, 12);
   P_ship.x=-130; P_ship.y=-130;
   player.dead = 1;
    hit();
    } // End if collision detection.

 // Blue one rapid fire. /////////////////////////////////////////////////////


     switch (1+rand() %45) {

      case 10:  if (!Blue1.dead && !player.dead) {
		for (index=15+blue1.y; index <= 200; index++) {

	       if (P_ship.x <= blue1.x+10 && P_ship.x >= blue1.x-10)
	       if (index == P_ship.y) {

		for (index=0; index<=100; index++)
		Write_Pixel (P_ship.x+rand() %20, P_ship.y+rand() %20, 12);
		P_ship.x=-130; P_ship.y=-130;
		player.dead = 1; hit(); }  // End collision detection if.

		buzz(750); buzz(1500); quiet();
		Write_Pixel (12+blue1.x, index, 1+rand() %256);

		  } // End of blue fire.
		   } // ---------------
		break;

	       } // End of switch.
		} // End of level one if.

  // Blue two movement. ///////////////////////////////////////////////////////////

  if (level == 2 || level >= 3) {

 if (blue2.y <= 85 && !Blue2.dead && !Blue2.bombs_once) {
  blue2.y += 20; beep();
   if (blue2.y >= 85) Blue2.bombs_once = 1; } // End if.

 if (++blue2.curr_frame >= 8) blue2.curr_frame = 0;


 if (!Blue2.dead && !player.dead && Blue2.bombs_once) {

       if (blue2.x < P_ship.x) blue2.x++;
       if (blue2.y < P_ship.y) blue2.y++;
       if (blue2.x > P_ship.x) blue2.x--;
       if (blue2.y > P_ship.y) blue2.y--;

   } // End if.


  // blue two collision detection. ///////////////////////////////////////////

   if (blue2.x <= P_ship.x+10 && blue2.x >= P_ship.x-10)
   if (blue2.y <= P_ship.y+10 && blue2.y >= P_ship.y-10) {
	for (index=0; index<=100; index++)
   Write_Pixel (P_ship.x+rand() %30, P_ship.y+rand() %30, 12);
   P_ship.x=-130; P_ship.y=-130;
   player.dead = 1;
    hit();
    } // End if collision detection.

 // Blue two rapid fire. /////////////////////////////////////////////////////


     switch (1+rand() %45) {

      case 10:  if (!Blue2.dead && !player.dead) {
		for (index=15+blue2.y; index <= 200; index++) {

	       if (P_ship.x <= blue2.x+10 && P_ship.x >= blue2.x-10)
	       if (index == P_ship.y) {

		for (index=0; index<=100; index++)
		Write_Pixel (P_ship.x+rand() %20, P_ship.y+rand() %20, 12);
		P_ship.x=-130; P_ship.y=-130;
		player.dead = 1; hit(); }  // End collision detection if.

		buzz(750); buzz(1500); quiet();
		Write_Pixel (12+blue2.x, index, 1+rand() %256);

		  } // End of blue two fire.
		   } // ---------------
		break;

	       } // End of switch.
		 } // End of level two if.

   // Blue three movement. ///////////////////////////////////////////////////////////

   if (level >= 3) {

 if (blue3.y <= 85 && !Blue3.dead && !Blue3.bombs_once) {
  blue3.y += 20; beep();
   if (blue3.y >= 85) Blue3.bombs_once = 1; } // End if.

 if (++blue3.curr_frame >= 8) blue3.curr_frame = 0;


 if (!Blue3.dead && !player.dead && Blue3.bombs_once) {

       if (blue3.x < P_ship.x) blue3.x++;
       if (blue3.y < P_ship.y) blue3.y++;
       if (blue3.x > P_ship.x) blue3.x--;
       if (blue3.y > P_ship.y) blue3.y--;

   } // End if.


  // blue three collision detection. ///////////////////////////////////////////

   if (blue3.x <= P_ship.x+10 && blue3.x >= P_ship.x-10)
   if (blue3.y <= P_ship.y+10 && blue3.y >= P_ship.y-10) {
	for (index=0; index<=100; index++)
   Write_Pixel (P_ship.x+rand() %30, P_ship.y+rand() %30, 12);
   P_ship.x=-130; P_ship.y=-130;
   player.dead = 1;
    hit();
    } // End if collision detection.

 // Blue three rapid fire. /////////////////////////////////////////////////////


     switch (1+rand() %45) {

      case 10:  if (!Blue3.dead && !player.dead) {
		for (index=15+blue3.y; index <= 200; index++) {

	       if (P_ship.x <= blue3.x+10 && P_ship.x >= blue3.x-10)
	       if (index == P_ship.y) {

		for (index=0; index<=100; index++)
		Write_Pixel (P_ship.x+rand() %20, P_ship.y+rand() %20, 12);
		P_ship.x=-130; P_ship.y=-130;
		player.dead = 1; hit(); }  // End collision detection if.

		buzz(750); buzz(1500); quiet();
		Write_Pixel (12+blue3.x, index, 1+rand() %256);

		  } // End of blue three fire.
		   } // ---------------
		break;

	       } // End of switch.
		 } // End of level three and higher if.

// END PATTERN MOTION LOGIC //////////////////////////////////////////////////


   // ready to draw sprites, but first scan background under it

if (!player.dead) Sprite_Under_Clip((sprite_ptr)&P_ship,double_buffer);

if (level == 1 || level == 2 || level >= 3)
if (!Enemy1.dead) Sprite_Under_Clip((sprite_ptr)&enemy1,double_buffer);

if (level == 2 || level >= 3)
if (!Enemy2.dead) Sprite_Under_Clip((sprite_ptr)&enemy2,double_buffer);

if (level >= 3)
if (!Enemy3.dead) Sprite_Under_Clip((sprite_ptr)&enemy3,double_buffer);

if (!Alien1.dead) Sprite_Under_Clip((sprite_ptr)&alien1,double_buffer);
if (!Alien2.dead) Sprite_Under_Clip((sprite_ptr)&alien2,double_buffer);
if (!Alien3.dead) Sprite_Under_Clip((sprite_ptr)&alien3,double_buffer);
if (!Bomber.dead) Sprite_Under_Clip((sprite_ptr)&bomber,double_buffer);
if (!Bombs.dead) Sprite_Under_Clip((sprite_ptr)&bombs,double_buffer);
if (!Asteroid1.dead) Sprite_Under_Clip((sprite_ptr)&asteroid1,double_buffer);
if (!Monster1.dead) Sprite_Under_Clip((sprite_ptr)&monster1,double_buffer);
if (!Monster2.dead) Sprite_Erase_Clip((sprite_ptr)&monster2,double_buffer);

if (level == 1 || level == 2 || level >= 3)
if (!Blue1.dead) Sprite_Under_Clip((sprite_ptr)&blue1,double_buffer);

if (level == 2 || level >= 3)
if (!Blue2.dead) Sprite_Under_Clip((sprite_ptr)&blue2,double_buffer);

if (level >= 3)
if (!Blue3.dead) Sprite_Under_Clip((sprite_ptr)&blue3,double_buffer);

if (!player.dead) Sprite_Draw_Clip((sprite_ptr)&P_ship,double_buffer,1);

if (level == 1 || level == 2 || level >= 3)
if (!Enemy1.dead) Sprite_Draw_Clip((sprite_ptr)&enemy1,double_buffer,1);

if (level == 2 || level >= 3)
if (!Enemy2.dead) Sprite_Draw_Clip((sprite_ptr)&enemy2,double_buffer,1);

if (level >= 3)
if (!Enemy3.dead) Sprite_Draw_Clip((sprite_ptr)&enemy3,double_buffer,1);

if (!Alien1.dead) Sprite_Draw_Clip((sprite_ptr)&alien1,double_buffer,1);
if (!Alien2.dead) Sprite_Draw_Clip((sprite_ptr)&alien2,double_buffer,1);
if (!Alien3.dead) Sprite_Draw_Clip((sprite_ptr)&alien3,double_buffer,1);
if (!Bomber.dead) Sprite_Draw_Clip((sprite_ptr)&bomber,double_buffer,1);
if (!Bombs.dead) Sprite_Draw_Clip((sprite_ptr)&bombs,double_buffer,1);
if (!Asteroid1.dead) Sprite_Draw_Clip((sprite_ptr)&asteroid1,double_buffer,1);
if (!Monster1.dead) Sprite_Draw_Clip((sprite_ptr)&monster1,double_buffer,1);
if (!Monster2.dead) Sprite_Draw_Clip((sprite_ptr)&monster2,double_buffer,1);

if (level == 1 || level == 2 || level >= 3)
if (!Blue1.dead) Sprite_Draw_Clip((sprite_ptr)&blue1,double_buffer,1);

if (level == 2 || level >= 3)
if (!Blue2.dead) Sprite_Draw_Clip((sprite_ptr)&blue2,double_buffer,1);

if (level >= 3)
if (!Blue3.dead) Sprite_Draw_Clip((sprite_ptr)&blue3,double_buffer,1);


     // display double buffer

     Display_Double_Buffer(double_buffer,0);



     // lock onto 18 frames per second max

     delay(queue.Time()); // Game speed.
     Fire++; // Fire delay.
     Move++; // Move delay.
     if (player.dead) wait++; // Return ship delay.

     } // End of main while.

     ship();
     delay (4000);

// exit in a very cool way

Screen_Transition(SCREEN_DARKNESS);

Set_Graphics_Mode(TEXT_MODE);

// Entering scores ////////////////////////////////////////


 if (level >= 3) {


  cout << "\n\n                           **** NAMES AND SCORES*****" << endl;

   cout << "\n\nEnter your name: ";
   cin >> name;

   cout << "\n\n"; // Space.

   outputOK = fileout();

   if (outputOK == 0) { inputOK = filein(); }

   } // End if.

   cout << "\n\n\nHit any key to exit.." << endl;

   getch();

// free up all resources ///////////////////////////////////

Sprite_Delete((sprite_ptr)&P_ship);
Sprite_Delete((sprite_ptr)&enemy1);
Sprite_Delete((sprite_ptr)&enemy2);
Sprite_Delete((sprite_ptr)&enemy3);
Sprite_Delete((sprite_ptr)&alien1);
Sprite_Delete((sprite_ptr)&alien2);
Sprite_Delete((sprite_ptr)&alien3);
Sprite_Delete((sprite_ptr)&bomber);
Sprite_Delete((sprite_ptr)&bombs);
Sprite_Delete((sprite_ptr)&asteroid1);
Sprite_Delete((sprite_ptr)&monster1);
Sprite_Delete((sprite_ptr)&monster2);
Sprite_Delete((sprite_ptr)&blue1);
Sprite_Delete((sprite_ptr)&blue2);
Sprite_Delete((sprite_ptr)&blue3);


Delete_Double_Buffer();

Set_Graphics_Mode(TEXT_MODE);

pong();

return (inputOK && outputOK);

} // end main



   // F U N C T I O N S ///////////////////////////////////////////////////

   void points()
   {

  sprintf (buffer, "LEVEL: %d", level);
  Print_String_DB (257, 2, 102, buffer, 0);

  sprintf (buffer, "SHIPS: %d", SHips);
  Print_String_DB (2, 2, 32, buffer, 0);

  sprintf (buffer, "SCORE: %d", score);
  Print_String_DB (90, 2, random(256), buffer, 0);

  } // End of function.


// L E V E L  A D D ////////////////////////////////////....

void Level_Add()
{

  if (level == 1) {

  if (header1) {

  hit();

 Print_String (75, 30, 67, "Assault phase one.. ", 1);

 Print_String (75, 55, 12, "Get Ready !!", 1);
 header1 = 0;
 delay(2500);
 Screen_Transition(SCREEN_SWIPE_X);
 pong();


 } // End of header1 if.

  if (Enemy1.dead && Blue1.dead && Bomber.dead) {
   Blue1.dead=0, Enemy1.dead=0;
  level++; } // End if.
  } // End level one if.


  if (level == 2) {

  if (header2) {

  hit();

 Print_String (75, 30, 67, "Assault phase two.. ", 1);

 Print_String (75, 55, 12, "Get Ready !!", 0);

 header2 = 0;
 delay(2500);
 Screen_Transition(SCREEN_SWIPE_X);
 pong();


 } // End of header2 if.

  if (Enemy1.dead && Enemy2.dead && Blue1.dead && Blue2.dead &&
   Bomber.dead) {
   Blue1.dead=0, Blue2.dead=0, Enemy1.dead=0, Enemy2.dead=0;
  level++; } // End if.
  } // End level two if.


 if (level >= 3) {

  if (header3) {

  hit();

 Print_String (10, 30, 100, "Assault phase three, the final level. ", 1);

 Print_String (75, 55, 12, "Get Ready !!", 0);
 header3 = 0;
 delay(2500);
 Screen_Transition(SCREEN_SWIPE_X);
 pong();


 } // End of header3 if.

  if (Enemy1.dead && Enemy2.dead && Enemy3.dead &&
   Blue1.dead && Blue2.dead && Blue3.dead && Bomber.dead) {

   setborderc (1);
   win(); win();
   Print_String (75, 37, 100, "WINNER !!  END OF GAME..  ", 1);
   delay (1500);
   win(); win();
   delay (4000);
     Done = 1;

    } // End if.
     } // End of level three if.

} // End of function.


 // S H I P S ///////////////////////////////////////////////////////////

 void SHIPS()
 {


      if (SHips <= 0) {

      SHips = 0;

      if (wait >= 20) {

      hit();

    Print_String (15, 30, 37, "OUT OF SHIPS !!  END OF GAME..  ", 1);
    setborderc(12);
    delay (2000);
    lose(); lose(); lose();
    delay (2000);
    Done = 1;  } // End of wait.


    } // End if no more ships.


    if (player.dead && SHips > 0 && wait >= 40) {
     SHips--;

     if (SHips > 0) {
    player.dead = 0;
    P_ship.x = 160; P_ship.y = 170;
    } // End of reinstate player if.

      wait = 0;
      win();

       }  // End if player dead.


   } // End of function.


int filein (void)
{
   // ifstream constructor opens the file
   
   if ( !inClientFile ) {
      cerr << "File could not be opened\n";
      exit( 1 );
   }

   // Sends file in.
   while ( inClientFile >> name >> score )
      outputLine( name, score );

   return (0);  // ifstream destructor closes the file
} // End of function.


void outputLine( char *names, long scores2 )
{
   cout << names << "  " << scores2 << endl;
} // End of function.


int fileout(void)
{
   // ofstream constructor opens the file.

   if ( !outClientFile ) {  // overloaded ! operator
      cerr << "File could not be opened" << endl;
      exit( 1 );    // prototype in stdlib.h
   }

       // Sends file out.
      outClientFile << name << " "<< score << endl;
   
   return (0);  // ofstream destructor closes file
} // End of function.


