/* Game Accessories By Steven Ramponi */

#ifndef GAME_H
#define GAME_H 


#include <conio.h>
#include <iostream.h>
#include "Death.h"


class game {

public:

	game() {}
	~game() {}

	final start; // Instance object from death.h


	void Game_Speed (void) { start.set_speed(); } 

	void Hit_Key (void) { Print(); getch(); }

	int Time (void) { return start.timer; }



private:

	void Print (void) { cout << "\n\n\nHit a key." << endl; }


};



#endif