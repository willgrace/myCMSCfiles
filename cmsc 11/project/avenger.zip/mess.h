#ifndef MESS_H
#define MESS_H


#define WIN32_LEAN_AND_MEAN  
#define INITGUID

#define NUM_DSETUP_RVALUES     14


#include <time.h>
#include <windows.h>    
#include <windowsx.h> 
#include <mmsystem.h>
#include <iostream>  
#include <conio.h>
#include <cstdlib>
#include <malloc.h>
#include <memory.h>
#include <cstring>
#include <stdarg.h>
#include <stdio.h> 
#include <cmath>
#include <io.h>
#include <fcntl.h>
#include <dsetup.h>


using namespace std;


// G L O B A L   V A R I A B L S /////////////////////////////////////////////////////
// exact path of contents of REDIST\
// note the use of "\\" instead of "\"
// this is neccessary since "\" is an escape character
char DIRECTX_REDIST_PATH[]=".\\REDIST";

// a lookup table that holds the return values
DWORD dsetup_rvalues[] = {DSETUPERR_SUCCESS,
                          DSETUPERR_SUCCESS_RESTART,
                          DSETUPERR_BADSOURCESIZE,
                          DSETUPERR_BADSOURCETIME, 
                          DSETUPERR_BADWINDOWSVERSION,
                          DSETUPERR_CANTFINDDIR,
                          DSETUPERR_CANTFINDINF,
                          DSETUPERR_INTERNAL,
                          DSETUPERR_NOCOPY,
                          DSETUPERR_NOTPREINSTALLEDONNT,
                          DSETUPERR_OUTOFDISKSPACE,
                          DSETUPERR_SOURCEFILENOTFOUND,
                          DSETUPERR_UNKNOWNOS,
                          DSETUPERR_USERHITCANCEL };

// another lookup table so the return values can be converted
// into a string for display
char *dsetup_rstrings[] = {"DSETUPERR_SUCCESS",
                           "DSETUPERR_SUCCESS_RESTART",
                           "DSETUPERR_BADSOURCESIZE" ,
                           "DSETUPERR_BADSOURCETIME", 
                           "DSETUPERR_BADWINDOWSVERSION" ,
                           "DSETUPERR_CANTFINDDIR" ,
                           "DSETUPERR_CANTFINDINF" ,
                           "DSETUPERR_INTERNAL" ,
                           "DSETUPERR_NOCOPY" ,
                           "DSETUPERR_NOTPREINSTALLEDONNT" ,
                           "DSETUPERR_OUTOFDISKSPACE" ,
                           "DSETUPERR_SOURCEFILENOTFOUND" ,
                           "DSETUPERR_UNKNOWNOS" ,
                           "DSETUPERR_USERHITCANCEL" };


// G L O B A L   F U N C T I O N S  //////////////////////////////////

DWORD WINAPI DSetupCallback(DWORD Reason, 
                            DWORD MsgType, 
                            char *szMessage, 
                            char *szName, 
                            void *pUpgradeInfo) {

//         generic callback function  
// it simply returns IDOK for status calls, otherwise
// it pops up a messagebox and allows to make the
// decision

if (MsgType==0)        
    return IDOK;

// call the messagebox function and return its value
// DirectSetup is designed to respond to the
// return values of MessageBox

return(MessageBox(main_window_handle, szMessage, 
                  "DirectX Setup Demo -- Running", MsgType));

} // end DSetupCallback //////////////////////////////////////////////


// C L A S S   M E S S ///////////////////////////////////////////////

class mess
{

public:

mess(short length, short GameLength, short ScoreLength, 
	 short ShipLength, short AlienLength)
{ 

		buffer =     new char [length];
		GameText =   new char [GameLength];
		ScoreText =  new char [ScoreLength];
		ShipText =   new char [ShipLength];
		AlienText =  new char [AlienLength];


Score = 0, 
Ships = 6,
Catches = 0, 
counter = 0,
Level = 1, 
enemy_shoot = false, 
stop_fire = false,
once = false,
game_speed = 30,
response = MessageBox(NULL, "WARNING:  this program needs DirectX to run. Would you like to test for DirectX on your system?", "DirectX Needed For This Game", MB_YESNO);

	}

	~mess(){ delete [] buffer,
		     delete [] GameText,
			 delete [] ScoreText,
			 delete [] ShipText,
			 delete [] AlienText; }

	
   void DirX_Install (void);
   void Screen_Text (void);


    long Score;
	short Ships;
	short Catches;
    short counter;
	short Level;
	short game_speed;
	bool enemy_shoot;
	bool stop_fire;
	bool once;


private:

	short response;       // choose to test for directX
	DWORD version;        // used to hold version information
    DWORD revision;       // used to hold revision information
	char messbuffer[256]; //***************
	char TimeText[256]; 
	char *GameText;      // used to print text 
    char *ScoreText;
    char *ShipText;
	char *buffer;
    char *AlienText;   // *******************   

};


 

void mess::DirX_Install (void)
{

if (response == IDYES)
{
   // test if directX is installed, if so then print out
// verison and revision, otherwise install it.
  if (DirectXSetupGetVersion(&version, &revision))
   {
   // build up message
   sprintf(buffer,"DirectX version is %d.%d.%d.%d\n",
                  HIWORD(version), LOWORD(version),
                  HIWORD(revision), LOWORD(revision));

   // display a message box with the info
   MessageBox(NULL,buffer,
              "DirectX Setup...",MB_OK);

   } // End If
else
{
   MessageBox(NULL,"Previous Versions of DirectX not Installed. This program will now install it.",
              "DirectX Setup",MB_OK);

// tell user whats up
MessageBox(main_window_handle,
  "This application installs the\nDirectX Run-Time libraries on your computer.\n\nPress OK to Continue.\n",
  "DirectX Setup -- Starting...",MB_OK);

// set callback function
DirectXSetupSetCallback(DSetupCallback);

// call directsetup
DWORD dsetup_result = 
DirectXSetup(main_window_handle,DIRECTX_REDIST_PATH,DSETUP_DIRECTX);

// test the return value and print out the DirectSetup
// error string

for (int index=0; index<NUM_DSETUP_RVALUES; index++)
    {
    if (dsetup_rvalues[index] == dsetup_result)
        {
        // build up message
        sprintf(messbuffer,"DirectSetup Has Completed.\n\nResult=%s\n\nPress OK to Continue.",dsetup_rstrings[index]);

        // print results of DirectXSetup to user
        MessageBox(main_window_handle,
                   messbuffer,
                   "DirectX Setup -- Final Results",MB_OK);
        break;
        } // End If
    } // End For  

} // End Else

} // End If

} // End Function



void mess::Screen_Text (void)
{
//*********************************************************************
// draw Text to the screen ///////////////////////////////////////////
wsprintf(GameText,"Game Speed: %d", game_speed);
Draw_Text_GDI(GameText,250, 460,RGB(0,255,0), lpddsback);

wsprintf(TimeText,"Game Time: %d Minutes", (clock() / CLOCKS_PER_SEC) / 60);
Draw_Text_GDI(TimeText,240, 430,RGB(0,255,0), lpddsback);

// make sure we get no negitive scoring
if (Score <= 0) Score = 0;

wsprintf(ScoreText,"Score: 0000000%d", Score);
Draw_Text_GDI(ScoreText,250, 10,RGB(0,255,0), lpddsback);

wsprintf(AlienText,"Alien Catches: %d", Catches);
Draw_Text_GDI(AlienText,475, 10,RGB(0,255,0), lpddsback);

wsprintf(ShipText,"Ships: %d", Ships);
Draw_Text_GDI(ShipText,10, 10,RGB(255,100,255), lpddsback);
//****************************************************
} // End Function


#endif		