#ifndef LOADUP_H
#define LOADUP_H



#include <windows.h>   // include important windows stuff
#include <windowsx.h> 
#include <mmsystem.h>
#include <iostream> // include important C/C++ stuff
#include <conio.h>
#include <cstdlib>
#include <malloc.h>
#include <memory.h>
#include <ctime>
#include <cstring>
#include <stdarg.h>
#include <stdio.h> 
#include <cmath>
#include <io.h>
#include <fcntl.h>
#include <ddraw.h>  // directX includes
#include <dsound.h>
#include <dinput.h>
#include "gpdumb1.h" // game library includes
#include "gpdumb2.h"



using namespace std;

// GLOBALS /////////////////////////////////////////////////
BITMAP_IMAGE background_bmp;   // holds the background

bool Done = false; // end looping intro

// PROTOTYPES /////////////////////////////////////////////
void Do_Intro(void);
void Game_Image(void);



// F U N C T I O N  D E F I N I T I O N S ////////////////////////////


// I N T R O //////////////////////////////////////////////
void Do_Intro (void)
{
   short shade = 0; // used as looping var

	// load bitmap into primary buffer
Load_Bitmap_File(&bitmap8bit, "BEGIN.BMP");
Create_Bitmap(&background_bmp,0,0,640,480);
Load_Image_Bitmap(&background_bmp, &bitmap8bit,0,0,BITMAP_EXTRACT_MODE_CELL);
DD_Lock_Primary_Surface();
Draw_Bitmap(&background_bmp,primary_buffer, primary_lpitch, 0);
DD_Unlock_Primary_Surface();
Unload_Bitmap_File(&bitmap8bit);
Destroy_Bitmap(&background_bmp);

 
for (shade=0; shade < 256; shade++)
    {
    // draw text in shades
    Draw_Text_GDI("STEVEN RAMPONI GAMES INC.",320-4*strlen("STEVEN RAMPONI GAMES INC."),10,
                   RGB(shade,shade,shade),lpddsprimary);

    Sleep(2);

    // is user trying to bail
    if (KEY_DOWN(VK_ESCAPE))
        return;

    } // end for shade

Sleep(2000);

for (shade=0; shade < 256; shade++)
    {
    // draw text in shades
    Draw_Text_GDI("- PRESENTS -",320-4*strlen("- PRESENTS -"),200,
                   RGB(shade,shade,shade),lpddsprimary);
    Sleep(2);
    
    // is user trying to bail
    if (KEY_DOWN(VK_ESCAPE))
        return;

    } // end for shade

Sleep(2000);

for (shade=255; shade >=0; shade--)
    {
    // draw text in shades
    Draw_Text_GDI("- PRESENTS -",320-4*strlen("- PRESENTS -"),200,
                   RGB(0,0,shade),lpddsprimary);
    Sleep(2);
    
    // is user trying to bail
    if (KEY_DOWN(VK_ESCAPE))
        return;

    } // end for shade

Sleep(1000);

for (shade=0; shade < 256; shade++)
    {
    // draw text in shades
    Draw_Text_GDI("A STEVE RAMPONI PRODUCTION",320-4*strlen("A STEVE RAMPONI PRODUCTION"),200,
                   RGB(shade,shade,shade),lpddsprimary);
    Sleep(2);
    
    // is user trying to bail
    if (KEY_DOWN(VK_ESCAPE))
        return;

    } // end for shade

Sleep(1000);

for (shade=255; shade >=0; shade--)
    {
    // draw text in shades
    Draw_Text_GDI("A STEVE RAMPONI PRODUCTION",320-4*strlen("A STEVE RAMPONI PRODUCTION"),200,
                   RGB(0,0,shade),lpddsprimary);
    Sleep(2);
    
    // is user trying to bail
    if (KEY_DOWN(VK_ESCAPE))
        return;

    } // end for shade

Sleep(1000);

for (shade=0; shade < 256; shade++)
    {
    // draw text in shades
    Draw_Text_GDI("A V E N G E R !",320-3*strlen("A V E N G E R !"),200,
                   RGB(shade,shade,shade),lpddsprimary);
    Sleep(2);

    // is user trying to bail
    if (KEY_DOWN(VK_ESCAPE))
        return;    

    } // end for shade

Sleep(2000);

for (shade=255; shade >=0; shade--)
    {
    // draw text in shades
    Draw_Text_GDI("A V E N G E R !",320-3*strlen("A V E N G E R !"),200,
                   RGB(0,0,shade),lpddsprimary);
    Sleep(2);
  
    // is user trying to bail
    if (KEY_DOWN(VK_ESCAPE))
        return;  

    } // end for shade

// get instructions ///////////////////////////////////////////////
while (!Done)

{

if (KEY_DOWN(VK_SPACE) || keyboard_state[DIK_SPACE]) Done = true;

Draw_Text_GDI("I N S T R UC T I O N S:",340-4*strlen("I N S T R U C T I O N S"),100,
RGB(shade,shade,shade),lpddsprimary);

Draw_Text_GDI("Save all blue falling aliens by catching them with your ship and shoot everything else in sight.",
410-4*strlen("Save all blue falling aliens by catching them with your ship and shoot everything else in sight."),160,
RGB(shade,shade,shade),lpddsprimary);

Draw_Text_GDI("Need to catch six aliens to get to the next level.",355-4*strlen("Need to catch ten aliens to get to the next level."),210,
RGB(shade,shade,shade),lpddsprimary);

Draw_Text_GDI("SHIP MOVEMENT: Use arrow keys.",325-4*strlen("SHIP MOVEMENT: Use arrow keys."),300,
RGB(shade,shade,shade),lpddsprimary);

Draw_Text_GDI("FIRE BUTTON: Spacebar.",320-4*strlen("FIRE BUTTON: Spacebar."),340,
RGB(shade,shade,shade),lpddsprimary);

Draw_Text_GDI("Hit spacebar to start.",330-4*strlen("Hit spacebar to start."),420,
RGB(shade,shade,shade),lpddsprimary);

Draw_Text_GDI("Level: 1",315-4*strlen("Level: 1"),450,
RGB(shade,shade,shade),lpddsprimary);


} // End While


} // End Of Intro ///////////////////////////////////////////////////


void Game_Image (void)
{
	// load background game image
Load_Bitmap_File(&bitmap8bit, "GHOSTBACK.BMP");
Create_Bitmap(&background_bmp,0,0,640,480);
Load_Image_Bitmap(&background_bmp, &bitmap8bit,0,0,BITMAP_EXTRACT_MODE_ABS);
Set_Palette(bitmap8bit.palette);
Unload_Bitmap_File(&bitmap8bit);

} // End Game Image ///////////////////////////////////////



#endif