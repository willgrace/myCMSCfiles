/*----------------------------------------------------------------
 * gamevars.h -- declarations of game-global variables
 *----------------------------------------------------------------
 *  These variables are accessed by the layer just 
 *  underneath game.c, and by game.c itself of course.
 */

#ifndef gf_included_gamevars_h
#define gf_included_gamevars_h


extern int game_end_flag;
extern int game_score;


#endif
