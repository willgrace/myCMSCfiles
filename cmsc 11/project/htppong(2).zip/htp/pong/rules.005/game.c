/*----------------------------------------------------------------
 * game.c -- game control routiunes
 *----------------------------------------------------------------
 *  Here I put the main game control routines.  They're normally
 *  pretty much the same, for most games.  The game_init function
 *  calls the initialisation functions for subsidiary modules as
 *  well as setting up anything this module needs.  game_shutdown
 *  reverses what game_init does -- it's generally a good idea to
 *  keep relationships between functions simple like this. 
 *  game_run plays one game; most of its work should be done by
 *  subsidiary modules.
 */


#include <allegro.h>

#include "game.h"
#include "gamevars.h"
#include "input.h"
#include "display.h"
#include "objects.h"


/* game_end_flag:
 *  This flag is used to end the game -- when it is nonzero, 
 *  the game will end.
 */
int game_end_flag = 0;


/* game_score:
 *  This is the player's score (number of times ball hits bat).
 */
int game_score = 0;


/* game_init:
 *  This function sets everything up ready to play through the 
 *  game once.
 */
void game_init() {
	game_end_flag = 0;
	game_score = 0;

	display_init();
	input_init();
	objects_init();
}


/* game_shutdown:
 *  Undo everything that game_init set up.
 */
void game_shutdown() {
	objects_shutdown();
	input_shutdown();
	display_shutdown();
}


/* game_run:
 *  This function actually plays the game.
 */
void game_run() {
	while (!game_end_flag) {
		input_update();
		objects_update();
		display_update();
	}
}
