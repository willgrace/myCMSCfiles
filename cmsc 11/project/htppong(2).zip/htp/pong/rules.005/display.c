/*----------------------------------------------------------------
 * display.c -- display routines
 *----------------------------------------------------------------
 *  This module takes care of everything relating to the
 *  screen display.
 */


#include <math.h>
#include <stdio.h>
#include <string.h>
#include <allegro.h>

#include "display.h"
#include "objdisp.h"
#include "layout.h"
#include "gamevars.h"


/* Various bitmaps used in the game:
 *	`arena' will be a subbitmap of the screen; all of the 
 *		objects in the game will be drawn there.
 *	`arena_bkgnd' will hold the image of the empty arena;
 *		game objects will use this to restore the background
 *		as they move.
 *	`status_bar' will be a subbitmap of the top of the screen,
 *		for writing status information to.
 *	`palette' will be the palette in use during the game.
 */
static BITMAP *arena, *arena_bkgnd, *status_bar;
static PALETTE palette;


/* write_colour: (local)
 *  This function just updates an entry in a palette, given the
 *  palette, a colour index, and the new R, G and B values.
 */
static void write_colour (RGB *pal, int i, int r, int g, int b) {
	pal[i].r = r;
	pal[i].g = g;
	pal[i].b = b;
}

/* make_palette: (local)
 *  This function puts the palette we want into the variable.  In
 *  this game the palette is determined algorithmically (i.e. we
 *  calculate it); if the game used sprites we'd probably load a
 *  palette in from the sprite image file and use that, for
 *  obvious reasons.
 */
static void make_palette (RGB *pal) {
	int i, r, g, b;

	/* Start with a black palette */
	memset (pal, 0, 256 * sizeof (RGB));

	/* Let's use the EGA palette for the bottom 16 colours... */ 
	for (i = 0; i < 8; i++) {
		r = ((i & 4) != 0);
		g = ((i & 2) != 0);
		b = ((i & 1) != 0);
		write_colour (pal, i, r * 31, g * 31, b * 31);
		write_colour (pal, i + 8, r * 63, g * 63, b * 63);
	}
	write_colour (pal, 8, 15, 15, 15);

	/* ... and make a gradient in blue for the next 16 */
	for (i = 0; i < 16; i++)
		write_colour (pal, i + 16, 0, 0, 16 + 2 * i);
}

/* make_background: (local)
 *  This function draws a background to the given bitmap.  A
 *  solid colour gets a bit boring to look at...
 */
static void make_background (BITMAP *bmp) {
	int x, y, w, h, col, blocksize = 32;

	w = (bmp->w / blocksize) + 1;
	h = (bmp->h / blocksize) + 1;

	for (x = 0; x < blocksize; x++)
		for (y = x; y < blocksize; y++) {
			col = (sin (x * 2 * 3.141592654 / blocksize) + sin (y * 2 * 3.141592654 / blocksize)) * 4;
			if (col < -7) col = -7;
			else if (col > 7) col = 7;
			col += 24;
			putpixel (bmp, x, y, col);
			if (y != x) putpixel (bmp, y, x, col);
		}

	for (x = 0; x < w; x++)
		for (y = 0; y < h; y++)
			if (x + y) blit (bmp, bmp, 0, 0, x * blocksize, y * blocksize, blocksize, blocksize);
}

/* display_init:
 *  Called once, at the start of the game.
 */
void display_init() {
	if (set_gfx_mode (GFX_AUTODETECT, screen_width, screen_height, 0, 0) < 0)
		abort();

	make_palette(palette);
	set_palette(palette);

	/* Make subbitmaps to simplify access to certain parts of the screen */
	arena = create_sub_bitmap (screen, arena_x, arena_y, arena_width, arena_height);
	status_bar = create_sub_bitmap (screen, status_x, status_y, status_width, status_height);

	/* arena_bkgnd is the background bitmap of the arena */
	arena_bkgnd = create_bitmap (arena_width, arena_height);

	if (!arena || !status_bar || !arena_bkgnd)
		abort();

	clear (arena_bkgnd);
	make_background (arena_bkgnd);
	line (arena_bkgnd, 0, arena_height - 1, 0, 0, 7);
	line (arena_bkgnd, 0, 0, arena_width - 1, 0, 7);
	line (arena_bkgnd, arena_width - 1, 0, arena_width - 1, arena_height - 1, 7);

	blit (arena_bkgnd, arena, 0, 0, 0, 0, arena_width, arena_height);
}

/* display_shutdown:
 *  Called after the game; should undo everything ~_init does.
 */
void display_shutdown() {
	destroy_bitmap (arena);
	destroy_bitmap (arena_bkgnd);
	destroy_bitmap (status_bar);
}


/* draw_status_bar: (local)
 *  Not surprisingly, this draws the status bar.
 */
static void draw_status_bar() {
	char string[100];
	sprintf (string, "Score: %d", game_score);
	text_mode (0);    /* you should always update this before writing text */
	textout (status_bar, font, string, 0, 0, 15);
}

/* display_update:
 *  This is called every cycle, to update the screen display.
 *
 *  Note that it is a slow routine; display routines tend to 
 *  be slow, and this one includes a vsync.
 */
void display_update() {
	vsync();
	draw_status_bar();
	objects_erase (arena, arena_bkgnd);
	objects_draw (arena);
}
