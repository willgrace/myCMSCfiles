/*----------------------------------------------------------------
 * layout.h -- declarations of layout variables
 *----------------------------------------------------------------
 *  These variables define the screen layout.  The colour 
 *  variables found their way in here too, for want of a better
 *  place to put them.
 */

#ifndef gf_included_layout_h
#define gf_included_layout_h


extern const int screen_width, screen_height;
extern const int arena_width, arena_height, arena_x, arena_y;
extern const int status_width, status_height, status_x, status_y;

extern const int bat_height, bat_length;

extern const int bat_colour, ball_colour;


#endif
