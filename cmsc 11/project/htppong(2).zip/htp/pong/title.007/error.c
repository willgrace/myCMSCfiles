/*----------------------------------------------------------------
 * error.c -- error handling functions
 *----------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <allegro.h>

#include "error.h"


/* error_x:
 *  This function does not return.  It terminates the program, 
 *  printing filename, line, s1 and (if it is not NULL) s2.
 *
 *  The filename and line number are normally supplied by the
 *  `error' macro defined in error.h.
 */
void error_x (char *filename, int line, char *s1, char *s2)
{
	set_gfx_mode (GFX_TEXT, 0, 0, 0, 0);
	fprintf (stderr, "Critical error:\n");
	fprintf (stderr, "%s:%d: %s", filename, line, s1);
	if (s2) fprintf (stderr, " (%s)", s2);
	fprintf (stderr, "\n");
	exit (EXIT_FAILURE);
}
