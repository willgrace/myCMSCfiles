/*----------------------------------------------------------------
 * title.h -- interface to title.c
 *----------------------------------------------------------------
 */

#ifndef gf_included_title_h
#define gf_included_title_h


void title_init();
void title_shutdown();
void title_screen();


#endif
