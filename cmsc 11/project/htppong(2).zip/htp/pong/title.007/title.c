/*----------------------------------------------------------------
 * title.c -- title screen routines
 *----------------------------------------------------------------
 */


#include <allegro.h>

#include "error.h"
#include "title.h"


static BITMAP *graphic;
static PALETTE palette;

/* title_init:
 *  Loads the title screen graphic.
 */ 
void title_init() {
	graphic = load_bitmap ("title.pcx", palette);
	if (!graphic) error ("Unable to load title graphic",NULL);
}

/* title_shutdown:
 *  Tidies up.
 */
void title_shutdown() {
	destroy_bitmap (graphic);
}

/* title_screen:
 *  Displays the title screen.
 */
void title_screen() {
	if (set_gfx_mode (GFX_AUTODETECT, 320, 200, 0, 0) < 0)
		error ("Unable to set video mode", allegro_error);
	set_palette (black_palette);
	blit (graphic, screen, 0, 0, 0, 0, 320, 200);
	fade_in (palette, 3);
	readkey();
	fade_out (5);
}
