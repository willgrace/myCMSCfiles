/*----------------------------------------------------------------
 * error.h -- interface to error handling functions
 *----------------------------------------------------------------
 */

#ifndef gf_included_error_h
#define gf_included_error_h


void error_x (char *filename, int line, char *s1, char *s2);


/* error macro:
 *  This macro expands to a call to the above function, 
 *  error_x, adding the filename and line number to the 
 *  parameters passed.
 */
#define error(a,b) error_x (__FILE__, __LINE__, a, b)


#endif
