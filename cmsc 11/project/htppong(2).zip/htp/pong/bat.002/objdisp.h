/*----------------------------------------------------------------
 * objdisp.h -- interface to objects module from display module
 *----------------------------------------------------------------
 *  This is the interface from the display module; there is 
 *  another header, objects.h, to interface from the game
 *  module.  The display module will call these functions
 *  when it wants to update the display.
 */

#ifndef gf_included_objdisp_h
#define gf_included_objdisp_h


#include <allegro.h>


void objects_draw (BITMAP *bmp);
void objects_erase (BITMAP *bmp, BITMAP *bkgnd);


#endif
