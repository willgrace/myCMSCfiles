/*----------------------------------------------------------------
 * objects.c -- object manipulation routines
 *----------------------------------------------------------------
 *  These routines coordinate the movement of game objects.
 *  Just about anything that need coordinating counts as a
 *  game object.  The actual processing of the objects is 
 *  done by separate modules, one for each object.  This
 *  module just keeps track of the objects.
 */

#include "objects.h"
#include "objdisp.h"
#include "layout.h"
#include "bat.h"

/* bat: (local)
 *  struct bat_t is defined in bat.h -- it holds information
 *  about the bat.  This variable is local (static), not global,
 *  because not many modules need to know about it.  When we ask
 *  the `bat' module to deal with the bat we'll pass the variable
 *  to the routine -- this will have more advantages later on.
 */
static struct bat_t bat;

/* objects_init:
 *  This function initialises all the objects in the game, with the
 *  help of some subsidiary modules.
 */
void objects_init() {
	bat_setup (&bat, arena_width/2, arena_height - bat_height, bat_length, bat_colour);
}


/* objects_shutdown:
 *  Yep, you guessed it -- this undoes what objects_init does.
 */
void objects_shutdown() {
	bat_unsetup (&bat);
}


/* objects_update:
 *  Called once every game cycle to update all the objects.
 */
void objects_update() {
	bat_update (&bat);
}


/* objects_draw:
 *  Called by the display module to draw all the objects.
 */
void objects_draw (BITMAP *bmp) {
	bat_draw (bmp, &bat);
}


/* objects_erase:
 *  Called by the display module to erase all the objects.
 */
void objects_erase (BITMAP *bmp, BITMAP *bkgnd) {
	bat_erase (bmp, bkgnd, &bat);
}
