/*----------------------------------------------------------------
 * display.c -- display routines
 *----------------------------------------------------------------
 *  This module takes care of everything relating to the
 *  screen display.
 */


#include <allegro.h>

#include "display.h"
#include "objdisp.h"
#include "layout.h"
#include "gamevars.h"


/* Various bitmaps used in the game:
 *	`arena' will be a subbitmap of the screen; all of the 
 *		objects in the game will be drawn there.
 *	`arena_bkgnd' will hold the image of the empty arena;
 *		game objects will use this to restore the background
 *		as they move.
 */
static BITMAP *arena, *arena_bkgnd;


/* display_init:
 *  Called once, at the start of the game.
 */
void display_init() {
	if (set_gfx_mode (GFX_AUTODETECT, screen_width, screen_height, 0, 0) < 0)
		abort();

	/* Make subbitmap to simplify access to certain parts of the screen */
	arena = create_sub_bitmap (screen, arena_x, arena_y, arena_width, arena_height);

	/* arena_bkgnd is the background bitmap of the arena */
	arena_bkgnd = create_bitmap (arena_width, arena_height);

	if (!arena || !arena_bkgnd)
		abort();

	clear (arena_bkgnd);
	rect (arena_bkgnd, 0, 0, arena_width - 1, arena_height - 1, 7);

	blit (arena_bkgnd, arena, 0, 0, 0, 0, arena_width, arena_height);
}

/* display_shutdown:
 *  Called after the game; should undo everything ~_init does.
 */
void display_shutdown() {
	destroy_bitmap (arena);
	destroy_bitmap (arena_bkgnd);
}


/* display_update:
 *  This is called every cycle, to update the screen display.
 *
 *  Note that it is a slow routine; display routines tend to 
 *  be slow, and this one includes a vsync.
 */
void display_update() {
	vsync();
	objects_erase (arena, arena_bkgnd);
	objects_draw (arena);
}
