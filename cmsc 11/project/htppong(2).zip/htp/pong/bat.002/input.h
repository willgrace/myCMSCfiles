/*----------------------------------------------------------------
 * input.h -- interface to input module
 *----------------------------------------------------------------
 */

#ifndef gf_included_input_h
#define gf_included_input_h


void input_init();
void input_shutdown();
void input_update();


#endif
