/*----------------------------------------------------------------
 * inpvars.h -- global input variables
 *----------------------------------------------------------------
 */

#ifndef gf_included_inpvars_h
#define gf_included_inpvars_h


extern int input_leftkey, input_rightkey;


#endif
