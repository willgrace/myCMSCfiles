/*----------------------------------------------------------------
 * main.c -- main function
 *----------------------------------------------------------------
 *  I tend to put the main function and one-off initialisation and
 *  shutdown routines in a file of their own.  It's always worth
 *  being modular. 
 */


#include <allegro.h>

#include "game.h"


/* init: (local)
 *  Performs once-per-run initialisation.
 */ 
static void init() {
	allegro_init();
	install_timer();
	install_keyboard();
	initialise_joystick();
	install_mouse();
}

/* shutdown: (local)
 *  Undoes what `init' did.
 */
static void shutdown() {
	allegro_exit();
}

/* run_once: (local)
 *  Runs the game once.
 */
static void run_once() {
	game_init();
	game_run();
	game_shutdown();
}


/* main:
 *  This is the entry point.  It does the one-off initialisation, 
 *  undoing it afterwards, and does something useful in between.
 */
int main() {
	init();
	run_once();
	shutdown();
	return 0;
}
