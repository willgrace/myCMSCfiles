/*----------------------------------------------------------------
 * bat.c -- bat module
 *----------------------------------------------------------------
 *  I've modularised the game objects.  The bat module does
 *  everything to do with the bat.
 */

#include <allegro.h>

#include "bat.h"
#include "inpvars.h"
#include "layout.h"


/* save_state: (local)
 *  Saves the position and length of the bat.
 */
static void save_state (struct bat_t *ptr) {
	ptr->drawn_x = ptr->x;
	ptr->drawn_y = ptr->y;
	ptr->drawn_l = ptr->l;
	ptr->drawn_h = 1;
}


/* bat_setup:
 *  This initialises a bat with x and y coordinates and a length.
 */
void bat_setup (struct bat_t *ptr, int x, int y, int l, int c) {
	ptr->x = x - l/2;
	ptr->y = y;
	ptr->l = l;
	ptr->colour = c;
	save_state (ptr);
}


/* bat_unsetup:
 *  This reverses the effect of bat_setup.  Since nothing 
 *  in bat_setup needs reversing, it does nothing.
 */
void bat_unsetup (struct bat_t *ptr) {
	(void)ptr;  /* suppress `ptr is unused' warning */
}


/* bat_update:
 *  This moves the bat left or right, depending upon the 
 *  input state.
 */
void bat_update (struct bat_t *ptr) {
	if (input_leftkey) ptr->x--;
	if (input_rightkey) ptr->x++;
	if (ptr->x < 1) ptr->x = 1;
	if (ptr->x > arena_width - ptr->l - 2) ptr->x = arena_width - ptr->l - 2;
}


/* bat_erase:
 *  Erases the bat from its previous location (stored with 
 *  save_state).
 */
void bat_erase (BITMAP *bmp, BITMAP *bkgnd, struct bat_t *ptr) {
	blit (bkgnd, bmp, ptr->drawn_x, ptr->drawn_y, ptr->drawn_x, ptr->drawn_y, ptr->drawn_l+1, ptr->drawn_h);
}


/* bat_draw:
 *  Draws the bat in its current position.
 */
void bat_draw (BITMAP *bmp, struct bat_t *ptr) {
	hline (bmp, ptr->x, ptr->y, ptr->x + ptr->l, ptr->colour);
	save_state (ptr);
}
