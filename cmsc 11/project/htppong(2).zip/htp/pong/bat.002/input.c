/*----------------------------------------------------------------
 * input.c -- input-related functions
 *----------------------------------------------------------------
 *  This is the input module.  input_update is called once per
 *  cycle to get the current input state; after that, the game
 *  engine will read from input_leftkey and input_rightkey.
 */


#include <allegro.h>

#include "input.h"
#include "inpvars.h"
#include "gamevars.h"


/* Variables to hold the state of the left and right keys */
int input_leftkey, input_rightkey;


void input_init() {
	input_leftkey = input_rightkey = 0;
}

void input_shutdown() {
}


/* input_update:
 *  This function gets called once per game cycle, and is
 *  responsible for getting the input information for the
 *  whole cycle.
 */
void input_update() {
	/* check the left and right keys */
	input_leftkey = key[KEY_LEFT];
	input_rightkey = key[KEY_RIGHT];

	/* end the game if the user presses Esc */
	if (key[KEY_ESC]) game_end_flag = 1;
}

