/*----------------------------------------------------------------
 * game.h -- interface to game.c from above
 *----------------------------------------------------------------
 *  This file prototypes functions in game.c which are called
 *  from `the layer above'.  Using two (or more) header files
 *  for each module can reduce rebuild times -- if you change
 *  something that affects how modules on the same layer
 *  interact with a module, there's no point in rebuilding 
 *  all the calling modules (since their interface hasn't 
 *  changed).  Consequently, the game variables are declared
 *  in gamevars.h, not here.
 */

#ifndef gf_included_game_h
#define gf_included_game_h


void game_init();
void game_shutdown();
void game_run();


#endif
