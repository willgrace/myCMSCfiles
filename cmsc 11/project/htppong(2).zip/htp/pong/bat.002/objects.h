/*----------------------------------------------------------------
 * objects.h -- interface to objects module
 *----------------------------------------------------------------
 *  This is the interface from the game module; there is 
 *  another header, objdisp.h, to interface from the display
 *  module.
 */

#ifndef gf_included_objects_h
#define gf_included_objects_h


void objects_init();
void objects_shutdown();
void objects_update();


#endif
