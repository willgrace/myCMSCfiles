/*----------------------------------------------------------------
 * display.h -- interface to display module
 *----------------------------------------------------------------
 */

#ifndef gf_included_display_h
#define gf_included_display_h


void display_init();
void display_shutdown();
void display_update();


#endif
