
                       How to program Pong

                              Readme

                     Third Draft, 10 May 1998

                  (c) Copyright George Foot 1998



Contents
~~~~~~~~
    1) "What's this all about?"
    2) "But any Pong is such a simple game..."
    3) "So what do I need to know to get started?"
    4) "What if I don't know how to use Allegro?"
    5) "How do I use the tutorial?"
    6) "How can I contact you?"


1. "What's this all about?"
~~~~~~~~~~~~~~~~~~~~~~~~~~~
    "How to program Pong" is the first in a series of game 
    programming tutorials I intend to write.  Each tutorial will 
    deal with a different type of game, showing how I develop it 
    from scratch and explaining why I do things in certain ways.  
    They'll be written to use the Allegro game programming library 
    under DJGPP -- both are freely downloadable. 


2. "But Pong is such a simple game..."
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    Pong is a very simple game.  For those who don't know what 
    it is, the basic game has a ball bouncing off the edges of 
    the screen and a bat at the bottom, controlled by the player.  
    If the ball hits the bottom of the screen, the player loses. 

    Being simple, it is relatively easy to program.  If you are 
    writing Pong just for its own sake, then it is extremely 
    easy to do -- but that isn't the idea of this tutorial.  This 
    tutorial will be using Pong to demonstrate what is (in my 
    opinion) good design technique.  Rather than just learning 
    how to program Pong, you'll be learning general techniques 
    which you can apply to other games. 


3. "So what do I need to know to get started?"
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    You need a working copy of DJGPP v2.01 or better (C++ support 
    is not required) and you need to know how to use it.  You 
    also need Allegro, preferably version 3.0 or better; if you 
    use an older version you may find that some things don't work 
    properly.  You will need to know a certain amount about using 
    Allegro.  This tutorial aims to teach you how to write the 
    game, not how to use the library in particular. 


4. "What if I don't know how to use Allegro?"
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    There are several options.  You could read the allegro.txt 
    file from start to finish, but this is likely to be somewhat 
    boring.  You could read a tutorial that teaches you how to 
    use the library -- there are several linked from the Allegro 
    web pages, under `Documentation' at the moment (though the 
    structure of those pages changes occasionally).  Or you can 
    press on with this tutorial, and refer to the Allegro 
    documentation whenever you don't understand something. 

    It's entirely up to you, of course.  I think you should try 
    the third option initially, and switching to the second if 
    you feel you need to.  Tutorials about the library itself 
    will cover different areas, and are probably worth reading 
    for their own sakes anyway. 


5. "How do I use the tutorial?"
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    The tutorial is split into several sections, like chapters. 
    Each section has its own subdirectory; the extensions of the 
    directories are the chapter numbers.  The `tutorial.txt' file 
    in each directory is the text for that chapter.  The chapters 
    also include the source code for the game at that stage, a 
    list of the changes from the previous chapter, and possibly 
    a file containing some suggestions you might like to try 
    implementing yourself. 

    So, when you're ready to start the tutorial, go to the first
    directory and read the `tutorial.txt' file there.  Enjoy! 


6. "How can I contact you?"
~~~~~~~~~~~~~~~~~~~~~~~~~~~
    by email:
        gfoot@users.sourceforge.net

    by pmail:
        George Foot
        Merton College
        Oxford
        OX1 4JD
        England


    Email messages are likely to be answered far more promptly
    than postal messages.


