/*----------------------------------------------------------------
 * input.c -- input-related functions
 *----------------------------------------------------------------
 *  This is the input module.  input_update is called once per
 *  cycle to get the current input state; after that, the game
 *  engine will read from things not yet implemented.
 */


#include <allegro.h>

#include "input.h"
#include "gamevars.h"


void input_init() {
}

void input_shutdown() {
}


/* input_update:
 *  This function gets called once per game cycle, and is
 *  responsible for getting the input information for the
 *  whole cycle.
 */
void input_update() {
	/* end the game if the user presses Esc */
	if (key[KEY_ESC]) game_end_flag = 1;
}

