/*----------------------------------------------------------------
 * display.c -- display routines
 *----------------------------------------------------------------
 *  This module takes care of everything relating to the
 *  screen display.
 */


#include <allegro.h>

#include "display.h"
#include "gamevars.h"


/* display_init:
 *  Called once, at the start of the game.
 */
void display_init() {
	if (set_gfx_mode (GFX_AUTODETECT, 320, 200, 0, 0) < 0)
		abort();

	clear (screen);
	rect (screen, 0, 0, 319, 199, 7);
}

/* display_shutdown:
 *  Called after the game; should undo everything ~_init does.
 */
void display_shutdown() {
}


/* display_update:
 *  This is called every cycle, to update the screen display.
 *
 *  Note that it is a slow routine; display routines tend to 
 *  be slow, and this one includes a vsync.
 */
void display_update() {
	vsync();
}
