/*----------------------------------------------------------------
 * input.h -- interface to input module
 *----------------------------------------------------------------
 */

#ifndef gf_included_input_h
#define gf_included_input_h


#include "inptyps.h"

void input_init();
void input_shutdown();
void input_update();

struct input_t *input_create_keyboard (int l, int r, int u, int d, int f1, int f2);
struct input_t *input_create_mouse (int sens);
struct input_t *input_create_joystick (int stick);

#endif
