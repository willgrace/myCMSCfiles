/*----------------------------------------------------------------
 * input.c -- input-related functions
 *----------------------------------------------------------------
 *  This is the input module.  input_update is called once per
 *  cycle to get the current input state.  When we do this we
 *  update all the input_t structs we've allocated, so that
 *  other modules can read directly from those.
 */


#include <stdlib.h>
#include <string.h>
#include <allegro.h>

#include "gamevars.h"
#include "input.h"
#include "inptyps.h"


/* INPUT_TYPE_*:
 *  Used in the `type' field of `struct input_internal_t' to
 *  record what type each input device is.
 */
#define INPUT_TYPE_KEYBOARD  1
#define INPUT_TYPE_MOUSE     2
#define INPUT_TYPE_JOYSTICK  3


/* struct input_kbd_t:
 *  This struct holds information about a keyboard device --
 *  specifically, which keys do what.  It's used in the struct
 *  below (`struct input_internal_t').
 */
struct input_kbd_t {
	int l,r,u,d,f1,f2;  /* left, right, up, down, fire1, fire2 */
};

/* struct input_mse_t:
 *  As above, but for the mouse.
 */
struct input_mse_t {
	int sensitivity;
};

/* struct input_joy_t:
 *  As above, but for the joystick.
 */
struct input_joy_t {
	int stick;
};

/* struct input_internal_t:
 *  This struct will be used to store information about a registered
 *  input device.  The other modules will not be able to see much of 
 *  it; just the `input' field in fact.  That's all they need to know.
 *  The other fields are there to help us update the `input' field
 *  when we're told to.
 */
struct input_internal_t {
	struct input_t input;     /* the struct we'll show to the other modules */
	int type;                 /* e.g. keyboard, joystick, mouse */
	union {
		struct input_kbd_t kbd;     /* keyboard data (keys to use) */
		struct input_mse_t mse;     /* mouse data (sensitivity) */
		struct input_joy_t joy;     /* joystick data (none) */
	} data;
	struct input_internal_t *next;  /* this is a linked list */
};

/* `devices' is the pointer to the head node of our list of
 * registered input devices.  We won't be using a dummy node;
 * `devices' will just be NULL if the list is empty.
 */
static struct input_internal_t *devices = NULL;


/* input_init:
 *  This function initialises the module, by clearing the linked
 *  list of registered input devices.
 */
void input_init()
{
	devices = NULL;
}

/* input_shutdown:
 *  Destroys all the registered devices.
 */
void input_shutdown()
{
	struct input_internal_t *devptr;
	while (devices) {
		devptr = devices->next;
		free (devices);
		devices = devptr;
	}
}


/* create_device: (local)
 *  Adds a new device to the linked list.  Since order isn't important
 *  we can just stick it on the beginning of the list, which is very
 *  simple to do (no need to walk the list).
 */
static struct input_internal_t *create_device (int type)
{
	struct input_internal_t *devptr;
	devptr = malloc (sizeof (struct input_internal_t));
	if (!devptr) return NULL;
	memset (devptr, 0, sizeof (struct input_internal_t));
	devptr->type = type;
	devptr->next = devices;
	devices = devptr;
	return devptr;
}

/* input_create_keyboard:
 *  Creates a keyboard device using the given keys.
 */
struct input_t *input_create_keyboard (int l, int r, int u, int d, int f1, int f2)
{
	struct input_internal_t *devptr = create_device (INPUT_TYPE_KEYBOARD);
	if (!devptr) return NULL;
	devptr->data.kbd.l = l;
	devptr->data.kbd.r = r;
	devptr->data.kbd.u = u;
	devptr->data.kbd.d = d;
	devptr->data.kbd.f1 = f1;
	devptr->data.kbd.f2 = f2;
	return &devptr->input;
}

/* input_create_mouse:
 *  Creates a mouse device, using the given sensitivity.
 */
struct input_t *input_create_mouse (int sens)
{
	struct input_internal_t *devptr = create_device (INPUT_TYPE_MOUSE);
	if (!devptr) return NULL;
	devptr->data.mse.sensitivity = sens;
	return &devptr->input;
}

/* input_create_joystick:
 *  Creates a joystick device, using the given joystick (1 or 2).
 */
struct input_t *input_create_joystick (int stick)
{
	struct input_internal_t *devptr = create_device (INPUT_TYPE_JOYSTICK);
	if (!devptr) return NULL;
	devptr->data.joy.stick = stick;
	return &devptr->input;
}


/* update_device: (local)
 *  Updates the given input device.
 */
static void update_device (struct input_internal_t *devptr)
{
	switch (devptr->type) {
		case INPUT_TYPE_KEYBOARD:
			{
				int x = 0, y = 0, f1 = 0, f2 = 0;
				if (key[devptr->data.kbd.r]) x++;
				if (key[devptr->data.kbd.l]) x--;
				if (key[devptr->data.kbd.d]) y++;
				if (key[devptr->data.kbd.u]) y--;
				if (key[devptr->data.kbd.f1]) f1 = 1;
				if (key[devptr->data.kbd.f2]) f2 = 1;
				devptr->input.x = x;
				devptr->input.y = y;
				devptr->input.fire1 = f1;
				devptr->input.fire2 = f2;
			}
			break;
		case INPUT_TYPE_MOUSE:
			{
				int x,y,sens;
				get_mouse_mickeys (&x, &y);
				sens = devptr->data.mse.sensitivity;

				if (x > sens) devptr->input.x = 1;
				else if (x < -sens) devptr->input.x = -1;
				else devptr->input.x = 0;

				if (y > sens) devptr->input.y = 1;
				else if (y < -sens) devptr->input.y = -1;
				else devptr->input.y = 0;
				
				devptr->input.fire1 = mouse_b & 1;
				devptr->input.fire2 = (mouse_b & 2) >> 1;
			}
			break;
		case INPUT_TYPE_JOYSTICK:
			{
				switch (devptr->data.joy.stick) {
					case 1:
						if (joy_left) devptr->input.x = -1;
							else if (joy_right) devptr->input.x = 1;
							else devptr->input.x = 0;
						if (joy_up) devptr->input.y = -1;
							else if (joy_down) devptr->input.y = 1;
							else devptr->input.y = 0;
						devptr->input.fire1 = joy_b1;
						devptr->input.fire2 = joy_b2;
						break;
					case 2:
						if (joy2_left) devptr->input.x = -1;
							else if (joy2_right) devptr->input.x = 1;
							else devptr->input.x = 0;
						if (joy2_up) devptr->input.y = -1;
							else if (joy2_down) devptr->input.y = 1;
							else devptr->input.y = 0;
						devptr->input.fire1 = joy2_b1;
						devptr->input.fire2 = joy2_b2;
						break;
				}
			}
			break;
	}
}

/* input_update:
 *  This function gets called once per game cycle, and is
 *  responsible for getting the input information for the
 *  whole cycle.
 */
void input_update()
{
	struct input_internal_t *devptr;

	/* Tell Allegro to update the joystick position */
	poll_joystick();
	
	/* Walk the linked list, updating devices */
	for (devptr = devices; devptr; devptr = devptr->next)
		update_device (devptr);

	/* end the game if the user presses Esc */
	if (key[KEY_ESC]) game_end_flag = 1;
}
