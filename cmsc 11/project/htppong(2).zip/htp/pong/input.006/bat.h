/*----------------------------------------------------------------
 * bat.h -- interface to bat module
 *----------------------------------------------------------------
 *  I've modularised the game objects.  The bat module does
 *  everything to do with the bat.
 */

#ifndef gf_included_bat_h
#define gf_included_bat_h


#include "inptyps.h"

struct bat_t {
	int x,y;        /* Coordinates (of top left point) on the screen */
	int l;          /* length */
	int colour;
	
	struct input_t *input;     /* input state */

	/* drawn_*:
	 *  These next variables describe a rectangle in the arena 
	 *  that covers the bat's image; they're updated when the 
	 *  bat is drawn so that the erasing code knows which area 
	 *  of the display to restore.
	 */ 
	int drawn_x,drawn_y,drawn_l,drawn_h;
};


void bat_setup (struct bat_t *ptr, int x, int y, int l, int c, struct input_t *input);
void bat_unsetup (struct bat_t *ptr);
void bat_update (struct bat_t *ptr);
void bat_draw (BITMAP *bmp, struct bat_t *ptr);
void bat_erase (BITMAP *bmp, BITMAP *bkgnd, struct bat_t *ptr);


#endif
