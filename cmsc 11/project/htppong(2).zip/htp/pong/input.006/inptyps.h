/*----------------------------------------------------------------
 * inptyps.h -- declarations of input types
 *----------------------------------------------------------------
 *  Our input routines will be very generic.  This approach has 
 *  several advantages; it's modular, which is good, and in 
 *  particular it will make it easy for us to let the user choose 
 *  which input device to use.
 */

#ifndef gf_included_inptyps_h
#define gf_included_inptyps_h


/* struct input_t:
 *	Pointers to these structs are returned when input devices
 *	are created.  Other modules can then look at the fields,
 *	which will be updated when input is polled.
 *
 *	`x' is the current left-right state 
 *		(-1 = left, 1 = right, 0 = neither)
 *	`y' is the current up-down state
 *		(-1 = up, 1 = down, 0 = neither)
 *	`fire1' and `fire2' give the states of two fire buttons
 *		(1 = pressed, 0 = not pressed)
 */
struct input_t {
	int x, y, fire1, fire2;
};


#endif
