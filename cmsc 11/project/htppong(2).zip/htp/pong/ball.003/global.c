/*----------------------------------------------------------------
 * global.c -- general global variables
 *----------------------------------------------------------------
 *  These are general global variables that don't fit 
 *  anywhere else.  Some people prefer to implement things
 *  like screen_width as macros, in a .h file, instead of 
 *  variables as here -- the advantage is a possible slight
 *  gain in speed, but the disadvantages are (1) that they 
 *  can't be changed at run-time, and (2) that any changes 
 *  made necessitate a full rebuild.
 *
 *  `const' variables also suffer from (1), but not (2).
 *
 *  Normal variables don't suffer from either, of course, 
 *  but can't be optimised as well as const variables.  If
 *  we wanted, for example, to be able to set the screen
 *  resolution at runtime, in a config file perhaps, we'd
 *  want to make at least some of these non-const.
 */


#include <allegro.h>

#include "layout.h"

const int screen_width  = 320,
		  screen_height = 200;

const int arena_width  = 320,
		  arena_height = 200,
		  arena_x      = 0,
		  arena_y      = 0;

const int bat_height = 10,
		  bat_length = 40;

const int bat_colour = 10,
		  ball_colour = 14;
