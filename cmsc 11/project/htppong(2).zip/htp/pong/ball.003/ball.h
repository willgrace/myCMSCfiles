/*----------------------------------------------------------------
 * ball.h -- interface to ball module
 *----------------------------------------------------------------
 *  I've modularised the game objects.  The ball module does
 *  everything to do with the ball.
 */

#ifndef gf_included_ball_h
#define gf_included_ball_h


struct ball_t {
	int x,y;        /* Coordinates on the screen */
	int xv,yv;      /* Velocity components in X and Y directions */
	int colour;

	int ox,oy;              /* Last cycle's X and Y coordinates */
	int drawn_x, drawn_y;   /* Coordinates where the ball was last drawn */
};


void ball_setup (struct ball_t *ptr, int x, int y, int xv, int yv, int c);
void ball_unsetup (struct ball_t *ptr);
void ball_update (struct ball_t *ptr);
void ball_bounce_x (struct ball_t *ptr);
void ball_bounce_y (struct ball_t *ptr);
void ball_draw (BITMAP *bmp, struct ball_t *ptr);
void ball_erase (BITMAP *bmp, BITMAP *bkgnd, struct ball_t *ptr);


#endif
