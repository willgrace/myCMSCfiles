/*----------------------------------------------------------------
 * ball.c -- ball module
 *----------------------------------------------------------------
 *  I've modularised the game objects.  The ball module does
 *  everything to do with the ball.
 */

#include <allegro.h>

#include "ball.h"
#include "layout.h"


/* save_state: (local)
 *  Saves the position of the ball.
 */
static void save_state (struct ball_t *ptr) {
	ptr->drawn_x = ptr->x;
	ptr->drawn_y = ptr->y;
}


/* ball_setup:
 *  This initialises a ball with x and y coordinates and velocities.
 */
void ball_setup (struct ball_t *ptr, int x, int y, int xv, int yv, int c) {
	ptr->x = x;
	ptr->y = y;
	ptr->xv = xv;
	ptr->yv = yv;
	ptr->colour = c;
	save_state (ptr);
}


/* ball_unsetup:
 *  This reverses the effect of ball_setup.  Since nothing in 
 *  ball_setup needs reversing, it does nothing.
 */
void ball_unsetup (struct ball_t *ptr) {
	(void)ptr;  /* suppress `ptr is unused' warning */
}


/* ball_update:
 *  This moves the ball and handles bouncing off the walls.
 */
void ball_update (struct ball_t *ptr) {
	ptr->ox = ptr->x;
	ptr->oy = ptr->y;

	ptr->x += ptr->xv;
	ptr->y += ptr->yv;

	if ((ptr->x < 1) || (ptr->x > arena_width-2)) ball_bounce_x (ptr);
	if ((ptr->y < 1) || (ptr->y > arena_height-2)) ball_bounce_y (ptr);
}


/* ball_bounce_x, ball_bounce_y:
 *  These routines make the ball bounce in the x or y
 *  direction.
 */
void ball_bounce_x (struct ball_t *ptr) {
	ptr->xv =- ptr->xv;
	ptr->x += 2 * ptr->xv;
}

void ball_bounce_y (struct ball_t *ptr) {
	ptr->yv =- ptr->yv;
	ptr->y += 2 * ptr->yv;
}


/* ball_erase:
 *  Erases the ball from its previous location (stored with 
 *  save_state).
 */
void ball_erase (BITMAP *bmp, BITMAP *bkgnd, struct ball_t *ptr) {
	putpixel (bmp, ptr->drawn_x, ptr->drawn_y, getpixel (bkgnd, ptr->drawn_x, ptr->drawn_y));
}


/* ball_draw:
 *  Draws the ball in its current position.
 */
void ball_draw (BITMAP *bmp, struct ball_t *ptr) {
	putpixel (bmp, ptr->x, ptr->y, ptr->colour);
	save_state (ptr);
}
