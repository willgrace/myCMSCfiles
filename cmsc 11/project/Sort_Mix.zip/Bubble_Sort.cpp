#include <windows.h>
#include <conio.h> 
#include <iostream>
#include <string>
#include <cctype>
#include <cstdlib>
#include <ctime>
#include "Conlib.cpp"

using namespace std;


ConLib Con; // Instance Object From ConLib

int I;
int *Arry;
short Amount_Sorted = 5;

void Print(void);


int main()
{

   srand(time(NULL)); // seed the random function

   bool Done = false;
   int Temp, J = 0;
   short Text_Color = 0, Back_Color = 0;
   int counter = -1;
   

   Con.SetTitle("Steve's Sort And Mix");

   Con.OutputString ( "This program will take any given numbers and sort them in order then mix them up" );
   Con.OutputString ( "Hit Spacebar To Continue" );
   getch();

   Con.Clear();

   Con.OutputString ( "Select Text Color: 1 = Red, 2 = Green, 3 = Blue, 0 = Standard: " );
   cin >> Text_Color;

   switch (Text_Color)
   {
     case 1:
       Con.SetTextColor(ConRed);
	   break;
	 case 2:
       Con.SetTextColor(ConGreen);
	   break;
	 case 3:
	   Con.SetTextColor(ConBlue);
	   break;
   }

    Con.Clear(); // Clears Screen
   
   Con.OutputString ( "Select Background Color: 1 = Red, 2 = Green, 3 = Blue, 0 = Standard: " );
   cin >> Back_Color;

   switch (Back_Color)
   {
     case 1:
       Con.SetBackgroundColor(ConRed);
	   break;
	 case 2:
       Con.SetBackgroundColor(ConGreen);
	   break;
	 case 3:
	   Con.SetBackgroundColor(ConBlue);
	   break;
   }


   Con.Clear(); // Clears Screen

   Con.OutputString ( "How Many Numbers Do You Want To Sort? " );
   cin >> Amount_Sorted;

   Con.Clear();
   Con.OutputString ( "Enter Numbers To Be Sorted: ");


   Arry = new int [Amount_Sorted];

   while (++counter < Amount_Sorted) cin >> Arry[counter];

   counter = 0; // Reset Counter For Times mixed
   
// Sort Numbers ///////////////////////////////////////////////////////////////////

   while(Done == false)
   {
	   Done = true;

	   for(I = 0; I < Amount_Sorted - 1; I++)
	   {
		   if(Arry[I] > Arry[I + 1])
		   { 
			   Temp = Arry[I];
			   Arry[I] = Arry[I + 1];
			   Arry[I + 1] = Temp;
               Done = false;
		   } // End If
		   } // End For
   } // End While

   Con.Clear();

   cout << "List In Order: " << endl;

   Print();

   randomagain:
  
  Con.OutputString (" ");
  Con.OutputString ( "Hit Spacebar" );
  Con.OutputString (" ");
  Con.OutputString ( " ");
  Con.OutputString ( "List Random:" );

  counter++;

// Randomize Numbers ///////////////////////////////////////////////////////////////////////

for(I = 0; I < Amount_Sorted - 1; I++)
{
	J = rand() % Amount_Sorted; 
    Temp = Arry[I];
    Arry[I] = Arry[J];
    Arry[J] = Temp;

} // End For


cout << endl;

Print(); 

getch();
   

if(counter <= 3) 
{
	Con.Clear();
	cout << endl;
	cout << "Hit Spacebar" << endl;
	cout << endl;
	cout << counter << " Again:" << endl;
	cout << "\a" << endl;
	goto randomagain;
}

   Con.END();
   getch();


   delete [] Arry; // Clean It Up Johnny (No Memory Leaks)

   Arry = NULL;

   return 0;

}


// Function Definitions /////////////////////////////////////////////////////////////////////////
void Print(void)
{
   for(I = 0; I < Amount_Sorted; I++)
  {
	  cout << Arry[I] << endl;
  }
}