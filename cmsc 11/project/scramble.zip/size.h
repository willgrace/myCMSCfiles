#ifndef SIZE_H
#define SIZE_H

/* Class size by Steven Ramponi */

#include <iostream.h>
#include <string.h>
#include <conio.h>
#include "keys.h"

class get_size
{

public:

	get_size(){}
	~get_size(){}

	unsigned short string_size(char* string)
	{ return length = strlen(string); } // End of function.


private:

	unsigned short length;

};

#endif