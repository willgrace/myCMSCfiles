
/* Scamble two by Steven Ramponi */


// INCLUDES ////////////////////////////////////////////////////////////

#include <iostream.h>
#include <fstream.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include <iomanip.h>
#include "size.h"
#include "Keys.h"
#include "delay.h"
#include "Black41.h"

/// GLOBALS ///////////////////////////////////////////////////////////
 
short output = 0; // Declarations.
short input = 0; ///////////////

 char WORD[35]; // Word chosen from file.
 char LW[35]; // Last word used variable.
 char unscr[35]; // Unscrambled word.

char again; // Choose to play again veriable.

bool once = FALSE; // Resets EOF only once.
bool Done = FALSE; // Continue game veriable.

 ofstream outClientFile( "Words.dat", ios::app);
 ifstream inClientFile( "Words.dat", ios::out);

// PRTOTYPES ///////////////////////////////////////////////////////////

 void HEADER(void);
 void struction (void);
 int filein (void);
 int fileout (void);
 void GAME (void);

/// MAIN //////////////////////////////////////////////////////////////


int main (void) // Control module.
{
   // Declarations. ////////////////////////////////////////////////////

	char temp, list;
	unsigned short i, LEGT;

	bool game_over = FALSE;

	unsigned int right = 0, wrong1 = 0, time1 = 10;

   /////////////////////////////////////////////////////////////////////


	get_size S; // Instance object from size.h.
	count counting; // Instance object from delay.h


       HEADER(); // Function call.

       struction(); // Function call.

       Set_Graphics_Mode (TEXT_MODE);


	cout << "\n\nDo you wish to make a list of words? (y-n).\n"
		<< "If you choose 'y' you will create a list of words\n"
		<< "to be scrambled. If you choose 'n' you will start\n"
		<< "up the game. If there are words showing below after\n"
		<< "you decide to enter a list this means you will be \n"
		<< "adding to an already made list.\n\n";

	do {
		list = getch();
	} while (list != 'n' && list != 'y');


	if (list == 'y') {

	input = filein(); // Function call.
	output = fileout(); // Function call.

	cout << "\n\nHit any key to exit list." << endl;

    getch();

return (output && input);

	} // End if.


  // Event loop. //////////////////////////////////////////////////////

	while (!Done) {


	GAME(); // Function call to main game.


 LEGT = S.string_size(WORD); // Get length of string function call from size.h.

 char *pick = new char[LEGT]; // Allocate variables at run time.
 char *user = new char[LEGT]; // User input word. //////////////

 strcpy (pick, WORD);
 strcpy (unscr, WORD);

 if (strcmp (LW, unscr) == 0) {  // If end of file check.
 delete [] pick;
 pick = NULL;
 delete [] user;
 user = NULL;
 game_over = TRUE;
 goto END;

 } // End if.

// Scramble word. ////////////////////////////////////////////////////////////


	for (i = 0; i <= LEGT-1; i++) {
		short j = rand() % LEGT;
	temp = pick[ i ];
	pick[ i ] = pick[ j ];
	pick[ j ] = temp;
	} // End of for loop.


/////////////////////////////////////////////////////////////////////////////

     Set_Graphics_Mode (GRAPHICS_MODE13);


 cout << setiosflags(ios::left) << "Words right: " << right << "         Words wrong: " <<
  wrong1 << "\n\n\n";

	cout << "\n\nScrambled word: ";
		for (i = 0; i < LEGT+1; i++) cout << pick[i] << ' ';

		cout << "\n\n"; // Space.

		cout << "Think for " << time1 << " seconds." << "\n\n";

    counting.Show_Delay(time1); // Function call from delay.h.

    cout << "\n\nInput unscrambled word: ";
    cin >> user;

	if (strcmp(user, unscr) == 0) {
	win();
	right++;
	cout << "\nRIGHT!!" << endl;
	} // End if.

	else {
	pong(); wrong(); lose();
	wrong1++;
	cout << "\nWRONG!! " << "The word was: "<< unscr << endl;
	} // End else.

// Reset everything. /////////////////////////////////////////////////

 for (i = 0; i < LEGT; i++) unscr[i] = 0;

 temp = NULL;

 delete [] user;
 user = NULL;

 delete [] pick;
 pick = NULL;

 strcpy (LW, unscr);  // Find end of file.

//////////////////////////////////////////////////////////////////////


 cout << "\n\nWould you like to try again? (y-n)" << endl;
 
 do {
	 again = getch(); ship();
 } while (again != 'n' && again != 'y');


 if (again == 'n') Done = TRUE;


	} // End of main event loop. ////////////////////////////////////

END:

	Screen_Transition (SCREEN_DISOLVE);

 if (game_over) {
 gotoxy (10, 5);
 cout << "End of list. Game over." << endl; } // End if.


cout << "\n\nEnd game results:" << endl;

gotoxy (1, 10);
 cout << setiosflags(ios::left) << "Words right: " << right << "         Words wrong: " <<
 wrong1 << "\n\n\n";

gotoxy(1, 25);
cout << "Hit any key to exit." << endl;

getch();

Screen_Transition (SCREEN_DARKNESS);
Set_Graphics_Mode (TEXT_MODE);


return (output && input);

} // End of program. /////////////////////////////////////////////////////


// Function definitions. ////////////////////////////////////////////////


int fileout (void)
{

   if ( !outClientFile ) {  // overloaded ! operator
      cerr << "File could not be opened" << endl;
      exit( 1 ); }   // prototype in stdlib.h

cout << "\n\nEnter all the words you wish to be scrambled in this list.\n"
<< "This process is done by typing in the desired word then\n"
<< "hitting enter. When you have entered the entire list you\n"
<< "need to press control 'z' then control 'm' to back out.\n";


cout << "\n? ";

   while ( cin >> WORD) {

outClientFile << setiosflags(ios::left) << setw(10) << WORD << endl;
	  
 
      cout << "? ";
   }

   return 0;  // ofstream destructor closes file.

} // End of function.



int filein (void)
{

	if ( !inClientFile ) { 
      cerr << "File could not be opened\n";
      exit( 1 ); } // End if prototype in stdlib.h.


while (inClientFile >> WORD)

   cout << setiosflags(ios::left) << setw(10) << WORD << endl;

   return 0;

} // End of function.



 void GAME (void)
 {

	 if (!once) {

    inClientFile.clear(); // Reset eof for next input.

    inClientFile.seekg(0); // move to the beginning of the file.

	once = TRUE;

	 } // End if.

 inClientFile >> WORD;

 } // End of function. ///////////////////////////////////////////////



 void HEADER (void)
{

unsigned short Y = 0;

   Set_Graphics_Mode (GRAPHICS_MODE13);

   delay (2000);

   win();

   while (!kbhit()) {

   if (Y-- < 5) Y = 5;

   Print_String (100, Y, random(256), "Scramble 2", 0);
   Print_String (120, Y+20, random(256), "By", 0);
   Print_String (100, Y+50, random(256), "Steven Ramponi", 0);
   Print_String (100, Y+180, random(256), "Hit a key to start game.", 0);

   delay(100);

   } // End of while.

   Screen_Transition (SCREEN_DISOLVE);

} // End of function. //////////////////////////////////////////////////////



 void struction (void)
{
   char ins;

  cout << "\n\n\n\nInstructions? (y-n)" << endl;

  do{
  ins = getch(); ship();
  } while (ins != 'n' && ins != 'y');


  if (ins == 'y') {

  Set_Graphics_Mode (TEXT_MODE);

  win();

cout << "\n\n\n    Scramble 2 takes the player to many new dimensions with more options than\n"
<< "before. This totally new set-up can be used as a two player configuration.\n"
<< "A player starts with the option to create a list of words to be scrambled.\n"
<< "This list that the player chooses to create is then entered. The player backs\n"
<< " out of the game to restart the game with a fresh list. This new list could\n"
<< "be made by an opponent challenging the player to guess their words.\n\n";

cout << "\n\n    There will be a list that comes with the game. If anybody wants to get\n"
<<  "rid of any existing list: go to the directory where the executable is\n"
<< "located, delete Words.dat file and the program will make a new one\n"
<< "when entered in the system by the player or players. If adding to the list\n"
<< "is desired: choose the option to add list and type the added words in\n"
<< "the system. Now your ready to play." << endl;

cout << "\n\n\n\n\n\n\nHit any key to get started.." << endl;

getch();

} // End if.


Set_Graphics_Mode (GRAPHICS_MODE13);

win();

Print_String (100, 120, RED, "GET READY!!", 0);

delay(2000);

 Screen_Transition (SCREEN_DISOLVE);

 } // End of function. ////////////////////////////////////////////////////




