//Hangman by Steven Ramponi ///////////////////////////////////////


// Includes ////////////////////////////////////////////////////////

#include <windows.h>
#include <conio.h> 
#include <iostream>
#include <string>
#include <cctype>
#include <cstdlib>
#include <ctime>
#include "Conlib.cpp"

using namespace std;

// Prototypes ///////////////////////////////////////////////////////////
 
void playHangman();

void getSecretWord(string&);

bool promptNext(string& secret, string& display, string& guessList);

void showWord(string&);

void showFinalGraphic(bool didWin); 

// Both of the following functions use default arguments.

// Note that default arguments only show up in the prototype.

// Do not put the "= 25" in the function definition itself.

void clearScreen(int lines = 25);

void showGraphic(int& index, bool addOne = false);

// Structures //////////////////////////////////////////////////////

struct slam { short OK; };

///////////////////////////////////////////////////////////////////
 
ConLib Con; // Instance object of ConLib class.
slam ending = { 0 }; // Instance object of structure slam.


// Global Variables ///////////////////////////////////////////////

short numberadd = 1, playeramount;

 string hint;

/// MAIN ////////////////////////////////////////////////////////////////

int main(void) // Controle module.

{

char ch, NewGame;
bool Done = false;


while(!Done)
{

   Con.SetTitle("Hangman by Steven Ramponi");

   srand(time(NULL)); // Seed the random function.

   cout << "  Mouse over dos window slowly to set background color after depressing a key." << endl;

   getch();

   while(!Con.GetKey())
   { 
	   Con.SetBackgroundColor(1+rand() % 5);
	   Con.Clear();

   } // End of while.
    

	Con.Clear();
		
	cout << "                         Hangman by Steven Ramponi" << endl;

	cout << "\n\n                           Hit any key to begin\n\n\n" << endl;

	getch();

	cout << "\a" << endl;

    Con.Clear();
	

cout << "\n\n\n\n\n\n\n          Enter the amount of players you want in the game \n" <<
        "          1 for single player 2 for two player: ";
cin >> playeramount;

Con.Clear();

while(playeramount < 1 || playeramount > 2)
{
   cout << "\n\n\n\n\n\n\n          Enter the amount of players you want in the game \n" <<
        "          1 for single player 2 for two player: ";
cin >> playeramount;

cout << "\a" << endl;

Con.Clear();

} // End while.
		
      

   //////////////////////////////////////////////////////////////

   do

      {

      playHangman();

      cout << "\nDo you want to play again? (y/n) ";

      cin >> ch;

      } while (ch == 'y' || ch == 'Y');

	  
     ////////////////////////////////////////////////////////////

cout << "\n\n\n\aDo you want to play a new game?(y-n): ";


do {
 NewGame = getchar();
 } while (NewGame != 'n' && NewGame != 'y');


if (NewGame != 'y') Done = true;
else { cout << "\a" << endl; Con.Clear(); }



} // End of main while loop ///////////////////////////////////////

    
    Con.END();


   return (ending.OK);

} // End of main ///////////////////////////////////////////////////////////

 // Function Definitions ///////////////////////////////////////////////////

/**************************************************************************/

void playHangman(void) 

{

   // pick a word

   string hiddenWord;

   getSecretWord(hiddenWord);


   Con.Clear();
 

   string displayWord(hiddenWord.length(), '_');

 

   // keep track of the guesses.

   string guesses("");


   // start the guessing

   bool tightenTheNoose = false;

   int  misses = 0;

   int  grphxIdx = -1;

   

   while (misses < 7 && (displayWord.compare(hiddenWord) != 0))

      {

     Con.Clear();
	  

      showGraphic(grphxIdx, tightenTheNoose);

 if (playeramount == 2) cout << "Hint: " << hint << "\n\n";

      cout << "\nWord:\t";

      showWord(displayWord);

 

      cout << "\nGuesses: ";

      showWord(guesses);

   

      if (tightenTheNoose = promptNext(hiddenWord, displayWord, guesses))

         misses++;

         Con.Clear();

      }

 

   showFinalGraphic(misses < 7);

 

   if (misses >= 7)

      cout << "\aSorry, you LOSE! The word was '" << hiddenWord << "'."

           << "\n(That's gotta hurt!)" << endl;

   else

      cout << "\aCongratulations! You guessed the word '" << hiddenWord << "'."

           << endl << endl;

}

 

/**************************************************************************/

void getSecretWord(string& dstStr)

{

   // Static array of strings to hold default word choices

   static const int wordCount = 10;

   static string wordCandidates[wordCount] = 

                  { "alligator", "crocodile", "holiday",

                    "coffee", "drainage", "computer",

                    "happy", "discontent", "programming",

                    "unix" };
  

   if (playeramount == 2)

      {

      cin.ignore();  // skip the newline from our previous cin

      cout << "Enter word for apponent (hit enter twice when done): ";

      getline(cin, dstStr);

      Con.Clear();

      // Make sure it's all lowercase

      for (int ii = 0; ii < dstStr.length(); ii++)

         dstStr[ii] = tolower(dstStr[ii]);

	  cin.ignore();  // skip the newline from our previous cin

cout << "Now enter a hint to help your apponent guess the word: ";

getline(cin, hint);


   } // End if.

   else

      dstStr = wordCandidates[ rand() % wordCount ];

}

 

/**************************************************************************/

 

// This function prompts the user for a guess.. 


//

// PARAMETERS:

//    string& secret    - A reference to the secret word.

//    string& display   - A reference to the display string (will be

//                        updated if a letter is guessed correctly)

//    string& guessList - A reference to to the list of letters

//                        already guessed (will be updated to refect

//                        the latest guess)

//

// RETURNS:

//    true if a letter was guessed correctly

//    false if the "number of misses" count should be incremented

//

bool promptNext(string& secret, string& display, string& guessList)

{

   bool addToGraphic = false;


   cout << "\nEnter your guess: ";

   char ch;

   cin >> ch;

 

   // Make sure that the guess letter is lowercase.

   ch = tolower(ch);

 

   // Have we already tried this one?

   if (guessList.find(ch) != string::npos)

      {

      // If it was wrong the first time around, it's

      // wrong again! (If it was right the first time

      // around, we'll just ignore it.)

      if (secret.find(ch) == string::npos)

         addToGraphic = true;

      }

   else

      {

      // Find all occurrences (if any) of the letter and

      // replace the '_' with the letter in the display string.

      int idx = secret.find(ch);

      addToGraphic = (idx == string::npos);

 

      while (idx != string::npos)

         {

         display[idx] = ch;

         idx = secret.find(ch, idx + 1);

         }

      }

 

   guessList += ch;

 

   return addToGraphic;

}

 

/**************************************************************************/

 

// This function displays the hangman graphic. No matter how many

// parts of the graphic it's showing, it always displays the same

// number of lines.

//

// PARAMETERS:

//    int& idx     - current index in the 'hangingMan' array

//    bool addNext - true if we should add the next part of the graphic

//                   false otherwise 

//                   (defaults to false)

//

// RETURNS:

//    nothing

//

void showGraphic(int& idx, bool addNext /* = false */)

{

   const static string hangingMan("\t O\n\t/|\\\n\t |\n\t/ \\");

 

   cout << endl << endl;

   int newlineCount = 2;

 

   // Display what we have so far

   int ii;

   for (ii = 0; ii <= idx; ii++)

      {

      cout << hangingMan[ii];

      

      if (hangingMan[ii] == '\n')

         newlineCount++;

      }

 

   if (addNext)

      {

      // now we have to add a character, but we don't

      // want it to be a blank, so keep looking for a

      // non-blank (non-tab, non-newline)

      do

         {

         if (hangingMan[idx] == '\n')

            newlineCount++;

 

         cout << hangingMan[++idx];

         } while (isspace(hangingMan[idx]));

      }

 

  clearScreen(8 - newlineCount);

}

 

/**************************************************************************/

 

void showFinalGraphic(bool didWin)

{

 
   Con.Clear();
 

   if (didWin)

      cout << "\t O\n\t\\|/\n\t |\n\t/ \\";

   else

      cout << "\t +--+\n"

           << "\t |  |\n"

           << "\t |  O\n"

           << "\t | /|\\\n"

           << "\t |  |\n"

           << "\t | / \\\n"

           << "\t |\n"

           << "\t-+-----\n";

 

   cout << endl << endl;

}

 

/**************************************************************************/

 

// Displays the given word with the letters separated by spaces.

void showWord(string& word)

{

   int len = word.length();

   for (int idx = 0; idx < len; idx++)

      cout << word[idx] << ' ';

}

 

/**************************************************************************/

void clearScreen( int lines /* = 25 */ )

{

   for (int ii = 0; ii < lines; ii++)

      cout << '\n';

} ////////////////////////////////////////////////////////////