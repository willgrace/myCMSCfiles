

#ifndef SETTINGS_H
#define SETTINGS_H


#include "line.h"


  //GLOBALS////////////////////////////

void plot_pixel(int x, int y,  unsigned char color)
{

	video_buffer[((y<<8)+(y<<6))+x]=color;

}

 ///////////////////////////////////////


  void stars()
 {

 Fill_Screen(0);
 plot_pixel(12, 13, 100);    plot_pixel(290, 20, 100);
 plot_pixel(100, 100, 100);  plot_pixel(265, 15, 100);
 plot_pixel(50, 50, 100);    plot_pixel(200, 35, 100);
 plot_pixel(30, 20, 100);    plot_pixel(180, 50, 100);
 plot_pixel(85, 75, 100);    plot_pixel(17, 185, 100);
 plot_pixel(200, 185, 100);  plot_pixel(25, 190, 100);
 plot_pixel(250, 195, 100);  plot_pixel(20, 200, 100);
 plot_pixel(280, 2, 100);    plot_pixel(3, 155, 100);
 plot_pixel(281, 12, 100);   plot_pixel(200, 200, 100);
 plot_pixel(150, 150, 100);   plot_pixel(200, 160, 100);
 plot_pixel(175, 169, 100);  plot_pixel(164, 155, 100);
 plot_pixel(180, 170, 100);  plot_pixel(152, 143, 100);
 plot_pixel(190, 185, 100);  plot_pixel(200, 134, 100);
 plot_pixel(195, 159, 100);  plot_pixel(190, 165, 100);
 plot_pixel(225, 155, 100);  plot_pixel(205, 163, 100);
 plot_pixel(2, 150, 100);    plot_pixel(3, 185, 100);
 plot_pixel(5, 190, 100);    plot_pixel(1, 200, 100);
 plot_pixel(2, 135, 100);    plot_pixel(6, 129, 100);
 plot_pixel(10, 120, 100);   plot_pixel(11, 119, 100); 

 }


#endif 
